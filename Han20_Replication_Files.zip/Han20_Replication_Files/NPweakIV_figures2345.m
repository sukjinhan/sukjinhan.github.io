
% Monte Carlo Simulation for Figures 2, 3, 4, 5 in Han (2013, wp)

% DATE: 022714 

% y = g(x) + e
% x = z*\pi + v
% Draw z from Normal
% Draw (e,v)' from BVN


clear

tic;  % Elapsed time

s = 500;   % The number of simulation estimating g0
n = 1000;   % The sample size in each simulation


% --- Preliminaries

rho = 0.5; % Degree of Endog (CAN BE NEGATIVE)

lambda = [4 8 16 32 64 128 256 1000];  % STRENGTH OF IV (this is \mu^2 in my JMP)
entry = 3; % Pick entry for lambda

penal = 0.001;

k1 = 6; % Order of approx functions for g (5)
k2 = 6; % Order of approx functions for \lambda (5)
k = k1 + k2;
k_star = 1; % k_star should be smaller than k-1

% Normalization!
v_norm = 0; % normalizing value of v (-1, 1, 0, etc)

interc = 0;

% -----

mu_x = 2;
var_x = 3;  % This should be big enough, o.w. var_v becomes negative

mu_z = 0;
var_z = 1;


% Calculating pi
pi_all = sqrt(lambda./((var_z + mu_z^2)*n));
pi = pi_all(entry);  % pi from lambda

% Evaluation point (SCALAR)
z_eval = mu_z + sqrt(var_z)*randn(n,1); % RND from normal

mu = [0 0];
var_e = 1;
var_v = 1;  % CAUTION
cov = rho*sqrt(var_e)*sqrt(var_v);
sigma = [var_e cov;cov var_v];    
ev = mvnrnd(mu,sigma,n); % RNG from bivariate normal
v_eval = ev(:,2);

% GENERATE eval_x:  Invariant to simulation repetition
x_eval = mu_x - mu_z*pi + z_eval*pi + v_eval;


% START LOOP for simulation repetition
x0 = min(x_eval); % min supp(x)
x1 = max(x_eval); % max supp(x)
x_eval = x_eval(1); % need to be scalar, pick one
xx = x0:0.1:x1;
sz = size(xx,2);
xx = xx';
all_g_hat1 = zeros(sz,s);
all_g_hat2 = zeros(sz,s);
for ss = 1:s;
    

% --- Generate {zi,ei,vi}, i = 1 to n
% Use vectorized random variables (n-by-1 vector)
% Draw (e,v)' ~ BN(0,\Sig)
% \Sig = [1, \rho; \rho, 1]
% Draw z ~ N(mean,variance)

% GENERATE z, pi, e, v for x
z = mu_z + sqrt(var_z)*randn(n,1); % RND from normal

mu = [0 0];
var_e = 1;
var_v = 1;  % CAUTION
cov = rho*sqrt(var_e)*sqrt(var_v);
sigma = [var_e cov;cov var_v];    
ev = mvnrnd(mu,sigma,n); % RNG from bivariate normal
e = ev(:,1);
v = ev(:,2);


% GENERATE x:  Invariant to simulation repetition
x = mu_x - mu_z*pi + z*pi + v; % Intercept included:  x has same mean indep of pi


% yi : Generate via y = g(x) + e

% g0(x) = cdfn((x-mu)/var) (what are these numbers??)
mu_cdf = mu_x;
sd_cdf = sqrt(var_x/4);

g0 = interc + cdf('normal',x,mu_cdf,sd_cdf); % CAUTION: sd, NOT variance
y = g0 + e;


% --- Series Estimation using {yi,xi,vi_hat}


% Linear RF
z1 = [ones(n,1) z];
pi_hat = pinv(z1'*z1)*z1'*x;
Pz = z1*pinv(z1'*z1)*z1';
Mz = eye(n) - Pz;
v_hat1 = Mz*x;

v_hat2 = v_hat1;

    
% Estimating h(x) = g(x) + \lambda(v_hat)

% With Penalization

Pmat2 = zeros(n,k-1); % k-1, only one intercept
for i=1:k1;
    Pmat2(:,i) = x.^(i-1); % from order ZERO
end
for j=1:k2-1; % CAUTION: NOT j=k1+1:k, also drop intercept term (so power is j below)
    Pmat2(:,k1+j) = v_hat2.^j; % from order ZERO as well % CAUTION, column
end


D_star = eye(k-1);
for i=1:k_star;
    D_star(i,i) = 0;
end
beta2 = pinv(Pmat2'*Pmat2 + n*penal*D_star)*Pmat2'*y;

const2 = beta2(1);
beta21 = beta2(2:k1);
beta22 = beta2(k1+1:k-1);

% Normalization: Calculating lambda_bar
var_v2 = var(v_hat2);
e_hat2 = y - Pmat2*beta2;
%var_e = var(e_hat);
rho2 = corr(e_hat2,v_hat2);
lambda_bar2 = (rho2/sqrt(var_v2))*v_norm; % corresponding value of lambda function, caution it is not rho


% --- Graph of mean(g_hat)
Pmat_xx = zeros(sz,k-1);
for i=1:k1; % from order ZERO
    Pmat_xx(:,i) = xx.^(i-1);
end
for j=1:k2-1; % from order ZERO
    Pmat_xx(:,k1+j) = v_norm.^j;
end
g_hat2 = const2 - (lambda_bar2 - Pmat_xx(:,k1+1:k-1)*beta22) + Pmat_xx(:,2:k1)*beta21;  % CAUTION: rho/sqrt(var_v)



%%

% Without Penalization
Pmat1 = zeros(n,k-1); % k-1, only one intercept
for i=1:k1;
    Pmat1(:,i) = x.^(i-1); % from order ZERO
end
for j=1:k2-1; % CAUTION: NOT j=k1+1:k, also drop intercept term (so power is j below)
    Pmat1(:,k1+j) = v_hat1.^j; % from order ZERO as well % CAUTION, column
end

beta1 = pinv(Pmat1'*Pmat1)*Pmat1'*y;

const1 = beta1(1);
beta11 = beta1(2:k1);
beta12 = beta1(k1+1:k-1);

% Normalization: Calculating lambda_bar
var_v1 = var(v_hat1);
e_hat1 = y - Pmat1*beta1;
%var_e = var(e_hat);
rho1 = corr(e_hat1,v_hat1);
lambda_bar1 = (rho1/sqrt(var_v1))*v_norm; % corresponding value of lambda function, caution it is not rho

% --- Graph of mean(g_hat)

g_hat1 = const1 - (lambda_bar1 - Pmat_xx(:,k1+1:k-1)*beta12) + Pmat_xx(:,2:k1)*beta11;  % CAUTION: rho/sqrt(var_v)


% END LOOP
all_g_hat1(:,ss) = g_hat1;
all_g_hat2(:,ss) = g_hat2;
end


%%

%--- PLOT
info(1) = {['\mu^2 = ' num2str(lambda(entry))]};
info(2) = {['k = ' num2str(k)]};
info(3) = {['penalty = ' num2str(penal)]};
info(4) = {['n = ' num2str(n)]};
info(5) = {['s = ' num2str(s)]};
info(6) = {[]};

g0_xx = interc + cdf('normal',xx,mu_cdf,sd_cdf);

mean_g_hat1 = mean(all_g_hat1,2);
mean_g_hat2 = mean(all_g_hat2,2);
l_g_hat1 = quantile(all_g_hat1,.025,2);
u_g_hat1 = quantile(all_g_hat1,.975,2);
l_g_hat2 = quantile(all_g_hat2,.025,2);
u_g_hat2 = quantile(all_g_hat2,.975,2);

plot1 = plot(xx,[g0_xx mean_g_hat1 l_g_hat1 u_g_hat1 mean_g_hat2 l_g_hat2 u_g_hat2]);

set(plot1(1),'LineStyle','-.','Color',[0 0 1]);
set(plot1(2),'LineWidth',1,'Color',[0 0 0]);
set(plot1(3),'LineStyle',':','Color',[0 0 0]);
set(plot1(4),'LineStyle',':','Color',[0 0 0]);
set(plot1(5),'LineWidth',1,'Color',[1 0 0]);
set(plot1(6),'LineStyle','--','Color',[1 0 0]);
set(plot1(7),'LineStyle','--','Color',[1 0 0]);

axis([-1 4.5 -1 2]); % Determin min and max of each axis
text(2,-0.5,info);



%{
% --- DIST of vec_ag
info(1) = {['\mu ^2 = ' num2str(lambda(kk))]};
info(2) = {['\rho = ' num2str(rho)]};
info(3) = {['k_1 = ' num2str(k1)]};
info(4) = {['k_2 = ' num2str(k2)]};
info(5) = {['n = ' num2str(n)]};
info(6) = {['s = ' num2str(s)]};

% Histogram
bin = min(vec_ag):0.005:max(vec_ag);
hist(vec_ag,bin);
text(min(vec_ag),220,info,'HorizontalAlignment','left');

% Kernel density
[f,xi] = ksdensity(vec_ag); % f is row vector!
%plot(xi,f);

% With normal dist for comparison
% (i) Centered at E[a(g^)]
mu_ag = mean(vec_ag);
var_ag = var(vec_ag);
sd_ag = sqrt(var_ag);
ag_normal1 = pdf('normal',xi,mu_ag,sd_ag); % CAUTION: sd, NOT variance!
% (ii) Centered at a(g0)
ag02 = cdf('normal',mu_x,mu_cdf,sd_cdf); % Either 1 or 2 % At eval point
ag_normal2 = pdf('normal',xi,ag02,sd_ag); % CAUTION: true mean but used the same sd

plot(xi,f,'-',xi,ag_normal1,':',xi,ag_normal2,':'); % solid and dotted lines
legend('a(g\^)','normal1','normal2'); % legend
text(min(mu_ag)-0.5,max(ag_normal1)-1,info);
%text(min(vec_ag),max(ag_normal),info,'HorizontalAlignment','left');

%}
tElapsed=toc/60
