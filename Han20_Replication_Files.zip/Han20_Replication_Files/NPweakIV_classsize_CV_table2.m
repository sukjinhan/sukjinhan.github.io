
% Cross Validation for Nonparametric Estimation of Effect of Class Size, Table 2 in Han (2013, wp)

% DATE: 022714 


clear

load [INSERT PATH HERE]class_data.mat;

tic;  % Elapsed time


% --- Preliminaries

k_mat = [2 2; 3 3; 4 4; 5 5];
k3_mat = [4; 6; 8; 10];
graphcnt = 3;
k1 = k_mat(graphcnt,1);
k2 = k_mat(graphcnt,2);
k = k1 + k2;
k3 = k3_mat(graphcnt);

penal = [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20];
penal = penal/600;
%penal = [0 0.0017 0.0034 0.0051 0.0068 0.0085 0.0102 0.0119 0.0136 0.0153 0.0170 0.0188 0.0205 0.0222 0.0239 0.0256];
%for weak IV %penal = [0 0.001 0.002 0.003 0.004 0.005 0.006 0.007 0.008 0.009 0.01 0.011 0.012 0.013 0.014 0.015 0.016 0.017];
%for strong IV %penal = [0 0.01 0.011 0.012 0.013 0.014 0.015 0.016 0.017 .02 .03 .04 .05 .07 .09 .15];
s = size(penal,2);

reps = 1000;

full = 0;   % Whether full sample (=1) full random subsample (=2) or discontinuity sample (=0)

% Normalization!
v_norm = 0; % normalizing value of v (-1, 1, 0, etc)

% Evaluation point of w can be changed!


% Variables:
% y : average verbal skill (average math skill)
% x : class size
% z : maimonides' rule (function of enrollment)
% w : percent disadvantaged (or, enrollment, enrollment2, linear trend)

n0 = size(a.avgverb,1);
n00 = sum(a.disc);
p = n00/n0;

if full == 1;
    select = ones(n0,1);
elseif full == 2;
    select = binornd(1,p,n0,1);
else
    select = a.disc;
end

n = sum(select);
y0 = zeros(n,1);
x0 = zeros(n,1);
z0 = zeros(n,1);
w0 = zeros(n,1);
schlcode = zeros(n,1);
cnt = 1;
for i = 1:n0;
    if select(i)==1;
    y0(cnt) = a.avgverb(i);
    x0(cnt) = a.classize(i);
    z0(cnt) = a.func1(i);
    w0(cnt) = a.tipuach(i);
    schlcode(cnt) = a.schlcode(i);
    cnt = cnt + 1;
    end
end

%y0 = y0 - mean(y0);
%x0 = x0 - mean(x0);


mu_x = mean(x0);
var_x = var(x0);

mu_z = mean(z0,1);  %row vector
var_z = var(z0);  %row vector

% Sample Size
n1 = size(y0,1);


MSE_penal_all = zeros(s,reps);

for rr = 1:reps;

% CROSS VALIDATION
CVO = cvpartition(n1,'k',10);
err = zeros(CVO.NumTestSets,s);
for ss = 1:s; % DO NOT USE THE SAME INDEX as in inner loops
    
for ii = 1:CVO.NumTestSets;
    trIdx = CVO.training(ii);
    teIdx = CVO.test(ii);
    y = y0(trIdx);
    x = x0(trIdx);
    z = z0(trIdx);
    w = w0(trIdx);
    y_te = y0(teIdx);
    x_te = x0(teIdx);
    z_te = z0(teIdx);
    w_te = w0(teIdx);
    
    
n = size(y,1);

% --- Series Estimation using {yi,xi,vi_hat}

% Series Estimating RF
%{
Rmat = zeros(n,k3);
for i=1:k3;
    Rmat(:,i) = z.^(i-1); % from order ZERO
end
gamma = pinv(Rmat'*Rmat)*Rmat'*x;
v_hat2 = x - Rmat*gamma;
%}

% Linear RF
z1 = [ones(n,1) z w];
Pz = z1*pinv(z1'*z1)*z1';
Mz = eye(n) - Pz;
v_hat1 = Mz*x;
v_hat2 = v_hat1;


%%
% Estimating h(x) = g(x) + \lambda(v_hat)

% With Penalization

Pmat_w2 = zeros(n,1);  % CAUTION, dimension randomly assigned but it works!!
cnt = 1;
for i=0:k1-1;
    for j=0:k1-1;
        if i+j <= k1-1;
        Pmat_w2(:,cnt) = x.^i .* w.^j; % from order ZERO
        cnt = cnt + 1;
        end
    end
end
k_b1 = cnt - 1;
for j=1:k2-1; % CAUTION: NOT j=k1+1:k, also drop intercept term (so power is j below)
    Pmat_w2(:,cnt) = v_hat2.^j; % from order ZERO as well % CAUTION, column
    cnt = cnt + 1;
end
k_b = cnt - 1;
Pmat2 = Pmat_w2;
Psi = eye(k_b);
Psi(1,1) = 0;
beta2 = pinv(Pmat2'*Pmat2 + n*penal(ss)*Psi)*Pmat2'*y;


%%
% CALCULATED TESTING SAMPLE (TESTING GENERATED REGRESSOR)
% Linear RF

n_te = size(y_te,1);
z1_te = [ones(n_te,1) z_te w_te];
Pz_te = z1_te*pinv(z1_te'*z1_te)*z1_te';
Mz_te = eye(n_te) - Pz_te;
v_hat_te = Mz_te*x_te;


Pmat2_te = zeros(n_te,1);  % CAUTION, dimension randomly assigned but it works!!
cnt = 1;
for i=0:k1-1;
    for j=0:k1-1;
        if i+j <= k1-1;
        Pmat2_te(:,cnt) = x_te.^i .* w_te.^j; % from order ZERO
        cnt = cnt + 1;
        end
    end
end
k_b1 = cnt - 1;
for j=1:k2-1; % CAUTION: NOT j=k1+1:k, also drop intercept term (so power is j below)
    Pmat2_te(:,cnt) = v_hat_te.^j; % from order ZERO as well % CAUTION, column
    cnt = cnt + 1;
end

err(ii,ss) = (y_te - Pmat2_te*beta2)'*(y_te - Pmat2_te*beta2);
end
end


MSE_penal_all(:,rr) = sum(err,1)'./sum(CVO.TestSize);

end

Mean_MSE_penal = mean(MSE_penal_all,2);

tElapsed=toc/60
