
% Monte Carlo Simulations for Table 1 in Han (2013, wp)

% DATE: 022714 

% y = g(x) + e
% x = z*\pi + v
% Draw z from Normal
% Draw (e,v)' from BVN

clear

tic;  % Elapsed time

s = 1000;   % The number of simulation estimating g0
n = 1000;   % The sample size in each simulation


% --- Preliminaries


rho = 0.5; % Degree of Endog

lambda = [2 4 8 16 32 64 128 256];  % STRENGTH OF IV

entry = 5;  % Choose penalization parameter value here
all_penal = [0.001 0.005 0.01 0.05 0.1];  %[0 0.001 0.005 0.01]
penal = all_penal(entry);
%penal = 0;

k1 = 6; % Order of approx functions for g
k2 = 6; % Order of approx functions for \lambda
k = k1 + k2;
k_star = 3; % k_star should be 0 or 1,3,5,7,... (i.e., of the form 2n-1), and smaller than k-1


% -----

mu_x = 2;
var_x = 3;  % This should be big enough, o.w. var_v becomes negative

mu_z = 0;
var_z = 1;

% Calculating pi
pi_all = sqrt(lambda./((var_z + mu_z^2)*n));


sz_l = size(lambda,2);
vec_g1 = zeros(s,sz_l*n);  % Collect ghat_cf
vec_g2 = zeros(s,sz_l*n);  % Collect ghat_cf
vec_g_ls = zeros(s,sz_l*n);  % Collect ghat_ls
vec_x_eval = zeros(1,sz_l*n);  % Collect x_eval

% START LOOP for variation in pi
for kk = 1:sz_l;

pi = pi_all(kk);  % pi from lambda

z_eval = mu_z + sqrt(var_z)*randn(n,1); % RND from normal

mu = [0 0];
var_e = 1;
var_v = 1;  % CAUTION
cov = rho*sqrt(var_e)*sqrt(var_v);
sigma = [var_e cov;cov var_v];    
ev = mvnrnd(mu,sigma,n); % RNG from bivariate normal
v_eval = ev(:,2);

% GENERATE eval_x:  Invariant to simulation repetition
x_eval = mu_x - mu_z*pi + z_eval*pi + v_eval;


% START LOOP for simluation repetition
for jj = 1:s;


% GENERATE z, pi, e, v for x
z = mu_z + sqrt(var_z)*randn(n,1); % RND from normal

mu = [0 0];
var_e = 1;
var_v = 1;  % CAUTION
cov = rho*sqrt(var_e)*sqrt(var_v);
sigma = [var_e cov;cov var_v];    
ev = mvnrnd(mu,sigma,n); % RNG from bivariate normal
e = ev(:,1);
v = ev(:,2);

% GENERATE x:  Invariant to simulation repetition
x = mu_x - mu_z*pi + z*pi + v; % x has same mean indep of pi

% yi : Generate via y = g(x) + e

% g0(x) = cdfn((x-mu)/var)
mu_cdf = mu_x;
sd_cdf = sqrt(var_x);
g0 = cdf('normal',x,mu_cdf,sd_cdf); % CAUTION: sd, NOT variance
y = g0 + e;


% --- Series Estimation using {yi,xi,vi_hat}

% Estimating \pi and vi
% CAUTION:  INTERCEPT
z1 = [ones(n,1) z];
pi_hat = pinv(z1'*z1)*z1'*x; % a\b instead of inv(a)*b (also consider pinv)
Pz = z1*pinv(z1'*z1)*z1';
Mz = eye(n) - Pz;
v_hat = Mz*x;
v_hat_check = x - z1*pi_hat;


% Estimating h(x) = g(x) + \lambda(v_hat)

% Series Estimation
% w = (x,v)
% At this stage, only one intercept in Pmat_w
Pmat_w = zeros(n,k-1); % k-1, only one intercept
for i=1:k1;
    Pmat_w(:,i) = x.^(i-1); % from order ZERO
end
for j=1:k2-1; % CAUTION: NOT j=k1+1:k, also drop intercept term (so power is j below)
    Pmat_w(:,k1+j) = v_hat.^j; % from order ZERO as well % CAUTION, column
end

Pmat = Pmat_w;

% Estimation
% Let \beta be the corresponding parameter

beta1 = pinv(Pmat'*Pmat)*Pmat'*y;


% --- Evaluating g(x)

Pk = zeros(n,k-1); % changed to matrix
for i=1:k1; % from order ZERO
    Pk(:,i) = (x_eval).^(i-1);  % CAUTION: x_eval
end
v_norm = ones(n,1); % normalizing value of v, that's why we subtract rho, changed to vector of 1's
for j=1:k2-1; % from order ZERO
    Pk(:,k1+j) = v_norm.^j; % CAUTION: Evaluation point: mu_x
end

% For constant terms for each g and \lambda, SEE p.572 NPV
const1 = beta1(1);
beta11 = beta1(2:k1);
beta12 = beta1(k1+1:k-1);
Pk1 = Pk(:,2:k1);
Pk2 = Pk(:,k1+1:k-1);

const12 = rho/sqrt(var_v) - Pk2*beta12;  % CAUTION, instead of rho
const11 = const1 - const12;

g1 = const11 + Pk1*beta11; % CAUTION, subtract normalization term, lambda_hat

% PENALIZED Series Estimation

D_star = eye(k-1);
if k_star~=0
    for i=1:(k_star+1)/2;   % Caution: control intercept and first (k_star-1)/2 coefficent
        D_star(i,i) = 0;
    end
    for i=k1+1:k1+(k_star-1)/2;   % Caution: control first (k_star-1)/2 coefficent starting from k1+1; When k_star=1, interval is not defined as desired
        D_star(i,i) = 0;
    end
end
beta2 = pinv(Pmat'*Pmat + n*penal*D_star)*Pmat'*y;

% For constant terms for each g and \lambda, SEE p.572 NPV
const2 = beta2(1);
beta21 = beta2(2:k1);
beta22 = beta2(k1+1:k-1);

const22 = rho/sqrt(var_v) - Pk2*beta22;  % CAUTION, instead of rho
const21 = const2 - const22;

g2 = const21 + Pk1*beta21; % CAUTION, subtract normalization term, lambda_hat


% --- LS Estimation of g using {yi,xi}

Pmat_x = Pmat_w(:,1:k1);
beta_ls = pinv(Pmat_x'*Pmat_x)*Pmat_x'*y;

g1_ls = Pk(:,1:k1)*beta_ls;

% Collecting results
vec_g1(jj,(kk-1)*n+1:kk*n) = g1';
vec_g2(jj,(kk-1)*n+1:kk*n) = g2';
vec_g_ls(jj,(kk-1)*n+1:kk*n) = g1_ls'; % Either 1 or 2
vec_x_eval((kk-1)*n+1:kk*n) = x_eval';

% END LOOP for pi (kk)
end

% END LOOP for repetition (jj)
end


clear Mz Pk Pk1 Pk2 Pmat Pmat_w Pmat_x Pz

% --- BIAS and VARIANCE comparison

% --- Integrated Bias
% NOTE: mean and variance function is for each column
mu_g1 = mean(vec_g1);  % E[ghat_cf]
mu_g2 = mean(vec_g2);  % E[ghat_cf]
mu_g_ls = mean(vec_g_ls);  % E[ghat_ls]

% True g0 evaluated at x_eval
g0 = cdf('normal',vec_x_eval,mu_cdf,sd_cdf);

bias_cf1 = mu_g1 - g0;
bias_cf2 = mu_g2 - g0;
bias_ls = mu_g_ls - g0;
sqbias_cf1 = bias_cf1.^2;
sqbias_cf2 = bias_cf2.^2;
sqbias_ls = bias_ls.^2;

int_sqbias_cf1 = zeros(1,sz_l);
int_sqbias_cf2 = zeros(1,sz_l);
int_sqbias_ls = zeros(1,sz_l);
for k=1:sz_l;
int_sqbias_cf1(k) = mean(sqbias_cf1((k-1)*n+1:k*n));
int_sqbias_cf2(k) = mean(sqbias_cf2((k-1)*n+1:k*n));
int_sqbias_ls(k) = mean(sqbias_ls((k-1)*n+1:k*n));
end

% --- Integrated Variance and Integrated MSE
demeansq1 = zeros(s,sz_l*n);
demeansq2 = zeros(s,sz_l*n);
demeansq_ls = zeros(s,sz_l*n);
for k=1:sz_l*n;
demeansq1(:,k) = (vec_g1(:,k) - mu_g1(k)).^2;
demeansq2(:,k) = (vec_g2(:,k) - mu_g2(k)).^2;
demeansq_ls(:,k) = (vec_g_ls(:,k) - mu_g_ls(k)).^2;
end

var_cf1 = mean(demeansq1);
var_cf2 = mean(demeansq2);
var_ls = mean(demeansq_ls);
clear vec_g1 vec_g2 vec_g_ls demeansq1 demeansq2 demeansq_ls vec_x_eval;

int_var_cf1 = zeros(1,sz_l);
int_var_cf2 = zeros(1,sz_l);
int_var_ls = zeros(1,sz_l);
for k=1:sz_l;
int_var_cf1(k) = mean(var_cf1((k-1)*n+1:k*n));
int_var_cf2(k) = mean(var_cf2((k-1)*n+1:k*n));
int_var_ls(k) = mean(var_ls((k-1)*n+1:k*n));
end

int_mse_cf1 = int_sqbias_cf1 + int_var_cf1;
int_mse_cf2 = int_sqbias_cf2 + int_var_cf2;
int_mse_ls = int_sqbias_ls + int_var_ls;

% --- Comparisons

rel_mse1 = int_mse_cf1./int_mse_ls;
rel_mse2 = int_mse_cf2./int_mse_cf1;

% RESULTS TABLE

table1 = [lambda; int_sqbias_cf1; int_var_cf1; int_mse_cf1; rel_mse1; int_sqbias_cf2; int_var_cf2; int_mse_cf2; rel_mse2];
table2 = [rho; 1; 1; 1; 1; 2; 2; 2; 2];
RESULT_TABLE = [table2 table1]; 

save('TABLE1_2_5.mat','RESULT_TABLE','penal','n','s','rho','k1','k2','k_star');    % "TABLE1_entry.mat"

tElapsed=toc/60;