
% Nonparametric Estimation of Effect of Class Size, Figure 8 in Han (2013, wp)

% DATE: 022714 


clear

load [INSERT PATH HERE]class_data.mat;

tic;  % Elapsed time


% --- Preliminaries

s = 100;   % The number of bootstrap simulation estimating g0


k_mat = [2 2; 3 3; 4 4; 5 5];
k3_mat = [4; 6; 8; 10];
graphcnt = 3;
k1 = k_mat(graphcnt,1);
k2 = k_mat(graphcnt,2);
k = k1 + k2;
k3 = k3_mat(graphcnt);

penal = 0.05;

%k1 = 5; % Order of approx functions for g (7)
%k2 = 5; % Order of approx functions for \lambda (4)
% k2 needs to be bigger than 2
%k = k1 + k2;

%k3 = 8; %  Order of approx functions for \Pi (7 is best) (20 or 15 can be a demonstration)

full = 0;   % Whether full sample (=1) full random subsample (=2) or discontinuity sample (=0)

% Normalization!
v_norm = 0; % normalizing value of v (-1, 1, 0, etc)

% Evaluation point of w can be changed!


% Variables:
% y : average verbal skill (average math skill)
% x : class size
% z : maimonides' rule (function of enrollment)
% w : percent disadvantaged (or, enrollment, enrollment2, linear trend)

n0 = size(a.avgverb,1);
n00 = sum(a.disc);
p = n00/n0;

if full == 1;
    select = ones(n0,1);
elseif full == 2;
    select = binornd(1,p,n0,1);
else
    select = a.disc;
end

n = sum(select);
y0 = zeros(n,1);
x0 = zeros(n,1);
z0 = zeros(n,1);
w0 = zeros(n,1);
schlcode = zeros(n,1);
cnt = 1;
for i = 1:n0;
    if select(i)==1;
    y0(cnt) = a.avgverb(i);
    x0(cnt) = a.classize(i);
    z0(cnt) = a.func1(i);
    w0(cnt) = a.tipuach(i);
    schlcode(cnt) = a.schlcode(i);
    cnt = cnt + 1;
    end
end


mu_x = mean(x0);
var_x = var(x0);

mu_z = mean(z0,1);  %row vector
var_z = var(z0);  %row vector

% Sample Size
n1 = size(y0,1);


% Bootstrap Indices
schl = unique(schlcode);
[bootstat,bootsam] = bootstrp(s,[],schl);


% START LOOP for simulation repetition
x_min = min(x0); % min supp(x)
x_max = max(x0); % max supp(x)
x_eval = mu_x; % for a(g)
xx = x_min:0.1:x_max;
sz = size(xx,2);
xx = xx';
all_g_hat1 = zeros(sz,s);
all_g_hat2 = zeros(sz,s);

for ss = 1:s; % DO NOT USE THE SAME INDEX as in inner loops
    

% Bootstrap Samples
y = zeros(5,1);
x = zeros(5,1);
z = zeros(5,1);
w = zeros(5,1);

sz_code = size(schl,1);
cnt = 1;
for bb = 1:sz_code;
    bootindex = bootsam(bb,ss);
    for i = 1:n1;
        if schlcode(i) == schl(bootindex);
        y(cnt) = y0(i);
        x(cnt) = x0(i);
        z(cnt) = z0(i);
        w(cnt) = w0(i);
        cnt = cnt + 1;
        end
    end
end

n = size(y,1);

%%


% --- Series Estimation using {yi,xi,vi_hat}

% Series Estimating RF
%{
Rmat = zeros(n,1);  % CAUTION, dimension randomly assigned but it works!!
cnt = 1;
for i=0:k3-1;
    for j=0:k3-1;
        if i+j <= k3-1;
        Rmat(:,cnt) = z.^i .* w.^j; % from order ZERO
        cnt = cnt + 1;
        end
    end
end
gamma = pinv(Rmat'*Rmat)*Rmat'*x;
v_hat2 = x - Rmat*gamma;
%}

% Linear RF

z1 = [ones(n,1) z w];
Pz = z1*pinv(z1'*z1)*z1';
Mz = eye(n) - Pz;
v_hat1 = Mz*x;
v_hat2 = v_hat1;


%%
% Estimating h(x) = g(x) + \lambda(v_hat)

% With Penalization
mu_w = mean(w);
eval_w = 1.5;

Pmat_w2 = zeros(n,1);  % CAUTION, dimension randomly assigned but it works!!
cnt = 1;
for i=0:k1-1;
    for j=0:k1-1;
        if i+j <= k1-1;
        Pmat_w2(:,cnt) = x.^i .* w.^j; % from order ZERO
        cnt = cnt + 1;
        end
    end
end
k_b1 = cnt - 1;
for j=1:k2-1; % CAUTION: NOT j=k1+1:k, also drop intercept term (so power is j below)
    Pmat_w2(:,cnt) = v_hat2.^j; % from order ZERO as well % CAUTION, column
    cnt = cnt + 1;
end
k_b = cnt - 1;
Pmat2 = Pmat_w2;

% RIDGE REGRESSION FORM
Psi = eye(k_b);
Psi(1,1) = 0;
beta2 = pinv(Pmat2'*Pmat2 + n*penal*Psi)*Pmat2'*y;

const2 = beta2(1);
beta21 = beta2(2:k_b1);
beta22 = beta2(k_b1+1:k_b);

% Normalization: Calculating lambda_bar
var_v2 = var(v_hat2);
e_hat2 = y - Pmat2*beta2;
%var_e = var(e_hat);
rho2 = corr(e_hat2,v_hat2);
lambda_bar2 = (rho2/sqrt(var_v2))*v_norm; % corresponding value of lambda function, caution it is not rho



% --- Graph of mean(g_hat)
Pmat_xx = zeros(sz,1);  % CAUTION, dimension randomly assigned but it works!!
cnt = 1;
for i=0:k1-1;
    for j=0:k1-1;
        if i+j <= k1-1;
        Pmat_xx(:,cnt) = xx.^i .* eval_w.^j; % from order ZERO
        cnt = cnt + 1;
        end
    end
end
for j=1:k2-1; % CAUTION: NOT j=k1+1:k, also drop intercept term (so power is j below)
    Pmat_xx(:,cnt) = v_norm.^j; % from order ZERO as well % CAUTION, column
    cnt = cnt + 1;
end

g_hat2 = const2 - (lambda_bar2 - Pmat_xx(:,k_b1+1:k_b)*beta22) + Pmat_xx(:,2:k_b1)*beta21;  % CAUTION: rho/sqrt(var_v)




%%

% Without Penalization

beta1 = pinv(Pmat2'*Pmat2)*Pmat2'*y;

const1 = beta1(1);
beta11 = beta1(2:k_b1);
beta12 = beta1(k_b1+1:k_b);

% Normalization: Calculating lambda_bar
var_v1 = var(v_hat1);
e_hat1 = y - Pmat2*beta1;
%var_e = var(e_hat);
rho1 = corr(e_hat1,v_hat1);
lambda_bar1 = (rho1/sqrt(var_v1))*v_norm; % corresponding value of lambda function, caution it is not rho

% --- Graph of mean(g_hat)

g_hat1 = const1 - (lambda_bar1 - Pmat_xx(:,k_b1+1:k_b)*beta12) + Pmat_xx(:,2:k_b1)*beta11;  % CAUTION: rho/sqrt(var_v)


% END LOOP
all_g_hat1(:,ss) = g_hat1;
all_g_hat2(:,ss) = g_hat2;

end

%{
mean_beta1 = mean(all_beta1,2);
mean_beta1(1) = 0;
norm_beta1 = sqrt(mean_beta1'*mean_beta1);
%}

%%

%--- PLOT
%info(1) = {['\mu^2 = ' num2str(lambda(entry1))]};
info(2) = {['k = ' num2str(k)]};
info(3) = {['penalty = ' num2str(penal)]};
info(4) = {['n = ' num2str(n)]};
info(5) = {['b = ' num2str(s)]};
%info(6) = {[]};

mean_g_hat1 = mean(all_g_hat1,2);
mean_g_hat2 = mean(all_g_hat2,2);
l_g_hat1 = quantile(all_g_hat1,.025,2);
u_g_hat1 = quantile(all_g_hat1,.975,2);
l_g_hat2 = quantile(all_g_hat2,.025,2);
u_g_hat2 = quantile(all_g_hat2,.975,2);

plot1 = plot(xx,[mean_g_hat1 l_g_hat1 u_g_hat1 mean_g_hat2 l_g_hat2 u_g_hat2]);

set(plot1(1),'LineWidth',1,'Color',[0 0 0]);
set(plot1(2),'LineStyle',':','Color',[0 0 0]);
set(plot1(3),'LineStyle',':','Color',[0 0 0]);
set(plot1(4),'LineWidth',1,'Color',[1 0 0]);
set(plot1(5),'LineStyle','--','Color',[1 0 0]);
set(plot1(6),'LineStyle','--','Color',[1 0 0]);



axis([20 40 75 90]); % Determin min and max of each axis
%axis([3.5 7 0.01 0.15]); % Ideal for k3 = 6 case
text(35,85,info);



tElapsed=toc/60
