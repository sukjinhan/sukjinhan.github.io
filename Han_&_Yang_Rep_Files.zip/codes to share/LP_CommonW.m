clear all;
%% Common W
common_W=1;
%% Generating (Y,D,Z,W) of size N
% size and seed
N = 200000;
K=50;
K=K+1;
rng(123)

% parameters
p_Z = 0.5;
nu_z = 0.3;
nu_x = 0.3;
rho = 0.3;
cop_mat = copularnd('Gaussian',rho,N);
u_x = cop_mat(:,1);
e = cop_mat(:,2);
u = rand(N,1);
p_W = 0.2;
p_X = 0.6;
% q(e|u), now e takes values {1,2,...,16}
% y(d,w,x=0)
% map1: y(0,0)=0, y(0,1)=0, y(1,0)=0, y(1,1)=0
q_1(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map2: y(0,0)=1, y(0,1)=0, y(1,0)=0, y(1,1)=0
q_2(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map3: y(0,0)=0, y(0,1)=1, y(1,0)=0, y(1,1)=0
q_3(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map4: y(0,0)=1, y(0,1)=1, y(1,0)=0, y(1,1)=0
q_4(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map5: y(0,0)=0, y(0,1)=0, y(1,0)=1, y(1,1)=0
q_5(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map6: y(0,0)=1, y(0,1)=0, y(1,0)=1, y(1,1)=0
q_6(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map7: y(0,0)=0, y(0,1)=1, y(1,0)=1, y(1,1)=0
q_7(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map8: y(0,0)=1, y(0,1)=1, y(1,0)=1, y(1,1)=0
q_8(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map9: y(0,0)=0, y(0,1)=0, y(1,0)=0, y(1,1)=1
q_9(:,1) = 0.8*bern(4,0,u) + 0.8*bern(4,1,u) + 0.8*bern(4,2,u) + 0.8*bern(4,3,u) + 0.8*bern(4,4,u);
% map10: y(0,0)=1, y(0,1)=0, y(1,0)=0, y(1,1)=1
q_10(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map11: y(0,0)=0, y(0,1)=1, y(1,0)=0, y(1,1)=1
q_11(:,1) = 0.18*bern(4,0,u) + 0.18*bern(4,1,u) + 0.18*bern(4,2,u) + 0.18*bern(4,3,u) + 0.18*bern(4,4,u);
% map12: y(0,0)=1, y(0,1)=1, y(1,0)=0, y(1,1)=1
q_12(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map13: y(0,0)=0, y(0,1)=0, y(1,0)=1, y(1,1)=1
q_13(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map14: y(0,0)=1, y(0,1)=0, y(1,0)=1, y(1,1)=1
q_14(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map15: y(0,0)=0, y(0,1)=1, y(1,0)=1, y(1,1)=1
q_15(:,1) = 0.02*bern(4,0,u) + 0.02*bern(4,1,u) + 0.02*bern(4,2,u) + 0.02*bern(4,3,u) + 0.02*bern(4,4,u);
% map16: y(0,0)=1, y(0,1)=1, y(1,0)=1, y(1,1)=1
q_16(:,1) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);

% y(d,w,x=1)
% map1: y(0,0)=0, y(0,1)=0, y(1,0)=0, y(1,1)=0
q_1(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map2: y(0,0)=1, y(0,1)=0, y(1,0)=0, y(1,1)=0
q_2(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map3: y(0,0)=0, y(0,1)=1, y(1,0)=0, y(1,1)=0
q_3(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map4: y(0,0)=1, y(0,1)=1, y(1,0)=0, y(1,1)=0
q_4(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map5: y(0,0)=0, y(0,1)=0, y(1,0)=1, y(1,1)=0
q_5(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map6: y(0,0)=1, y(0,1)=0, y(1,0)=1, y(1,1)=0
q_6(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map7: y(0,0)=0, y(0,1)=1, y(1,0)=1, y(1,1)=0
q_7(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map8: y(0,0)=1, y(0,1)=1, y(1,0)=1, y(1,1)=0
q_8(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map9: y(0,0)=0, y(0,1)=0, y(1,0)=0, y(1,1)=1
q_9(:,2) = 0.9*bern(4,0,u) + 0.9*bern(4,1,u) + 0.9*bern(4,2,u) + 0.9*bern(4,3,u) + 0.9*bern(4,4,u);
% map10: y(0,0)=1, y(0,1)=0, y(1,0)=0, y(1,1)=1
q_10(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map11: y(0,0)=0, y(0,1)=1, y(1,0)=0, y(1,1)=1
q_11(:,2) = 0.09*bern(4,0,u) + 0.09*bern(4,1,u) + 0.09*bern(4,2,u) + 0.09*bern(4,3,u) + 0.09*bern(4,4,u);
% map12: y(0,0)=1, y(0,1)=1, y(1,0)=0, y(1,1)=1
q_12(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map13: y(0,0)=0, y(0,1)=0, y(1,0)=1, y(1,1)=1
q_13(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map14: y(0,0)=1, y(0,1)=0, y(1,0)=1, y(1,1)=1
q_14(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);
% map15: y(0,0)=0, y(0,1)=1, y(1,0)=1, y(1,1)=1
q_15(:,2) = 0.01*bern(4,0,u) + 0.01*bern(4,1,u) + 0.01*bern(4,2,u) + 0.01*bern(4,3,u) + 0.01*bern(4,4,u);
% map16: y(0,0)=1, y(0,1)=1, y(1,0)=1, y(1,1)=1
q_16(:,2) = 0*bern(4,0,u) + 0*bern(4,1,u) + 0*bern(4,2,u) + 0*bern(4,3,u) + 0*bern(4,4,u);

% m function: m(d,w,x) = m_d_w_x
for i=1:2
    m_0_0(:,i) = q_2(:,i) + q_4(:,i) + q_6(:,i) + q_8(:,i) + q_10(:,i) + q_12(:,i) + q_14(:,i) + q_16(:,i);
    m_0_1(:,i) = q_3(:,i) + q_4(:,i) + q_7(:,i) + q_8(:,i) + q_11(:,i) + q_12(:,i) + q_15(:,i) + q_16(:,i);
    m_1_0(:,i) = q_5(:,i) + q_6(:,i) + q_7(:,i) + q_8(:,i) + q_13(:,i) + q_14(:,i) + q_15(:,i) + q_16(:,i);
    m_1_1(:,i) = q_9(:,i) + q_10(:,i) + q_11(:,i) + q_12(:,i) + q_13(:,i) + q_14(:,i) + q_15(:,i) + q_16(:,i);
end
% data
Z = p_Z >= rand(N,1);
W = p_W >= rand(N,1);
X = p_X >= u_x;

D = (0.1+nu_z*Z+nu_x*X+common_W.*0.1*W >= u);
Y = D.*(W.*(X.*(m_1_1(:,2)>e)+(1-X).*(m_1_1(:,1))>e)...
    +(1-W).*(X.*(m_1_0(:,2)>e)+(1-X).*(m_1_0(:,1)>e)))...
    +(1-D).*(W.*(X.*(m_0_1(:,2)>e)+(1-X).*(m_0_1(:,1)>e))...
    +(1-W).*(X.*(m_0_0(:,2)>e)+(1-X).*(m_0_0(:,1)>e)));

ATE = mean(W.*(X.*(m_1_1(:,2)>e)+(1-X).*(m_1_1(:,1)>e))...
    +(1-W).*(X.*(m_1_0(:,2)>e)+(1-X).*(m_1_0(:,1)>e)))...
    -mean(W.*(X.*(m_0_1(:,2)>e)+(1-X).*(m_0_1(:,1)>e))...
    +(1-W).*(X.*(m_0_0(:,2)>e)+(1-X).*(m_0_0(:,1)>e)));

%% Basis Function
b = cell(K,1);
for i=1:K
    b{i} = @(u)bern(K-1,i-1,u);
end

%% A is for ATE
dim_s = 2^(4); % number of maps for each x
dim_x = 2; % dimension of x
dim_w = 2; % dimension of w
s = (1:dim_s)';
Bi_s = de2bi(s-1);    % value of y(0), y(1) for each x

% probablity of W in data
p_wx = zeros(2,dim_x);
for j = 1:dim_x
    for i=1:2
        p_wx(i,j) = sum(W==i-1&X==j-1)/N;
    end
end
p_w_x = zeros(2,dim_x);
for j = 1:dim_x
    for i=1:2
        p_w_x(i,j) = sum(W==i-1&X==j-1)/sum(X==j-1);
    end
end

A_0 = zeros(K,dim_s,dim_x);
A_1 = zeros(K,dim_s,dim_x);

gam0_ATE = zeros(K,1);
gam1_ATE = zeros(K,1);
for i=1:K
    syms u
    gam0_ATE(i) = -int(b{i},u,0,1);
    gam1_ATE(i) = int(b{i},u,0,1);
end

for i=1:dim_x
    for j = 1:dim_s
        for m=1:dim_w
            if Bi_s(j,m) == 1  % in Bi_s, find the column for y(d,w) and choose s (decimal value j) s.t. y(0,w) = 1
                A_0(:,j,i) = p_wx(m,i)+A_0(:,j,i); % sum across w s.t y(0,w) = 1
            end
            if Bi_s(j,m+2) == 1  % in Bi_s, find the column for y(d,w) and choose s (decimal value j) s.t. y(1,w) = 1
                A_1(:,j,i) = p_wx(m,i)+A_1(:,j,i);
            end
        end
        A_0(:,j,i) = A_0(:,j,i).*gam0_ATE;
        A_1(:,j,i) = A_1(:,j,i).*gam1_ATE;
    end
end

A = reshape(A_0,1,[])+reshape(A_1,1,[]);

%% Defining p =  P(D,Y=1|Z,W,X)
dim_p = 2^(4);    % number of possibility in (Z,D,Y,W,X)
Bi = de2bi(0:dim_p-1);    % the order of column: (Z,D,Y,W); each ROW of this matrix correspond to each decimal number
p = zeros(dim_p,1);
for i = 1:dim_p
    summand1 = (D==Bi(i,2)).*(W==Bi(i,3)).*(Z==Bi(i,1)).*(Y==1).*(X==Bi(i,4));
    summand2 = (Z==Bi(i,1)).*(W==Bi(i,3)).*(X==Bi(i,4));
    p(i) = sum(summand1)/sum(summand2);
end
%
p_z = zeros(2,dim_w,dim_x); % the propensity score
for i=1:2
    for j=1:dim_w
        for m=1:dim_x
            p_z(i,j,m) = sum((D==1).*(Z==i-1).*(W==j-1).*(X==m-1))/sum((Z==i-1).*(W==j-1).*(X==m-1));
        end
    end
end

%% Defining B
% the left hand side coefficients
B = [];
for l = 1:dim_p
    
    z = Bi(l,1);
    d = Bi(l,2);
    y = 1;
    w = Bi(l,3);
    x = Bi(l,4);
    
    delta = zeros(1,K);
    for m=1:K
        if d == 1
            delta(m) = int(b{m},u,0,p_z(z+1,w+1,x+1));
        elseif d == 0
            delta(m) = int(b{m},u,p_z(z+1,w+1,x+1),1);
        end
    end
    
    B0 = zeros(K,dim_s,dim_x);
    
    for j = 1:dim_s
        if Bi_s(j,2*d+w+1) == y  % in Bi_s, find the column for y(d,w) and choose s (decimal value j) s.t. y(d,w) = y
            B0(:,j,x+1) = 1;
        end
        B0(:,j,x+1) = delta'.*B0(:,j,x+1);
    end
    B0 = reshape(B0,1,[]);
    B(l,:) = B0;
end
%% Restrictions on conditional probabilities
% without rank similarity assumption
dim = size(B,2); % dimension of thetas
zer = zeros(dim,1);
one = zeros(K,dim,dim_x); 

for i=1:K
    for j=1:dim
        if mod(j-i,K)==0 && j<=dim_s*K
            one(i,j,1) = 1;
        elseif mod(j-i,K)==0 && j>dim_s*K
            one(i,j,2) = 1;
        end
    end
end

one = [one(:,:,1);one(:,:,2)];

%% Defining additional assumptions
% Monotonicity
M00 = zeros(dim_x*(K-1),dim);
M01 = zeros(dim_x*(K-1),dim);
M10 = zeros(dim_x*(K-1),dim);
M11 = zeros(dim_x*(K-1),dim);
for x = 1:dim_x
    if x==1
        for i = 1:K-1
            M_0_0 = zeros(K,dim_s);
            M_1_0 = zeros(K,dim_s);
            M_0_1 = zeros(K,dim_s);
            M_1_1 = zeros(K,dim_s);
            for j=1:dim_s
                if Bi_s(j,1) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    M_0_0(i,j) = -1;
                    M_0_0(i+1,j) = 1;
                end
                if Bi_s(j,2) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    M_0_1(i,j) = -1;
                    M_0_1(i+1,j) = 1;
                end
                if Bi_s(j,3) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    M_1_0(i,j) = -1;
                    M_1_0(i+1,j) = 1;
                end
                if Bi_s(j,4) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    M_1_1(i,j) = -1;
                    M_1_1(i+1,j) = 1;
                end
            end
            M_0_0 = reshape(M_0_0,1,[]);
            M_0_1 = reshape(M_0_1,1,[]);
            M_1_0 = reshape(M_1_0,1,[]);
            M_1_1 = reshape(M_1_1,1,[]);
            M00(i,1:dim/2) = M_0_0;
            M01(i,1:dim/2) = M_0_1;
            M10(i,1:dim/2) = M_1_0;
            M11(i,1:dim/2) = M_1_1;
        end
    else
        for i = K:2*(K-1)
            M_0_0 = zeros(K,dim_s);
            M_1_0 = zeros(K,dim_s);
            M_0_1 = zeros(K,dim_s);
            M_1_1 = zeros(K,dim_s);
            for j=1:dim_s
                if Bi_s(j,1) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    M_0_0(i-K+1,j) = -1;
                    M_0_0(i-K+2,j) = 1;
                end
                if Bi_s(j,2) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    M_0_1(i-K+1,j) = -1;
                    M_0_1(i-K+2,j) = 1;
                end
                if Bi_s(j,3) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    M_1_0(i-K+1,j) = -1;
                    M_1_0(i-K+2,j) = 1;
                end
                if Bi_s(j,4) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    M_1_1(i-K+1,j) = -1;
                    M_1_1(i-K+2,j) = 1;
                end
            end
            M_0_0 = reshape(M_0_0,1,[]);
            M_0_1 = reshape(M_0_1,1,[]);
            M_1_0 = reshape(M_1_0,1,[]);
            M_1_1 = reshape(M_1_1,1,[]);
            M00(i,dim/2+1:dim) = M_0_0;
            M01(i,dim/2+1:dim) = M_0_1;
            M10(i,dim/2+1:dim) = M_1_0;
            M11(i,dim/2+1:dim) = M_1_1;
        end
    end
end

M = [M00;M01;M10;M11];

% Concavity
C00 = zeros(dim_x*(K-2),dim);
C01 = zeros(dim_x*(K-2),dim);
C10 = zeros(dim_x*(K-2),dim);
C11 = zeros(dim_x*(K-2),dim);
for x = 1:dim_x
    if x==1
        for i = 1:K-2
            C_0_0 = zeros(K,dim_s);
            C_0_1 = zeros(K,dim_s);
            C_1_0 = zeros(K,dim_s);
            C_1_1 = zeros(K,dim_s);
            for j=1:dim_s
                if Bi_s(j,1) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    C_0_0(i,j) = 1;
                    C_0_0(i+1,j) = -2;
                    C_0_0(i+2,j) = 1;
                end
                if Bi_s(j,2) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    C_0_1(i,j) = 1;
                    C_0_1(i+1,j) = -2;
                    C_0_1(i+2,j) = 1;
                end
                if Bi_s(j,3) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    C_1_0(i,j) = 1;
                    C_1_0(i+1,j) = -2;
                    C_1_0(i+2,j) = 1;
                end
                if Bi_s(j,4) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    C_1_1(i,j) = 1;
                    C_1_1(i+1,j) = -2;
                    C_1_1(i+2,j) = 1;
                end
            end
            C_0_0 = reshape(C_0_0,1,[]);
            C_0_1 = reshape(C_0_1,1,[]);
            C_1_0 = reshape(C_1_0,1,[]);
            C_1_1 = reshape(C_1_1,1,[]);
            C00(i,1:dim/2) = C_0_0;
            C01(i,1:dim/2) = C_0_1;
            C10(i,1:dim/2) = C_1_0;
            C11(i,1:dim/2) = C_1_1;
        end
    else
        for i = K-1:dim_x*(K-2)
            C_0_0 = zeros(K,dim_s);
            C_0_1 = zeros(K,dim_s);
            C_1_0 = zeros(K,dim_s);
            C_1_1 = zeros(K,dim_s);
            for j=1:dim_s
                if Bi_s(j,1) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    C_0_0(i-K+2,j) = 1;
                    C_0_0(i-K+3,j) = -2;
                    C_0_0(i-K+4,j) = 1;
                end
                if Bi_s(j,2) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    C_0_1(i-K+2,j) = 1;
                    C_0_1(i-K+3,j) = -2;
                    C_0_1(i-K+4,j) = 1;
                end
                if Bi_s(j,3) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    C_1_0(i-K+2,j) = 1;
                    C_1_0(i-K+3,j) = -2;
                    C_1_0(i-K+4,j) = 1;
                end
                if Bi_s(j,4) == 1 % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    C_1_1(i-K+2,j) = 1;
                    C_1_1(i-K+3,j) = -2;
                    C_1_1(i-K+4,j) = 1;
                end
            end
            C_0_0 = reshape(C_0_0,1,[]);
            C_0_1 = reshape(C_0_1,1,[]);
            C_1_0 = reshape(C_1_0,1,[]);
            C_1_1 = reshape(C_1_1,1,[]);
            C00(i,dim/2+1:dim) = C_0_0;
            C01(i,dim/2+1:dim) = C_0_1;
            C10(i,dim/2+1:dim) = C_1_0;
            C11(i,dim/2+1:dim) = C_1_1;
        end
    end
end

C = [C00;C01;C10;C11];

%% Determining the RSW direction
[A_R1_old, B_R1_old, H1_old, one_R1_old, dim_R1_old, zer_R1_old] = ChooseRSW(A(1:length(A)/2), B((1:length(p)/2),1:length(A)/2), p(1:length(p)/2), K, dim_s,dim_w,Bi_s);
[A_R2_old, B_R2_old, H2_old, one_R2_old, dim_R2_old, zer_R2_old] = ChooseRSW(A(length(A)/2+1:length(A)), B((length(p)/2+1:length(p)),length(A)/2+1:length(A)), p(length(p)/2+1:length(p)), K, dim_s,dim_w,Bi_s);

H_old = [H1_old,H2_old];
A_R_old = [A_R1_old,A_R2_old];
B_R_old = [B_R1_old,zeros(size(B_R2_old));zeros(size(B_R1_old)),B_R2_old];
one_R_old = [one_R1_old,zeros(size(one_R2_old));zeros(size(one_R1_old)),one_R2_old];
zer_R_old = [zer_R1_old;zer_R2_old];
dim_R_old = dim_R1_old+dim_R2_old;

for i=1:size(M,1)
    temp = M(i,:);
    M_R_old(i,:) = temp(H_old~=-1);
end

for i=1:size(C,1)
    temp = C(i,:);
    C_R_old(i,:) = temp(H_old~=-1);
end

%% Determining the RSW new direction
[A_R1, B_R1, H1, one_R1, dim_R1, zer_R1] = ChooseRSW_new(A(1:length(A)/2), B((1:length(p)/2),1:length(A)/2), p(1:length(p)/2), K, dim_s,dim_w,Bi_s);
[A_R2, B_R2, H2, one_R2, dim_R2, zer_R2] = ChooseRSW_new(A(length(A)/2+1:length(A)), B((length(p)/2+1:length(p)),length(A)/2+1:length(A)), p(length(p)/2+1:length(p)), K, dim_s,dim_w,Bi_s);

H = [H1,H2];
A_R = [A_R1,A_R2];
B_R = [B_R1,zeros(size(B_R2));zeros(size(B_R1)),B_R2];
one_R = [one_R1,zeros(size(one_R2));zeros(size(one_R1)),one_R2];
zer_R = [zer_R1;zer_R2];
dim_R = dim_R1+dim_R2;

for i=1:size(M,1)
    temp = M(i,:);
    M_R(i,:) = temp(H~=-1);
end

for i=1:size(C,1)
    temp = C(i,:);
    C_R(i,:) = temp(H~=-1);
end

%% Determining U0 direction
G_M1 = ChooseU0(A(1:length(A)/2), B((1:length(p)/2),1:length(A)/2), p(1:length(p)/2), K, dim_s,dim_w,Bi_s);
G_M2 = ChooseU0(A(length(A)/2+1:length(A)), B((length(p)/2+1:length(p)),length(A)/2+1:length(A)), p(length(p)/2+1:length(p)), K, dim_s,dim_w,Bi_s);
G_M=[G_M1,zeros(size(G_M1,1),size(G_M1,2));zeros(size(G_M2,1),size(G_M2,2)),G_M2];
%% CVX - ATE
% create the tuning parameter base
cvx_clear
cvx_begin
variable theta(dim)
dual variables lambdaEq2 lambdaIneq

minimize(norm(B*theta - p))
subject to
lambdaEq2: one * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer
cvx_end

base = cvx_optval;

% upper bound
cvx_clear
cvx_begin
variable theta(dim)
dual variables lambdaEq lambdaEq2 lambdaIneq

maximize( A * theta )
subject to
lambdaEq: norm(B * theta - p) <= base + 2*(1e-3)
lambdaEq2: one * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer
cvx_end

UB_ATE = cvx_optval;

% lower bound
cvx_clear
cvx_begin
variable theta(dim)
dual variables lambdaEq lambdaEq2 lambdaIneq

minimize(A * theta)
subject to
lambdaEq: norm(B * theta - p) <= base + 2*(1e-3)
lambdaEq2: one * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer

cvx_end
LB_ATE = cvx_optval;

%% CVX - ATE & RSW
% tuning
cvx_clear
cvx_begin
variable theta(dim_R_old)
dual variables lambdaEq2 lambdaIneq  

minimize( norm(B_R_old * theta - p) )
subject to
lambdaEq2: one_R_old * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer_R_old
cvx_end

base_R_old = cvx_optval;

% upper bound
cvx_clear
cvx_begin
variable theta(dim_R_old)
dual variables lambdaEq lambdaEq2 lambdaIneq

maximize( A_R_old * theta )
subject to
lambdaEq: norm(B_R_old * theta - p) <=  base_R_old + 2*(1e-3)
lambdaEq2: one_R_old * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer_R_old
cvx_end

UB_ATE_R_old = cvx_optval;

% lower bound
cvx_clear
cvx_begin
variable theta(dim_R_old)
dual variables lambdaEq lambdaEq2 lambdaIneq

minimize(A_R_old * theta)
subject to
lambdaEq: norm(B_R_old * theta - p) <=  base_R_old + 2*(1e-3)
lambdaEq2: one_R_old * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer_R_old
cvx_end
LB_ATE_R_old = cvx_optval;

%% CVX - ATE WITH U0
% tuning
cvx_clear
cvx_begin
variable theta(dim)
dual variables lambdaEq2 lambdaIneq lambdaIneq2

minimize( norm(B * theta-p) )
subject to
lambdaEq2: one * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer
lambdaIneq2: G_M*theta>=zeros(size(G_M,1),1)
cvx_end

base_0 = cvx_optval; 

% upper bound
cvx_clear
cvx_begin
variable theta(dim)
dual variables lambdaEq lambdaEq2 lambdaIneq lambdaIneq2

maximize( A * theta )
subject to
lambdaEq: norm(B * theta - p) <=base_0 + 2*(1e-3)
lambdaEq2: one * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer
lambdaIneq2: G_M*theta>=zeros(size(G_M,1),1)
cvx_end

UB_ATE0 = cvx_optval; 

% lower bound
cvx_clear
cvx_begin
variable theta(dim)
dual variables lambdaEq lambdaEq2 lambdaIneq lambdaIneq2

minimize(A * theta)
subject to
lambdaEq: norm(B * theta - p) <=base_0 + 2*(1e-3)
lambdaEq2: one * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer
lambdaIneq2: G_M*theta>=zeros(size(G_M,1),1)

cvx_end
LB_ATE0 = cvx_optval;
%% CVX - ATE & RSW new
% tuning
cvx_clear
cvx_begin
variable theta(dim_R)
dual variables lambdaEq2 lambdaIneq  

minimize( norm(B_R * theta-p) )
subject to
lambdaEq2: one_R * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer_R
cvx_end

base_R = cvx_optval;

% upper bound
cvx_clear
cvx_begin
variable theta(dim_R)
dual variables lambdaEq lambdaEq2 lambdaIneq 

maximize( A_R * theta )
subject to
lambdaEq: norm(B_R * theta - p) <=  base_R+2*(1e-3)
lambdaEq2: one_R * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer_R
cvx_end

UB_ATE_R = cvx_optval;

% lower bound
cvx_clear
cvx_begin
variable theta(dim_R)

dual variables lambdaEq lambdaEq2 lambdaIneq 

minimize(A_R * theta)
subject to
lambdaEq: norm(B_R * theta - p) <=  base_R+2*(1e-3)
lambdaEq2: one_R * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer_R
cvx_end

LB_ATE_R = cvx_optval;

%% CVX - ATE RS shape restriction
% tuning
cvx_clear
cvx_begin
variable theta(dim_R)
dual variables lambdaEq2 lambdaIneq lambdaIneq2 lambdaIneq3

minimize( norm(B_R * theta - p) )
subject to
lambdaEq2: one_R * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer_R
lambdaIneq2: M_R * theta >= zeros(8*(K-1),1)
lambdaIneq3: C_R * theta <= zeros(8*(K-2),1)
cvx_end

base_R2 = cvx_optval;

% upper bound
cvx_clear
cvx_begin
variable theta(dim_R)
dual variables lambdaEq lambdaEq2 lambdaIneq lambdaIneq2 lambdaIneq3

maximize( A_R * theta )
subject to
lambdaEq: norm(B_R * theta - p)<=base_R2+2*(1e-3)
lambdaEq2: one_R * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer_R
lambdaIneq2: M_R * theta >= zeros(8*(K-1),1)
lambdaIneq3: C_R * theta <= zeros(8*(K-2),1)
cvx_end

UB_ATE_R2 = cvx_optval;

% lower bound
cvx_clear
cvx_begin
variable theta(dim_R)
dual variables lambdaEq lambdaEq2 lambdaIneq lambdaIneq2 lambdaIneq3

minimize(A_R * theta)
subject to
lambdaEq: norm(B_R * theta - p)<=base_R2+2*(1e-3)
lambdaEq2: one_R * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer_R
lambdaIneq2: M_R * theta >= zeros(8*(K-1),1)
lambdaIneq3: C_R * theta <= zeros(8*(K-2),1)
cvx_end

LB_ATE_R2 = cvx_optval;

%% CVX - ATE shape restriction
% tuning
cvx_clear
cvx_begin
variable theta(dim)
dual variables lambdaEq2 lambdaIneq lambdaIneq2 lambdaIneq3

minimize(norm(B*theta-p))
subject to
lambdaEq2: one * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer
lambdaIneq2: M * theta >= zeros(8*(K-1),1)
lambdaIneq3: C * theta <= zeros(8*(K-2),1)
cvx_end

base_S = cvx_optval;

% upper bound
cvx_clear
cvx_begin
variable theta(dim)
dual variables lambdaEq lambdaEq2 lambdaIneq lambdaIneq2 lambdaIneq3

maximize( A * theta )
subject to
lambdaEq: norm(B * theta - p)<=base_S+2*(1e-3)
lambdaEq2: one * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer
lambdaIneq2: M * theta >= zeros(8*(K-1),1)
lambdaIneq3: C * theta <= zeros(8*(K-2),1)
cvx_end

UB_ATE_S = cvx_optval;

% lower bound
cvx_clear
cvx_begin
variable theta(dim)

dual variables lambdaEq lambdaEq2 lambdaIneq lambdaIneq2 lambdaIneq3

minimize(A * theta)
subject to
lambdaEq: norm(B * theta - p)<=base_S+2*(1e-3)
lambdaEq2: one * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer
lambdaIneq2: M * theta >= zeros(8*(K-1),1)
lambdaIneq3: C * theta <= zeros(8*(K-2),1)
cvx_end

LB_ATE_S = cvx_optval;

%% without W
%% Defining A, A is for ATE
dim_s = (2^2); % number of maps for each w
dim_x = 2; % dimension of x

s = (1:dim_s)';
Bi_s = de2bi(s-1); % value of y(0), y(1) for each x
my_d = 1;
my_y = 1;

P_X = null(2,1);
for i=1:2
    P_X(i) = sum((X==i-1))/N;
end

gam0_ATE = zeros(K,1);
gam1_ATE = zeros(K,1);
for i=1:K
    syms u
    gam0_ATE(i) = -int(b{i},u,0,1);
    gam1_ATE(i) = int(b{i},u,0,1);
end

A_0 = zeros(K,dim_s,dim_x);
A_1 = zeros(K,dim_s,dim_x);

for i = 1:dim_x
    for j = 1:dim_s
        if Bi_s(j,bi2de(my_d)) == my_y  % in Bi_s, for each x, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
            A_0(:,j,i) = P_X(i);
        end
        if Bi_s(j,bi2de(my_d)+1) == my_y  % in Bi_s, for each x, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
            A_1(:,j,i) = P_X(i);
        end
        A_0(:,j,i) = A_0(:,j,i).*gam0_ATE;
        A_1(:,j,i) = A_1(:,j,i).*gam1_ATE;
    end
end

A = reshape(A_0,1,[])+reshape(A_1,1,[]);

%% Defining p
dim_p = 2^(3);    % number of possibility in (Z,D,Y,X)
Bi = de2bi(0:dim_p-1);    % the order of column: (Z,D,Y,X); each ROW of this matrix correspond to each decimal number
p = zeros(dim_p,1);
for i = 1:dim_p
    summand1 = (D==Bi(i,2)).*(X==Bi(i,3)).*(Z==Bi(i,1)).*(Y==1);
    summand2 = (Z==Bi(i,1)).*(X==Bi(i,3));
    p(i) = sum(summand1)/sum(summand2);
end

p_z = null(2,1); % propesntiy score, conditional on X
for j=1:dim_x
    for i=1:2
        p_z(i,j) = sum((D==1).*(Z==i-1).*(X==j-1))/sum((Z==i-1).*(X==j-1));
    end
end

%% Defining B
B = [];
B_R = [];
for l = 1:dim_p
    % focus on p(l) and find corresponding (d,y,z) in p(d,y|z)
    d = Bi(l,2);
    y = 1;
    z = Bi(l,1);
    x = Bi(l,3);
    delta = null(1,K);
    for m=1:K
        if d == 1
            delta(m) = int(b{m},u,0,p_z(z+1,x+1));
        elseif d == 0
            delta(m) = int(b{m},u,p_z(z+1,x+1),1);
        end
    end
    
    B0 = zeros(K,dim_s,dim_x);
    
    for j = 1:dim_s
        if Bi_s(j,bi2de(d)+1) == y
            B0(:,j,x+1) = 1;
        end
        B0(:,j,x+1) = (B0(:,j,x+1)'.*delta)';
    end
    B0 = reshape(B0,1,[]);
    B(l,:) = B0;
end

%% Restrictions on conditional probabilities
% The one without rank similarity assn
dim = size(B,2);
zer = zeros(dim,1);

one = zeros(K,dim,dim_x);

for i=1:K
    for j=1:dim
        if mod(j-i,K)==0 && j<=dim_s*K
            one(i,j,1) = 1;
        elseif mod(j-i,K)==0 && j>dim_s*K
            one(i,j,2) = 1;
        end
    end
end

one = [one(:,:,1);one(:,:,2)];

%% Defining additional assumptions
% Monotonicity
M0 = zeros(dim_x*(K-1),dim);
M1 = zeros(dim_x*(K-1),dim);

for x = 1:dim_x
    if x==1
        for i = 1:K-1
            M_0 = zeros(K,dim_s);
            M_1 = zeros(K,dim_s);
            for j=1:dim_s
                if Bi_s(j,bi2de(my_d)) == my_y % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    M_0(i,j) = -1;
                    M_0(i+1,j) = 1;
                end
                if Bi_s(j,bi2de(my_d)+1) == my_y % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    M_1(i,j) = -1;
                    M_1(i+1,j) = 1;
                end
            end
            M_0 = reshape(M_0,1,[]);
            M_1 = reshape(M_1,1,[]);
            M0(i,1:dim/2) = M_0;
            M1(i,1:dim/2) = M_1;
        end
    else
        for i = K:2*(K-1)
            M_0 = zeros(K,dim_s);
            M_1 = zeros(K,dim_s);
            for j=1:dim_s
                if Bi_s(j,bi2de(my_d)) == my_y % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    M_0(i-K+1,j) = -1;
                    M_0(i-K+2,j) = 1;
                end
                if Bi_s(j,bi2de(my_d)+1) == my_y % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    M_1(i-K+1,j) = -1;
                    M_1(i-K+2,j) = 1;
                end
            end
            M_0 = reshape(M_0,1,[]);
            M_1 = reshape(M_1,1,[]);
            M0(i,dim/2+1:dim) = M_0;
            M1(i,dim/2+1:dim) = M_1;
        end
    end
end

M = [M0;M1];

% Concavity
C0 = zeros(dim_x*(K-2),dim);
C1 = zeros(dim_x*(K-2),dim);
for x = 1:dim_x
    if x==1
        for i = 1:K-2
            C_0 = zeros(K,dim_s);
            C_1 = zeros(K,dim_s);
            for j=1:dim_s
                if Bi_s(j,bi2de(my_d)) == my_y % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    C_0(i,j) = 1;
                    C_0(i+1,j) = -2;
                    C_0(i+2,j) = 1;
                end
                if Bi_s(j,bi2de(my_d)+1) == my_y % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    C_1(i,j) = 1;
                    C_1(i+1,j) = -2;
                    C_1(i+2,j) = 1;
                end
            end
            C_0 = reshape(C_0,1,[]);
            C0(i,1:dim/2) = C_0;
            C_1 = reshape(C_1,1,[]);
            C1(i,1:dim/2) = C_1;
        end
    else
        for i = K-1:dim_x*(K-2)
            C_0 = zeros(K,dim_s);
            C_1 = zeros(K,dim_s);
            for j=1:dim_s
                if Bi_s(j,bi2de(my_d)) == my_y % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    C_0(i-K+2,j) = 1;
                    C_0(i-K+3,j) = -2;
                    C_0(i-K+4,j) = 1;
                end
                if Bi_s(j,bi2de(my_d)+1) == my_y % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    C_1(i-K+2,j) = 1;
                    C_1(i-K+3,j) = -2;
                    C_1(i-K+4,j) = 1;
                end
            end
            C_0 = reshape(C_0,1,[]);
            C0(i,dim/2+1:dim) = C_0;
            C_1 = reshape(C_1,1,[]);
            C1(i,dim/2+1:dim) = C_1;
        end
    end
end

C = [C0;C1];
%% Determining the RS direction
[A_R1, B_R1, H1, one_R1, dim_R1, zer_R1] = ChooseRS(A(1:length(A)/2), B((1:length(p)/2),1:length(A)/2), p(1:length(p)/2), K);
[A_R2, B_R2, H2, one_R2, dim_R2, zer_R2] = ChooseRS(A(length(A)/2+1:length(A)), B((length(p)/2+1:length(p)),length(A)/2+1:length(A)), p(length(p)/2+1:length(p)), K);

A_R = [A_R1,A_R2];
B_R = [B_R1,zeros(size(B_R2));zeros(size(B_R1)),B_R2];
one_R = [one_R1,zeros(size(one_R2));zeros(size(one_R1)),one_R2];
zer_R = [zer_R1;zer_R2];
dim_R = dim_R1+dim_R2;
H = [H1,H2];

M_R=[];
C_R=[];

for i=1:size(M,1)
    temp = M(i,:);
    M_R(i,:) = temp(H~=-1);
end

for i=1:size(C,1)
    temp = C(i,:);
    C_R(i,:) = temp(H~=-1);
end

%% CVX - ATE
% tuning parameter
cvx_clear
cvx_begin
variable theta(dim)
dual variables lambdaEq2 lambdaIneq

minimize( norm(B*theta-p) )
subject to
lambdaEq2: one * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer
cvx_end

base_ATE3 = cvx_optval;


% upper bound
cvx_clear
cvx_begin
variable theta(dim)
dual variables lambdaEq lambdaEq2 lambdaIneq

maximize( A * theta )
subject to
lambdaEq: norm(B * theta - p) <=  base_ATE3 + 2*(1e-3)
lambdaEq2: one * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer
cvx_end

UB_ATE3 = cvx_optval;

% lower bound
cvx_clear
cvx_begin
variable theta(dim)
dual variables lambdaEq lambdaEq2 lambdaIneq

minimize(A * theta)
subject to
lambdaEq: norm(B * theta - p) <=  base_ATE3 + 2*(1e-3)
lambdaEq2: one * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer
cvx_end

LB_ATE3 = cvx_optval;

%% CVX - ATE RS
% tuning
cvx_clear
cvx_begin
variable theta(dim_R)
dual variables lambdaEq2 lambdaIneq

minimize( norm(B_R*theta-p) )
subject to
lambdaEq2: one_R * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer_R
cvx_end

base_ATE_R3 = cvx_optval;

% upper bound
cvx_clear
cvx_begin
variable theta(dim_R)
dual variables lambdaEq lambdaEq2 lambdaIneq

maximize( A_R * theta )
subject to
lambdaEq: norm(B_R * theta - p) <= base_ATE_R3+2*(1e-3)
lambdaEq2: one_R * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer_R
cvx_end

UB_ATE_R3 = cvx_optval;

% lower bound
cvx_clear
cvx_begin
variable theta(dim_R)
dual variables lambdaEq lambdaEq2 lambdaIneq

minimize(A_R * theta)
subject to
lambdaEq: norm(B_R * theta - p) <= base_ATE_R3+2*(1e-3)
lambdaEq2: one_R * theta == ones(K*dim_x,1)
lambdaIneq: theta >= zer_R
cvx_end

LB_ATE_R3 = cvx_optval;

%% Plot for ATE: first figure
x = 0.01:0.01:0.99;
y = double((1-p_W)*(1-p_X)*(0.02*int(bern(4,0,u),u,0,1)+0.02*int(bern(4,1,u),u,0,1)+0.02*int(bern(4,2,u),u,0,1)+0.02*int(bern(4,3,u),u,0,1)+0.02*int(bern(4,4,u),u,0,1))+...
    p_W*(1-p_X)*(0.8*int(bern(4,0,u),u,0,1)+0.8*int(bern(4,1,u),u,0,1)+0.8*int(bern(4,2,u),u,0,1)+0.8*int(bern(4,3,u),u,0,1)+0.8*int(bern(4,4,u),u,0,1))+...
    (1-p_W)*p_X*(0.01*int(bern(4,0,u),u,0,1)+0.01*int(bern(4,1,u),u,0,1)+0.01*int(bern(4,2,u),u,0,1)+0.01*int(bern(4,3,u),u,0,1)+0.01*int(bern(4,4,u),u,0,1))+...
    p_W*p_X*(0.9*int(bern(4,0,u),u,0,1)+0.9*int(bern(4,1,u),u,0,1)+0.9*int(bern(4,2,u),u,0,1)+0.9*int(bern(4,3,u),u,0,1)+0.9*int(bern(4,4,u),u,0,1)))*ones(1,99);
%y = ATE*ones(1,99);
x1 = LB_ATE3*ones(1,99); % No assn, without W LB
x2 = UB_ATE3*ones(1,99); % No assn, without W UB
x3 = LB_ATE_R3*ones(1,99); % U0, without W LB
x4 = UB_ATE_R3*ones(1,99); % U0, without W UB
y1 = LB_ATE*ones(1,99); % with W LB
y2 = UB_ATE*ones(1,99); % with W UB
y3 = LB_ATE_R*ones(1,99); % RS+W LB
y4 = UB_ATE_R*ones(1,99); % RS+W UB
y5 = LB_ATE_S*ones(1,99); % M+C+W LB
y6 = UB_ATE_S*ones(1,99); % M+C+W UB
y7 = LB_ATE0*ones(1,99); % U0 LB
y8 = UB_ATE0*ones(1,99); % U0 UB
y9 = LB_ATE_R_old*ones(1,99); % RS old+W LB
y10 = UB_ATE_R_old*ones(1,99); % RS old+W UB

figure('Name','ATE: first figure');
plot(x,y,'r','linew',2)
hold on
% No assn, without W
plot (x,x1,'-o','color',[0 1 1]*1,'linew',1.5,'MarkerIndices',1:5:100) %LB
plot (x,x2,'-o','color',[0 1 1]*1,'linew',1.5,'HandleVisibility','off','MarkerIndices',1:5:100) %UB
% with W
plot (x,y1,':','color',[0 1 1]*0.4,'linew',2) %LB
plot (x,y2,':','color',[0 1 1]*0.4,'linew',2,'HandleVisibility','off') %UB
% U0, without W
plot (x,x3,'-+','color',[0.4940 0.1840 0.5560],'linew',1.5,'MarkerIndices',1:5:100)%LB
plot (x,x4,'-+','color',[0.4940 0.1840 0.5560],'linew',1.5,'HandleVisibility','off','MarkerIndices',1:5:100)%UB
% U0(or U, same result)+W
plot (x,y7,'--','color',[0 1 0],'linew',1.5)%LB
plot (x,y8,'--','color',[0 1 0],'linew',1.5,'HandleVisibility','off')%UB
% M+C+W
plot (x,y5,'-x','color',[255/255 0.5 255/255],'linew',1.5,'MarkerIndices',1:5:100) %LB
plot (x,y6,'-x','color',[255/255 0.5 255/255],'linew',1.5,'HandleVisibility','off','MarkerIndices',1:5:100)%UB

hold off
legend('True ATE', 'Bounds on ATE: No Assumption','Bounds on ATE: W','ATE: U0','Bounds on ATE: W+U0','Bounds on ATE: W+M+C','Location','bestoutside','orientation','horizontal','Fontsize',11)
title('Bounds on ATE')
xlabel('u \in [0,1]')  
lgd = legend;
lgd.NumColumns = 2;
set(0,'defaultfigurecolor','w') 

