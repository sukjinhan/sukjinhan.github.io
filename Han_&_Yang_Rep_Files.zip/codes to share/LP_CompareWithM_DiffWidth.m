clear all;
%% DGP
for i=1:4
    N = 200000;        % sample size
    rng(111);
    
    nu = 0.2;
    sigma{i} = eye((2*i+1)*(i<=2)+(2*i+3)*(i==3)+21*(i==4));
    sigma{i}(sigma{i}==0)=0.5;
    cop_mat = copularnd('Gaussian',sigma{i},N);
    
    K = 51;
    u_Z = rand(N,1);
    
    U = cop_mat(:,size(cop_mat,2));
    e_0 = cop_mat(:,1:(size(cop_mat,2)-1)/2);
    e_1 = cop_mat(:,(size(cop_mat,2)-1)/2+1:(size(cop_mat,2)-1));
    
    %Group 1: Z takes 2 values
    p_Z = 0.3;      % P(Z=1)
    Z_index{i,1} =  u_Z >=p_Z;
    
    % Group 2: Z takes 3 values
    %p_Z1 = 0.3;
    %p_Z2 = 0.6;
    Z_index{i,2} = ((u_Z>=0.3)+(u_Z>=0.6));
    
    % Group 3: Z = 0,0.25,...,1
    %p_Z1 = 0.2;
    %p_Z2 = 0.4;
    %p_Z3 = 0.6;
    %p_Z4 = 0.8;
    Z_index{i,3} = ((u_Z>=0.2)+(u_Z>=0.4)+(u_Z>=0.6)+(u_Z>=0.8));
    
    for o=1:3
        D_index{i,o} = (0.1+nu*Z_index{i,o} >= U);
        
        m_0 = 0.06*bern(2,0,U) + 0.04*bern(2,1,U) + 0.03*bern(2,2,U);  % m_0 function
        m_1 = 0.75*bern(2,0,U) + 0.5*bern(2,1,U) + 0.25*bern(2,2,U);  % m_1 function
        
        Y_0 = zeros(N,1);
        Y_1 = zeros(N,1);
        
        for j=1:size(e_0,2)
            Y_0 = Y_0+ ((i==1)+(i==2)*0.5+(i==3)*0.25+(i==4)*0.1)*(m_0 >=e_0(:,j));
        end
        for j=1:size(e_1,2)
            Y_1 = Y_1+ ((i==1)+(i==2)*0.5+(i==3)*0.25+(i==4)*0.1)*(m_1 >=e_1(:,j));
        end
        
        Y_index{i,o} = D_index{i,o}.*Y_1 + (1-D_index{i,o}).*Y_0;
        True{i,o} =  mean(Y_1-Y_0);
    end
end
%% Run the LP process -- Our approach
for o_y=1:4
    for o_z=1:3
        Z = Z_index{o_y,o_z};
        D = D_index{o_y,o_z};
        Y = Y_index{o_y,o_z};
        
        % Basis function
        b = cell(K,1);
        for i=1:K
            b{i} = @(u)bern(K-1,i-1,u);
        end
        
        % Defining A
        YGroup = findgroups(Y);
        Y_supp = splitapply(@mean, Y, YGroup); %find the support for Y
        
        DGroup = findgroups(D);
        D_supp = splitapply(@mean, D, DGroup); %find the support for D
        
        dim_s = (length(Y_supp))^length(D_supp);
        Bi_s = nan(dim_s,2);
        Bi_s(:,1) = repmat(Y_supp,length(Y_supp),1);
        
        for i=1:length(Y_supp)
            Bi_s(length(Y_supp)*(i-1)+1:length(Y_supp)*i,2) = repmat(Y_supp(i),length(Y_supp),1);
        end
        
        % A is for ATE
        my_d = 1;
        
        gam0_ATE = zeros(K,1);
        gam1_ATE = zeros(K,1);
        for i=1:K
            syms u
            gam0_ATE(i) = -int(b{i},u,0,1);
            gam1_ATE(i) = int(b{i},u,0,1);
        end
        
        A_0 = zeros(K,dim_s);
        A_1 = zeros(K,dim_s);
        
        for j = 1:dim_s
            for h = 1:length(Y_supp)
                if Bi_s(j,bi2de(my_d)) == Y_supp(h)  % in Bi_s, find the column for y(0) and choose s s.t. y(0) = 1
                    A_0(:,j) = Y_supp(h);
                end
                if Bi_s(j,bi2de(my_d)+1) == Y_supp(h)  % in Bi_s, find the column for y(1) and choose s s.t. y(1) = 1
                    A_1(:,j) = Y_supp(h);
                end
            end
            A_0(:,j) = A_0(:,j).*gam0_ATE;
            A_1(:,j) = A_1(:,j).*gam1_ATE;
        end
        
        A_0 = reshape(A_0,1,[]);
        A_1 = reshape(A_1,1,[]);
        A = A_0+A_1;
        
        % Defining p
        ZGroup = findgroups(Z);
        Z_supp = splitapply(@mean, Z, ZGroup); %find the support for Z
        
        Bi_temp = de2bi(0:2^1-1);    % the order of column: (Z,D,Y,W); each ROW of this matrix correspond to each decimal number
        Bi = [];
        for i=1:size(Z_supp,1)
            Bi=[Bi;[Z_supp(i)*ones(size(Bi_temp,1),1),Bi_temp]];
        end
        Bi = sortrows(Bi,size(Bi,2));
        Bi_new = [];
        for i=1:length(Y_supp)
            Bi_new = [Bi_new;Bi,Y_supp(i)*ones(size(Bi,1),1)];
        end
        Bi = Bi_new;
        
        dim_p = length(Z_supp)*length(D_supp)*length(Y_supp);    % number of possibility in (Z,D)
        p = zeros(dim_p,1);
        % p is p(y,d|z) from data
        
        for i = 1:dim_p
            summand1 = (D==Bi(i,2)).*(abs(Z-round(Bi(i,1),3))<=0.0001).*(abs(Y-round(Bi(i,3),3))<=0.0001);
            summand2 = (abs(Z-round(Bi(i,1),3))<=0.0001);
            p(i) = sum(summand1)/sum(summand2);
        end
        
        p_z = null(size(Z_supp,1),1); % the propensity score
        for i=1:size(Z_supp,1)
            p_z(i) = sum((D==1).*(abs(Z-Z_supp(i))<=0.0001))/sum((abs(Z-Z_supp(i))<=0.0001));
        end
        
        % Defining B
        % the left hand side coefficients
        B = [];
        for l = 1:dim_p
            % focus on p(l) and find corresponding (d,y,z) in p(d,y|z)
            d = Bi(l,2);
            y = Bi(l,3);
            z = Bi(l,1);
            delta = null(1,K);
            for m=1:K
                if d == 1
                    delta(m) = int(b{m},u,0,p_z(find(abs(Z_supp-z)<=0.0001,1)));
                elseif d == 0
                    delta(m) = int(b{m},u,p_z(find(abs(Z_supp-z)<=0.0001,1)),1);
                end
            end
            
            B0 = zeros(K,dim_s);
            
            for j = 1:dim_s
                if Bi_s(j,bi2de(d)+1) == y  % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                    B0(:,j) = 1;
                end
                B0(:,j) = (B0(:,j)'.*delta)';
            end
            B0 = reshape(B0,1,[]);
            B(l,:) = B0;
        end
        
        % Restrictions on conditional probabilities
        % The one without rank similarity assn
        dim = size(B,2);
        zer = zeros(dim,1);
        
        one = null(K,dim);
        for i=1:K
            for j=1:dim_N
                if mod(j-i,K)==0
                    one(i,j) = 1;
                else
                    one(i,j) = 0;
                end
            end
        end
        
        % CVX - No Assumption
        % first determine the smallest error
        cvx_clear
        cvx_begin
        variable theta(dim)
        dual variables lambdaIneq lambdaIneq2
        minimize( norm(B * theta-p) )
        subject to
        lambdaIneq: one * theta == ones(K,1);
        lambdaIneq2: theta >= zer;
        cvx_end
        tuning = cvx_optval;
        
        % upper bound
        cvx_clear
        cvx_begin
        variable theta(dim_N)
        dual variables lambdaEq lambdaEq2 lambdaIneq
        
        maximize( N_A * theta )
        subject to
        lambdaEq: norm(N_B * theta - p)<=tuning + (1e-4)*tuning
        lambdaEq2: one_N * theta == ones(K,1)
        lambdaIneq: theta >= zer_N
        cvx_end
        
        UB{o_y,o_z} = cvx_optval;
        
        % lower bound
        cvx_clear
        cvx_begin
        variable theta(dim_N)
        dual variables lambdaEq lambdaEq2 lambdaIneq
        
        minimize( N_A * theta )
        subject to
        lambdaEq: norm(N_B * theta - p)<=tuning + (1e-4)*tuning
        lambdaEq2: one_N * theta == ones(K,1)
        lambdaIneq: theta >= zer_N
        cvx_end
        
        LB{o_y,o_z} = cvx_optval;
        
    end
end
%% Run the LP process -- Mogstad's approach
for o_y=1:4
    for o_z=1:3
        Z = Z_index{o_y,o_z};
        D = D_index{o_y,o_z};
        Y = Y_index{o_y,o_z};
        
        % Basis Function
        b = cell(K,1);
        for i=1:K
            b{i} = @(u)bern(K-1,i-1,u);
        end
        
        % Linear Programming Inputs
        UncondInputs.labels = {'d=0,z=0', 'd=0,z=1', ...
            'd=1,z=0', 'd=1,z=1'};
        covariance =  @(x,y) [1,0]*cov(x,y)*[0,1]';
        ZGroup = findgroups(Z);
        Z_supp = splitapply(@mean, Z, ZGroup);
        
        DGroup = findgroups(D);
        D_supp = splitapply(@mean, D, DGroup);
        
        prop = splitapply(@mean, D, ZGroup);
        Propensity = prop(ZGroup);
        
        % Caluculate the s(d,x,z) functions
        UncondInputs.s = cell(length(Z_supp)*length(D_supp),1);
        
        for i=1:length(Z_supp)
            for j=1:length(D_supp)
                UncondInputs.s{i+length(Z_supp)*(j-1)} = @(d,z)(abs(z-Z_supp(i))<=0.0001)*(d==D_supp(j));
            end
        end
        
        % Caluculate the weights
        UncondInputs.M0Parameter = cell(length(Z_supp)*length(D_supp),1);
        UncondInputs.M1Parameter = cell(length(Z_supp)*length(D_supp),1);
        
        PZ = nan(1,size(Z_supp,1));
        
        for j=1:size(Z_supp,1)
            PZ(1,j)=sum(abs(Z-Z_supp(j))<=0.0001)/N;
        end
        
        for i = 1:1:length(Z_supp)*length(D_supp)
            UncondInputs.M0Parameter{i} = nan(1,K);
            UncondInputs.M1Parameter{i} = nan(1,K);
            syms z u;
            for k = 1:1:K
                UncondInputs.M0ParameterFn{i,k} = @(z)...
                    UncondInputs.s{i}(0,z)*int(b{k}(u),u,...
                    Propensity(find(abs(Z-z)<0.0001,1)),1);
                UncondInputs.M1ParameterFn{i,k} = @(z)...
                    UncondInputs.s{i}(1,z)*int(b{k}(u),u,0,...
                    Propensity(find(abs(Z-z)<0.0001,1)));
                
                UncondInputs.M0Parameter{i}(k) = 0;
                for h=1:size(Z_supp,1)
                    UncondInputs.M0Parameter{i}(k) = ...
                        UncondInputs.M0Parameter{i}(k) + UncondInputs.M0ParameterFn{i,k}(Z_supp(h))*PZ(1,h);
                end
                UncondInputs.M1Parameter{i}(k) = 0;
                for h=1:size(Z_supp,1)
                    UncondInputs.M1Parameter{i}(k) = ...
                        UncondInputs.M1Parameter{i}(k) + UncondInputs.M1ParameterFn{i,k}(Z_supp(h))*PZ(1,h);
                end
            end
        end
        
        % Constraints in LP
        beq = zeros(length(Z_supp)*length(D_supp),1);
        for i=1:length(Z_supp)
            for j=1:length(D_supp)
                beq(i+length(Z_supp)*(j-1)) = mean(Y(D==D_supp(j)&abs(Z-Z_supp(i))<0.0001)*sum(D==D_supp(j)& abs(Z-Z_supp(i))<0.0001))/N;
            end
        end
        
        % Linear Programming
        % ATE
        w1{1} = @(u,z) 1;
        w0{1} = @(u,z) -1;
        
        for k = 1:1:K
            Obj.M0ParameterFn{1,k} = @(z)int(w0{1}(u,z)*b{k}(u),...
                u,0,1);
            Obj.M0Parameter(1,k) = 0;
            for h=1:size(Z_supp,1)
                Obj.M0Parameter(1,k) = Obj.M0Parameter(1,k) + Obj.M0ParameterFn{1,k}(Z_supp(h))*PZ(1,h);
            end
        end
        
        for k = 1:1:K
            Obj.M1ParameterFn{1,k} = @(z)int(w1{1}(u,z)*b{k}(u),...
                u,0,1);
            Obj.M1Parameter(1,k) = 0;
            for h=1:size(Z_supp,1)
                Obj.M1Parameter(1,k) = Obj.M1Parameter(1,k) + Obj.M1ParameterFn{1,k}(Z_supp(h))*PZ(1,h);
            end
        end
        
        f = double([Obj.M0Parameter, Obj.M1Parameter]);
        Aeq0 = UncondInputs.M0Parameter{1}';
        Aeq1 = UncondInputs.M1Parameter{1}';
        for i=2:length(UncondInputs.M0Parameter)
            Aeq0 = [Aeq0, UncondInputs.M0Parameter{i}'];
            Aeq1 = [Aeq1, UncondInputs.M1Parameter{i}'];
        end
        
        Aeq = [Aeq0',Aeq1'];
        %beq = Aeq*True;
        lb = min(Y)*ones(size(f,2),1);
        ub = max(Y)*ones(size(f,2),1);
        
        % CVX - No Assumption
        % Tuning
        cvx_solver sedumi
        cvx_clear
        cvx_begin
        variable theta(size(f,2))
        dual variables lambdaEq lambdaEq2 lambdaIneq
        
        minimize( norm(Aeq * theta - beq) )
        subject to
        lambdaEq2: theta >= lb
        lambdaIneq: theta <= ub
        cvx_end
        tuning = cvx_optval;
        
        % upper bound
        cvx_clear
        cvx_begin
        variable theta(size(f,2))
        dual variables lambdaEq lambdaEq2 lambdaIneq
        
        maximize( f * theta )
        subject to
        lambdaEq: norm(Aeq * theta - beq) <= tuning + (1e-4)*tuning
        lambdaEq2: theta >= lb
        lambdaIneq: theta <= ub
        cvx_end
        UB_M{o_y,o_z} = cvx_optval;
        
        % lower bound
        cvx_clear
        cvx_begin
        variable theta(size(f,2))
        dual variables lambdaEq lambdaEq2 lambdaIneq
        
        minimize( f * theta )
        subject to
        lambdaEq: norm(Aeq * theta - beq) <= tuning + (1e-4)*tuning
        lambdaEq2: theta >= lb
        lambdaIneq: theta <= ub
        cvx_end
        LB_M{o_y,o_z} = cvx_optval;
    end
end

%% Create the graph
% Elements in the first plot
x1 = [0.02,0.02];
x2 = [0.04,0.04];
x3 = [0.12,0.12];
x4 = [0.14,0.14];
x5 = [0.22,0.22];
x6 = [0.24,0.24];

x7 = [0.02,0.04];
x8 = [0.12,0.14];
x9 = [0.22,0.24];


y1 = [LB{1,1},UB{1,1}];
y1_M = [LB_M{1,1},UB_M{1,1}];
y2 = [LB{1,2},UB{1,2}];
y2_M = [LB_M{1,2},UB_M{1,2}];
y3 = [LB{1,3},UB{1,3}];
y3_M = [LB_M{1,3},UB_M{1,3}];

y4 = [LB{1,1},LB{1,1}]; 
y5 = [UB{1,1},UB{1,1}];
y6 = [LB{1,2},LB{1,2}];
y7 = [UB{1,2},UB{1,2}];
y8 = [LB{1,3},LB{1,3}];
y9 = [UB{1,3},UB{1,3}];

% Elements in the second plot
z1 = [LB{2,1},UB{2,1}];
z1_M = [LB_M{2,1},UB_M{2,1}];
z2 = [LB{2,2},UB{2,2}];
z2_M = [LB_M{2,2},UB_M{2,2}];
z3 = [LB{2,3},UB{2,3}];
z3_M = [LB_M{2,3},UB_M{2,3}];

z4 = [LB{2,1},LB{2,1}]; 
z5 = [UB{2,1},UB{2,1}];
z6 = [LB{2,2},LB{2,2}];
z7 = [UB{2,2},UB{2,2}];
z8 = [LB{2,3},LB{2,3}];
z9 = [UB{2,3},UB{2,3}];

% Elements in the third plot
w1 = [LB{3,1},UB{3,1}];
w1_M = [LB_M{3,1},UB_M{3,1}];
w2 = [LB{3,2},UB{3,2}];
w2_M = [LB_M{3,2},UB_M{3,2}];
w3 = [LB{3,3},UB{3,3}];
w3_M = [LB_M{3,3},UB_M{3,3}];

w4 = [LB{3,1},LB{3,1}]; 
w5 = [UB{3,1},UB{3,1}];
w6 = [LB{3,2},LB{3,2}];
w7 = [UB{3,2},UB{3,2}];
w8 = [LB{3,3},LB{3,3}];
w9 = [UB{3,3},UB{3,3}];

% Elements in the fourth plot
v1 = [LB{4,1},UB{4,1}];
v1_M = [LB_M{4,1},UB_M{4,1}];
v2 = [LB{4,2},UB{4,2}];
v2_M = [LB_M{4,2},UB_M{4,2}];
v3 = [LB{4,3},UB{4,3}];
v3_M = [LB_M{4,3},UB_M{4,3}];

v4 = [LB{4,1},LB{4,1}]; 
v5 = [UB{4,1},UB{4,1}];
v6 = [LB{4,2},LB{4,2}];
v7 = [UB{4,2},UB{4,2}];
v8 = [LB{4,3},LB{4,3}];
v9 = [UB{4,3},UB{4,3}];

%% draw the first plot
subplot(2,2,1);
plot(x1,y1,'-x','color','red','linew',1.5);
hold on
plot(x2,y1_M,'-x','color',[0 1 1]*0.4,'linew',1.5);
plot(x3,y2,'-x','color','red','linew',1.5,'HandleVisibility','off');
plot(x4,y2_M,'-x','color',[0 1 1]*0.4,'linew',1.5,'HandleVisibility','off');
plot(x5,y3,'-x','color','red','linew',1.5,'HandleVisibility','off');
plot(x6,y3_M,'-x','color',[0 1 1]*0.4,'linew',1.5,'HandleVisibility','off');

plot(0.02, True{1,1},'.r', 'color','blue','MarkerSize', 20);
plot(0.04, True{1,1},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.12, True{1,2},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.14, True{1,2},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.22, True{1,3},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.24, True{1,3},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');

plot(x7,y4,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x7,y5,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x8,y6,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x8,y7,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x9,y8,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x9,y9,'--','color','black','linew',0.5,'HandleVisibility','off');
hold off
title('Y \in \{0, 1\}')
xlim([0 0.26])
ylim([0 1])
Words = {'Z \in \{0,1\}'; 'Z \in \{0, 1, 2\}';'Z \in \{0, 1, 2, 3, 4\}'};
set(gca,'xtick',[0.03, 0.13, 0.23],'xticklabel',Words,'color','w')

%% draw the second plot
subplot(2,2,2);
plot(x1,z1,'-x','color','red','linew',1.5);
hold on
plot(x2,z1_M,'-x','color',[0 1 1]*0.4,'linew',1.5);
plot(x3,z2,'-x','color','red','linew',1.5,'HandleVisibility','off');
plot(x4,z2_M,'-x','color',[0 1 1]*0.4,'linew',1.5,'HandleVisibility','off');
plot(x5,z3,'-x','color','red','linew',1.5,'HandleVisibility','off');
plot(x6,z3_M,'-x','color',[0 1 1]*0.4,'linew',1.5,'HandleVisibility','off');

plot(0.02, True{2,1},'.r', 'color','blue','MarkerSize', 20);
plot(0.04, True{2,1},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.12, True{2,2},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.14, True{2,2},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.22, True{2,3},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.24, True{2,3},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');

plot(x7,z4,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x7,z5,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x8,z6,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x8,z7,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x9,z8,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x9,z9,'--','color','black','linew',0.5,'HandleVisibility','off');
hold off
title('Y \in \{0, 0.5, 1\}')
xlim([0 0.26])
ylim([0 1])
Words = {'Z \in \{0,1\}'; 'Z \in \{0, 1, 2\}';'Z \in \{0, 1, 2, 3, 4\}'};
set(gca,'xtick',[0.03, 0.13, 0.23],'xticklabel',Words,'color','w')

%% draw the third plot
subplot(2,2,3);
plot(x1,w1,'-x','color','red','linew',1.5);
hold on
plot(x2,w1_M,'-x','color',[0 1 1]*0.4,'linew',1.5);
plot(x3,w2,'-x','color','red','linew',1.5,'HandleVisibility','off');
plot(x4,w2_M,'-x','color',[0 1 1]*0.4,'linew',1.5,'HandleVisibility','off');
plot(x5,w3,'-x','color','red','linew',1.5,'HandleVisibility','off');
plot(x6,w3_M,'-x','color',[0 1 1]*0.4,'linew',1.5,'HandleVisibility','off');

plot(0.02, True{3,1},'.r', 'color','blue','MarkerSize', 20);
plot(0.04, True{3,1},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.12, True{3,2},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.14, True{3,2},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.22, True{3,3},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.24, True{3,3},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');

plot(x7,w4,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x7,w5,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x8,w6,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x8,w7,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x9,w8,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x9,w9,'--','color','black','linew',0.5,'HandleVisibility','off');
hold off
title('Y \in \{0, 0.25, 0.5, 0.75, 1\}')
xlim([0 0.26])
ylim([0 1])
Words = {'Z \in \{0,1\}'; 'Z \in \{0, 1, 2\}';'Z \in \{0, 1, 2, 3, 4\}'};
set(gca,'xtick',[0.03, 0.13, 0.23],'xticklabel',Words,'color','w')

%% draw the fourth plot
subplot(2,2,4);
plot(x1,v1,'-x','color','red','linew',1.5);
hold on
plot(x2,v1_M,'-x','color',[0 1 1]*0.4,'linew',1.5);
plot(x3,v2,'-x','color','red','linew',1.5,'HandleVisibility','off');
plot(x4,v2_M,'-x','color',[0 1 1]*0.4,'linew',1.5,'HandleVisibility','off');
plot(x5,v3,'-x','color','red','linew',1.5,'HandleVisibility','off');
plot(x6,v3_M,'-x','color',[0 1 1]*0.4,'linew',1.5,'HandleVisibility','off');

plot(0.02, True{4,1},'.r', 'color','blue','MarkerSize', 20);
plot(0.04, True{4,1},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.12, True{4,2},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.14, True{4,2},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.22, True{4,3},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.24, True{4,3},'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');

plot(x7,v4,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x7,v5,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x8,v6,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x8,v7,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x9,v8,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x9,v9,'--','color','black','linew',0.5,'HandleVisibility','off');
hold off
title('Y \in \{0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1\}')
xlim([0 0.26])
ylim([0 1])
Words = {'Z \in \{0,1\}'; 'Z \in \{0, 1, 2\}';'Z \in \{0, 1, 2, 3, 4\}'};
set(gca,'xtick',[0.03, 0.13, 0.23],'xticklabel',Words,'color','w')

Lgnd = legend('show','Location','bestoutside','orientation','horizontal','Fontsize',11);
set(gcf,'color','w');