function b = bern3(K,k,L,l,M,m,y0,y1,u)
b = bern(K,k,y0).*bern(L,l,y1).*bern(M,m,u);
end