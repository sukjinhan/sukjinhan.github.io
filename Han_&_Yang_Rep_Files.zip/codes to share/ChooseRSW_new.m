function [A_R, B_R, H, one_R, dim_R, zer_R] = ChooseRSW(A, B, p, K,dim_s,dim_w,Bi_s)
H = mat2cell(repmat(zeros(K,dim_s),1,4),K,repmat(dim_s,1,4));

for i = 1:dim_s
    if Bi_s(i,1)>Bi_s(i,3)||Bi_s(i,2)>Bi_s(i,4) %defier-defier
            H{1}(:,i) = -1;            
    end
    if Bi_s(i,1)>Bi_s(i,3)||Bi_s(i,2)<Bi_s(i,4) %defier-complier
            H{2}(:,i) = -1;
    end
    if Bi_s(i,1)<Bi_s(i,3)||Bi_s(i,2)>Bi_s(i,4) %complier-defier
            H{3}(:,i) = -1;
    end
    if Bi_s(i,1)<Bi_s(i,3)||Bi_s(i,2)<Bi_s(i,4) %complier-complier
            H{4}(:,i) = -1;
    end
end

for i=1:length(H)
    H{i} = reshape(H{i},1,[]);
end

B_R = cell(size(H));
for i=1:length(H)
    for j=1:size(B,1)
        B_R_temp = B(j,:);
        B_R{i}(j,:) = B_R_temp(H{i}~=-1);
    end
end

% with rank similarity assn
dim_R = size(B_R{1},2);
zer_R = zeros(dim_R,1);
one_R = nan(K,dim_R);
for i=1:K
    for j=1:dim_R
        if mod(j-i,K)==0
            one_R(i,j) = 1;
        else
            one_R(i,j) = 0;
        end
    end
end

for i=1:length(H)
    %    cvx_solver sedumi     % For SeDuMi
    % upper bound
    cvx_clear
    cvx_begin quiet
    variable theta(dim_R)
    dual variables lambdaEq lambdaEq2 lambdaIneq
    
    maximize( ones(1,dim_R) * theta )
    subject to
    
    lambdaEq: B_R{i} * theta == p
    %lambdaEq: B_R{i} * theta - p==0
    lambdaEq2: one_R * theta == ones(K,1)
    lambdaIneq: theta >= zer_R
    cvx_end
    
    UB(i) = cvx_optval;
end

if sum(UB~=-inf)>1
    warning('Multiple candidates')
elseif sum(UB~=-inf)==0
    warning('Infesibility')
%elseif sum(UB~=-inf)==length(UB)
%    H = H{find(UB~=-inf,1)};
%    B_R = B_R{find(UB~=-inf,1)};
%    A_R = A(H~=-1);
else
    H = H{UB~=-inf};
    B_R = B_R{UB~=-inf};
    A_R = A(H~=-1);
end
end