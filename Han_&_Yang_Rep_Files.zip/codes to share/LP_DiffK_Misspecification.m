clear all;
%% Generating (Y,D,Z) of size N
% size and seed
N = 200000;
K = 50;
rng(123);

% parameters
p_Z = 0.3;
nu = 0.6;
u = rand(N,1);

% q(e|u)
% d=0,y=0; d=1,y=0;
q_1 = abs(sin(u)); % This DGP cannot be correctly specified by bernstein polynomials
% d=0,y=1; d=1,y=0;
q_2 = 0;
% d=0,y=0; d=1,y=1;
q_3 = 0.7.*abs(sin(3.14*2.*u));
% d=0,y=1; d=1,y=1;
q_4 = 0;

% m(u)
m_0 = q_2 + q_4;
m_1 = q_3 + q_4;

% data
Z = p_Z >= rand(N,1);
D = (0.1+nu*Z >= u);
Y = D.*binornd(1,m_1) + (1-D).*binornd(1,m_0);


%% Approximating MTE using different K
K_N = [5, 10, 20, 30, 40, 50];
for k = 1:length(K_N)
    % Basis function
    K = K_N(k);
    b = cell(K,1);
    for i=1:K
        b{i} = @(u)bern(K-1,i-1,u);
    end
    
    % Incorporating Rank similarity assumption
    dim_s = 2^(2);
    s = (1:dim_s)';
    Bi_s = de2bi(s-1);    % value of y(0), y(1)
    H = zeros(K,dim_s);
    
    for i = 1:dim_s
        if Bi_s(i,:) == [1 0]
            H(:,i) = -1;
        end
    end
    
    H = reshape(H,1,[]);
    
    % Defining A
    % A is for ATE
    my_d = 1;
    my_y = 1;
    
    gam0_ATE = zeros(K,1);
    gam1_ATE = zeros(K,1);
    for i=1:K
        syms u
        gam0_ATE(i) = -int(b{i},u,0,1);
        gam1_ATE(i) = int(b{i},u,0,1);
    end
    
    A_0 = zeros(K,dim_s);
    A_1 = zeros(K,dim_s);
    
    for j = 1:dim_s
        if Bi_s(j,bi2de(my_d)) == my_y  % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
            A_0(:,j) = 1;
        end
        if Bi_s(j,bi2de(my_d)+1) == my_y  % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
            A_1(:,j) = 1;
        end
        A_0(:,j) = A_0(:,j).*gam0_ATE;
        A_1(:,j) = A_1(:,j).*gam1_ATE;
    end
    
    A_0 = reshape(A_0,1,[]);
    A_1 = reshape(A_1,1,[]);
    A = A_0+A_1;
    A(H==-1) = [];
    
    % Defining p
    % p is p(y,d|z) from data
    dim_p = 2^(3);    % number of possibility in (D,Y,Z)
    Bi = de2bi(0:dim_p-1);    % the order of column: (D,Y,Z); each ROW of this matrix correspond to each decimal number
    p = zeros(dim_p,1);
    for i = 1:dim_p
        summand1 = (D==Bi(i,2)).*(Y==Bi(i,3)).*(Z==Bi(i,1));
        summand2 = (Z==Bi(i,1));
        p(i) = sum(summand1)/sum(summand2);
    end
    
    p_z = null(2,1); % the propensity score
    for i=1:2
        p_z(i) = sum((D==1).*(Z==i-1))/sum(Z==i-1);
    end
    
    % Defining B
    % the left hand side coefficients
    B = [];
    for l = 1:dim_p
        d = Bi(l,2);
        y = Bi(l,3);
        z = Bi(l,1);
        delta = null(1,K);
        for m=1:K
            if d == 1
                delta(m) = int(b{m},u,0,p_z(z+1));
            elseif d == 0
                delta(m) = int(b{m},u,p_z(z+1),1);
            end
        end
        
        B0 = zeros(K,dim_s);
        
        for j = 1:dim_s
            if Bi_s(j,bi2de(d)+1) == y  % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                B0(:,j) = 1;
            end
            B0(:,j) = (B0(:,j)'.*delta)';
        end
        B0 = reshape(B0,1,[]);
        B0(H==-1) = [];
        B(l,:) = B0;
    end
    
    % Restrictions on conditional probabilities
    p(1:4,:)=[];
    dim = size(B,2);
    zer = zeros(dim,1);
    one = null(K,dim);
    for i=1:K
        for j=1:dim
            if mod(j-i,K)==0
                one(i,j) = 1;
            else
                one(i,j) = 0;
            end
        end
    end
    
    B(1:4,:)=[];
    
    % MTE
    x = 0.01:0.01:0.99;
    mte = null(length(x),length(B));

    for i=1:length(x)
        for j=1:length(B)
            m=mod(j,K);
            if m==0
                mte(i,j) = double(A(j)~=0)*b{K}(x(i));
            else
                mte(i,j) =  double(A(j)~=0)*b{m}(x(i));
            end
        end
    end
    
    % CVX
    % RS + Monotonicity + Concavity
    LB3_mte{k} = nan(1,length(x));
    UB3_mte{k} = nan(1,length(x));
    
    for i = 1:length(x)
        cvx_clear
        cvx_begin
        variable theta(dim)
        dual variables lambdaEq lambdaEq2 lambdaIneq lambdaIneq2 lambdaIneq3
        
        maximize( mte(i,:) * theta )
        subject to
        lambdaEq: B * theta == p
        lambdaEq2: one * theta == ones(K,1)
        lambdaIneq: theta >= zer
        cvx_end
        
        UB3_mte{k}(i) = cvx_optval;
        
        cvx_clear
        cvx_begin
        variable theta(dim)
        dual variables lambdaEq lambdaEq2 lambdaIneq lambdaIneq2 lambdaIneq3
        
        minimize( mte(i,:) * theta )
        subject to
        lambdaEq: B * theta == p
        lambdaEq2: one * theta == ones(K,1)
        lambdaIneq: theta >= zer
        cvx_end
        
        LB3_mte{k}(i) = cvx_optval;
    end 
end

%% Plot
x = 0.01:0.01:0.99;
true = 0.7.*abs(sin(3.14*2.*x));
% MTE
plot(x,true,'r')
hold on
for k=1:length(K_N)
plot (x,LB3_mte{k},'--','color',[0 1 1]*0.1*(12-2*k),'linew',1.5)
plot (x,UB3_mte{k},'--','color',[0 1 1]*0.1*(12-2*k),'linew',1.5,'HandleVisibility','off')
end
hold off
xlabel('u \in [0,1]')  
title('Bounds on MTE: Different K')
legend('True MTE','K=5', 'K=10', 'K=20','K=30', 'K=40','K=50','Location','bestoutside','orientation','horizontal')
set(0,'defaultfigurecolor','w')

%% Compute the misspecification error
mis = zeros(length(K_N),size(x,2));
for k=1:length(K_N) % compute the distance
    for i=1:size(x,2)
        if true(i)<LB3_mte{k}(i)
            mis(k,i)=(LB3_mte{k}(i)-true(i));
        elseif true(i)>UB3_mte{k}(i)
            mis(k,i)=(true(i)-UB3_mte{k}(i));
        end
    end
end

mis_h = zeros(length(K_N),1);

for k=1:length(K_N)
    mis_h(k) = max(mis(k,:));
end

%% Draw a bar graph for Hausdorff distance of deviation
temp = [0.1,0.3,0.5,0.7,0.9,1.1];
bar (temp, mis_h);

Words = {'K=5'; 'K=10';'K=20';'K=30';'K=40';'K=50';};
set(gca,'xtick',[0.1, 0.3, 0.5, 0.7, 0.9,1.1],'xticklabel',Words,'color','w')
xlabel('Approximation Order')  
ylabel('Hausdorff Distance of Deviation') 
title('Misspecification with Different K')
%legend('True MTE','K=5', 'K=10', 'K=20','K=30', 'K=40','K=50','Location','bestoutside','orientation','horizontal')
set(0,'defaultfigurecolor','w')

