clear all;
%% Generating (Y,D,Z,W) of size N
for o=1:3
    width_same = 0; % fix the width of support of Z or not 
    %% DGP
    N = 20000;      % sample size
    rng(111);
    u_Z = rand(N,1);
    
    % Group 1: Z takes 2 values
    p_Z = 0.5;      % P(Z=1)
    Z_index{1} =  u_Z >=p_Z;
    
    % Group 2: Z takes 3 values
    % p_Z1 = 0.3;
    % p_Z2 = 0.6;
    Z_index{2} = (1-0.5.*width_same).*((u_Z>=0.3)+(u_Z>=0.6));
    
    % Group 3: Z = 0,0.25,...,1
    % p_Z1 = 0.2;
    % p_Z2 = 0.4;
    % p_Z3 = 0.6;
    % p_Z4 = 0.8;
    Z_index{3} = (1-0.75.*width_same).*((u_Z>=0.2)+(u_Z>=0.4)+(u_Z>=0.6)+(u_Z>=0.8));

    % size and seed
    % N = 20000;
    K1=5;
    K1=K1+1;
    % rng(123);
    
    % parameters
    %p_Z = 0.5;
    nu_z = 0.2;
    rho = 0.3;
    
    mu = [0 0.5 0.04];
    Sigma = [1 0.5 0.3; 0.5 1 0.6; 0.3 0.6 1];
    R = mvnrnd(mu, Sigma, N);
    R = normcdf(R);
    u = R(:,1);
    
    % data
    Z = Z_index{o};
    D = (0.1+nu_z*Z >= u);
    Y_1 = R(:,2);
    Y_0 = R(:,3);
    
    Y = D.*Y_1+(1-D).*Y_0;
    ATE = mean(Y_1-Y_0); % ATE is fixed to be the same
    
    %% Basis Function
    K0=K1;
    KU=K1;
    b = cell(K1,K0,KU);
    for i=1:K1
        for j=1:K0
            for m=1:KU
                b{i,j,m} = @(y0,y1,u)bern3(K0-1,i-1,K1-1,j-1,KU-1,m-1,y0,y1,u);
            end
        end
    end
    %% Construct comb
    ZGroup = findgroups(Z);
    Z_supp = splitapply(@mean, Z, ZGroup); %find the support for Z
    
    Bi_temp = de2bi(0:2^1-1);    % the order of column: (Z,D); each ROW of this matrix correspond to each decimal number
    
    Bi = [];
    for i=1:size(Z_supp,1)
        Bi=[Bi;[Z_supp(i)*ones(size(Bi_temp,1),1),Bi_temp]];
    end
    Bi = sortrows(Bi,size(Bi,2));
    comb = Bi;
    %% Construct the data distribution
    dim_p = size(Z_supp,1)*2;
    Y_sub = cell(dim_p,1);
    for i=1:dim_p
        Y_sub{i} = Y(sum([Z,D]==comb(i,:),2)==2);
    end
    
    dim_z = size(Z_supp,1);
    p_z = zeros(dim_z,1); % the propensity score
    for i=1:dim_z
        p_z(i) = sum((D==1).*(Z==Z_supp(i)))/sum((Z==Z_supp(i)));
    end
    
    for i=1:dim_p
        [f,y]=ecdf(Y_sub{i});
        z = comb(i,1);
        d = comb(i,2);
        for n=1:size(Y_sub{i},1)
            if d==0
                p{i}(n,1) = max(f(y<=Y_sub{i}(n)))*(1-p_z(find(abs(Z_supp-z)<=0.0001,1)));
            elseif d==1
                p{i}(n,1) = max(f(y<=Y_sub{i}(n)))*p_z(find(abs(Z_supp-z)<=0.0001,1));
            end
        end
    end
    
    %% Construct the restriction matrix
    sigma = cell(dim_p,1);
    for i=1:dim_p
        z = comb(i,1);
        d = comb(i,2);
        z_loc = find(abs(Z_supp-z)<=0.0001,1);
        for n=1:size(Y_sub{i},1)
            for k=1:K0
                for l=1:K1
                    for m=1:KU
                        if d==1
                            temp = @(u)b{k,l,m}(Y_sub{i}(n),1,u);
                            sigma{i}(n,k,l,m) = integral(temp,0,p_z(z_loc));
                        elseif d==0
                            temp = @(u)b{k,l,m}(1,Y_sub{i}(n),u);
                            sigma{i}(n,k,l,m) = integral(temp,p_z(z_loc),1);
                        end
                    end
                end
            end
        end
        sigma{i} = reshape(sigma{i},size(Y_sub{i},1),[]);
    end
    %%
    B = [];
    for i=1:length(sigma)
        B=[B;sigma{i}];
    end
    B_store{o,1} = B;
    pi = [];
    for i=1:length(p)
        pi=[pi;p{i}];
    end
    pi_store{o,1} = pi;
    %% Constructing the ineuqality constraints
    
    % theta_{K,K,ku}=1
    ineq1 = zeros(KU,K1*K0*KU);
    for i=1:KU
        ineq1(i,i*K1*K0)=1;
    end
    
    % theta_{1,1,ku}=0
    ineq2 = zeros(KU,K1*K0*KU);
    for i=1:KU
        ineq2(i,(i-1)*K1*K0+1)=1;
    end
    
    % theta_{1,K,ku}=0
    ineq3 = zeros(KU,K1*K0*KU);
    for i=1:KU
        ineq3(i,i*K1*K0-K1+1)=1;
    end
    
    % theta_{K,1,ku}=0
    ineq4 = zeros(KU,K1*K0*KU);
    for i=1:KU
        ineq4(i,(i-1)*K1*K0+K1)=1;
    end
    
    % createe coefficient for the 2-increasing property
    [order1,order2,order3] = ndgrid([1:K0],[1:K1],[1:KU]);
    order = [order1(:) order2(:) order3(:)];
    
    ineq5 = [];
    for k=1:KU
        for i=1:size(order)-1
            for j=(i+1):size(order)
                if order(j,1)>=order(i,1) && order(j,2)>=order(i,2) && order(j,3)==order(i,3) && order(j,3)==k
                    k0 = order(i,1);
                    k1 = order(i,2);
                    k0_tilde = order(j,1);
                    k1_tilde = order(j,2);
                    idx1 = find(ismember(order, [k0_tilde,k1_tilde,k],'rows'));
                    idx2 = find(ismember(order, [k0_tilde,k1,k],'rows'));
                    idx3 = find(ismember(order, [k0,k1_tilde,k],'rows'));
                    idx4 = find(ismember(order, [k0,k1,k],'rows'));
                    ineq5 = [ineq5; zeros(1,KU*K0*K1)];
                    row_num = size(ineq5,1);
                    ineq5(row_num,idx1)=1+ineq5(row_num,idx1);
                    ineq5(row_num,idx2)=-1+ineq5(row_num,idx2);
                    ineq5(row_num,idx3)=-1+ineq5(row_num,idx3);
                    ineq5(row_num,idx4)=1+ineq5(row_num,idx4);
                end
            end
        end
    end
    %% Target parameter: ATE
    temp = cell(K1,K0,KU);
    for k=1:K1
        for l=1:K0
            for m=1:KU
                temp{k,l,m} = @(y,u)b{k,l,m}(1,y,u)-b{k,l,m}(y,1,u);
            end
        end
    end
    
    A = zeros(K1,K0,KU);
    for k = 1:K1
        for l=1:K0
            for m=1:KU
                A(k,l,m) = integral2(temp{k,l,m},0,1,0,1);
            end
        end
    end   
    A = reshape(A,1,[]);

    %% run CVX
    dim = KU*K1*K0;
    % base for tuning
    cvx_clear
    cvx_begin
    variable theta(dim)
    dual variables lambdaIneq1 lambdaIneq2 lambdaIneq3 lambdaIneq4 lambdaIneq5 lambdaIneq6 lambdaIneq7
    
    minimize(norm(B*theta-pi,1)/size(Y,1))
    subject to
    lambdaIneq1: theta<=ones(dim,1);
    lambdaIneq2: theta>=zeros(dim,1);
    lambdaIneq3: ineq1*theta == ones(size(ineq1,1),1);
    lambdaIneq4: ineq2*theta == zeros(size(ineq2,1),1);
    lambdaIneq5: ineq3*theta == zeros(size(ineq3,1),1);
    lambdaIneq6: ineq4*theta == zeros(size(ineq4,1),1);
    lambdaIneq7: ineq5*theta >= zeros(size(ineq5,1),1);
    cvx_end
    tuning = cvx_optval;
    
    % lower bound
    cvx_clear
    cvx_begin
    variable theta(dim)
    dual variables lambdaEq1 ...
        lambdaIneq1 lambdaIneq2 lambdaIneq3 lambdaIneq4 lambdaIneq5 lambdaIneq6 lambdaIneq7
    minimize(A*theta)
    subject to
    lambdaEq1: norm(B*theta-pi,1)/size(Y,1)<=tuning+(1e-3);
    lambdaIneq1: theta<=ones(dim,1);
    lambdaIneq2: theta>=zeros(dim,1);
    lambdaIneq3: ineq1*theta == ones(size(ineq1,1),1);
    lambdaIneq4: ineq2*theta == zeros(size(ineq2,1),1);
    lambdaIneq5: ineq3*theta == zeros(size(ineq3,1),1);
    lambdaIneq6: ineq4*theta == zeros(size(ineq4,1),1);
    lambdaIneq7: ineq5*theta >= zeros(size(ineq5,1),1);
    cvx_end
    LB(o,1) = cvx_optval;
    
    % upper bound
    cvx_clear
    cvx_begin
    variable theta(dim)
    dual variables lambdaEq1 ...
        lambdaIneq1 lambdaIneq2 lambdaIneq3 lambdaIneq4 lambdaIneq5 lambdaIneq6 lambdaIneq7
    maximize(A*theta)
    subject to
    lambdaEq1: norm(B*theta-pi,1)/size(Y,1)<=tuning+(1e-3);
    lambdaIneq1: theta<=ones(dim,1);
    lambdaIneq2: theta>=zeros(dim,1);
    lambdaIneq3: ineq1*theta == ones(size(ineq1,1),1);
    lambdaIneq4: ineq2*theta == zeros(size(ineq2,1),1);
    lambdaIneq5: ineq3*theta == zeros(size(ineq3,1),1);
    lambdaIneq6: ineq4*theta == zeros(size(ineq4,1),1);
    lambdaIneq7: ineq5*theta >= zeros(size(ineq5,1),1);
    cvx_end
    UB(o,1) = cvx_optval;
    
    %% Results with Mogstad et al.
    % Basis Function
    K = 6;
    b = cell(K,1);
    for i=1:K
        b{i} = @(u)bern(K-1,i-1,u); 
    end
    
    % Linear Programming Inputs
    UncondInputs.labels = {'d=0,z=0', 'd=0,z=1', ...
        'd=1,z=0', 'd=1,z=1'};
    covariance =  @(x,y) [1,0]*cov(x,y)*[0,1]';
    ZGroup = findgroups(Z);
    Z_supp = splitapply(@mean, Z, ZGroup);
    
    DGroup = findgroups(D);
    D_supp = splitapply(@mean, D, DGroup);
    
    prop = splitapply(@mean, D, ZGroup);
    Propensity = prop(ZGroup);
    
    % Caluculate the s(d,x,z) functions
    UncondInputs.s = cell(length(Z_supp)*length(D_supp),1);
    
    for i=1:length(Z_supp)
        for j=1:length(D_supp)
            UncondInputs.s{i+length(Z_supp)*(j-1)} = @(d,z)(abs(z-Z_supp(i))<=0.0001)*(d==D_supp(j));
        end
    end
    
    % Caluculate the weights
    UncondInputs.M0Parameter = cell(length(Z_supp)*length(D_supp),1);
    UncondInputs.M1Parameter = cell(length(Z_supp)*length(D_supp),1);
    
    PZ = nan(1,size(Z_supp,1));
    
    for j=1:size(Z_supp,1)
        PZ(1,j)=sum(abs(Z-Z_supp(j))<=0.0001)/N;
    end
    
    for i = 1:1:length(Z_supp)*length(D_supp)
        UncondInputs.M0Parameter{i} = nan(1,K);
        UncondInputs.M1Parameter{i} = nan(1,K);
        syms z u;
        for k = 1:1:K
            UncondInputs.M0ParameterFn{i,k} = @(z)...
                UncondInputs.s{i}(0,z)*int(b{k}(u),u,...
                Propensity(find(abs(Z-z)<0.0001,1)),1);
            UncondInputs.M1ParameterFn{i,k} = @(z)...
                UncondInputs.s{i}(1,z)*int(b{k}(u),u,0,...
                Propensity(find(abs(Z-z)<0.0001,1)));
            
            UncondInputs.M0Parameter{i}(k) = 0;
            for h=1:size(Z_supp,1)
                UncondInputs.M0Parameter{i}(k) = ...
                    UncondInputs.M0Parameter{i}(k) + UncondInputs.M0ParameterFn{i,k}(Z_supp(h))*PZ(1,h);
            end
            UncondInputs.M1Parameter{i}(k) = 0;
            for h=1:size(Z_supp,1)
                UncondInputs.M1Parameter{i}(k) = ...
                    UncondInputs.M1Parameter{i}(k) + UncondInputs.M1ParameterFn{i,k}(Z_supp(h))*PZ(1,h);
            end
        end
    end
    
    % Constraints in LP
    beq = zeros(length(Z_supp)*length(D_supp),1);
    
    for i=1:length(Z_supp)
        for j=1:length(D_supp)
            beq(i+length(Z_supp)*(j-1)) = mean(Y(D==D_supp(j)&abs(Z-Z_supp(i))<0.0001)*sum(D==D_supp(j)& abs(Z-Z_supp(i))<0.0001))/N;
        end
    end
    
    % Linear Programming
    % ATE
    w1{1} = @(u,z) 1;
    w0{1} = @(u,z) -1;
    
    for k = 1:1:K
        Obj.M0ParameterFn{1,k} = @(z)int(w0{1}(u,z)*b{k}(u),...
            u,0,1);
        Obj.M0Parameter(1,k) = 0;
        for h=1:size(Z_supp,1)
            Obj.M0Parameter(1,k) = Obj.M0Parameter(1,k) + Obj.M0ParameterFn{1,k}(Z_supp(h))*PZ(1,h);
        end
    end
    
    for k = 1:1:K
        Obj.M1ParameterFn{1,k} = @(z)int(w1{1}(u,z)*b{k}(u),...
            u,0,1);
        Obj.M1Parameter(1,k) = 0;
        for h=1:size(Z_supp,1)
            Obj.M1Parameter(1,k) = Obj.M1Parameter(1,k) + Obj.M1ParameterFn{1,k}(Z_supp(h))*PZ(1,h);
        end
    end
    
    f = double([Obj.M0Parameter, Obj.M1Parameter]);
    Aeq0 = UncondInputs.M0Parameter{1}';
    Aeq1 = UncondInputs.M1Parameter{1}';
    for i=2:length(UncondInputs.M0Parameter)
        Aeq0 = [Aeq0, UncondInputs.M0Parameter{i}'];
        Aeq1 = [Aeq1, UncondInputs.M1Parameter{i}'];
    end
    
    Aeq = [Aeq0',Aeq1'];
    lb = min(Y)*ones(size(f,2),1);
    ub = max(Y)*ones(size(f,2),1);
    
    % CVX - No Assumption
    % tuning
    cvx_solver sedumi
    cvx_clear
    cvx_begin
    variable theta(size(f,2))
    dual variables lambdaEq lambdaEq2 lambdaIneq
    
    minimize( norm(Aeq * theta - beq) )
    subject to
    lambdaEq2: theta >= lb
    lambdaIneq: theta <= ub
    cvx_end
    tuning = cvx_optval;
    
    % upper bound
    cvx_clear
    cvx_begin
    variable theta(size(f,2))
    dual variables lambdaEq lambdaEq2 lambdaIneq
    
    maximize( f * theta )
    subject to
    
    lambdaEq: norm(Aeq * theta - beq) <= tuning+(1e-3)
    lambdaEq2: theta >= lb
    lambdaIneq: theta <= ub
    cvx_end
    UB_M(o,1) = cvx_optval;
    
    % lower bound
    
    cvx_clear
    cvx_begin
    variable theta(size(f,2))
    dual variables lambdaEq lambdaEq2 lambdaIneq
    
    minimize( f * theta )
    subject to
    
    lambdaEq: norm(Aeq * theta - beq) <= tuning+(1e-3)
    lambdaEq2: theta >= lb
    lambdaIneq: theta <= ub
    cvx_end
    LB_M(o,1) = cvx_optval;
    %% CLEAR
    clearvars -except UB* LB* B_store pi_store ATE
end
%% Plot
% Elements in the first plot
x1 = [0.02,0.02];
x2 = [0.04,0.04];
x3 = [0.12,0.12];
x4 = [0.14,0.14];
x5 = [0.22,0.22];
x6 = [0.24,0.24];
x7 = [0.02,0.04];
x8 = [0.12,0.14];
x9 = [0.22,0.24];


y1 = [LB(1),UB(1)];
y1_M = [LB_M(1),UB_M(1)];
y2 = [LB(2),UB(2)];
y2_M = [LB_M(2),UB_M(2)];
y3 = [LB(3),UB(3)];
y3_M = [LB_M(3),UB_M(3)];

y4 = [LB(1),LB(1)];
y5 = [UB(1),UB(1)];
y6 = [LB(2),LB(2)];
y7 = [UB(2),UB(2)];
y8 = [LB(3),LB(3)];
y9 = [UB(3),UB(3)];

%% draw the first plot
plot(x1,y1,'-x','color','red','linew',1.5);
hold on
plot(x2,y1_M,'-x','color',[0 1 1]*0.4,'linew',1.5);
plot(x3,y2,'-x','color','red','linew',1.5,'HandleVisibility','off');
plot(x4,y2_M,'-x','color',[0 1 1]*0.4,'linew',1.5,'HandleVisibility','off');
plot(x5,y3,'-x','color','red','linew',1.5,'HandleVisibility','off');
plot(x6,y3_M,'-x','color',[0 1 1]*0.4,'linew',1.5,'HandleVisibility','off');

plot(0.02, ATE,'.r', 'color','blue','MarkerSize', 20);
plot(0.04, ATE,'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.12, ATE,'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.14, ATE,'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.22, ATE,'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');
plot(0.24, ATE,'.r', 'color','blue','MarkerSize', 20,'HandleVisibility','off');

plot(x7,y4,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x7,y5,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x8,y6,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x8,y7,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x9,y8,'--','color','black','linew',0.5,'HandleVisibility','off');
plot(x9,y9,'--','color','black','linew',0.5,'HandleVisibility','off');
hold off
title('Continuous Y')
xlim([0 0.26])
ylim([-0.4 0.4])
Words = {'Z \in \{0,1\}'; 'Z \in \{0, 1, 2\}';'Z \in \{0, 1, 2, 3, 4\}'};
set(gca,'xtick',[0.03, 0.13, 0.23],'xticklabel',Words,'color','w')

Lgnd = legend('show','Location','bestoutside','orientation','horizontal','Fontsize',11);
set(gcf,'color','w');
