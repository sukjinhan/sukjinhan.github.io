% Bernstein Basis Function

% Inputs:
% K and k
% u: a vector of uniform r.v.

% Outputs:
% b: a vector of Bernstein basis values

function b = bern(K,k,u)
b = nchoosek(K,k)*(u.^k).*((1-u).^(K-k));
end