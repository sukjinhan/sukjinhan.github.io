function [A_R, B_R, H, one_R, dim_R, zer_R] = ChooseRS(A, B, p, K)
dim_s = 2^(2);

s = (1:dim_s)';
Bi_s = de2bi(s-1);    % value of y(0), y(1)


H = mat2cell(repmat(zeros(K,dim_s),1,2),K,repmat(dim_s,1,2));  

for i = 1:dim_s
    if Bi_s(i,:) == [1 0]
        H{1}(:,i) = -1;
    end
    if Bi_s(i,:) == [0 1]
        H{2}(:,i) = -1;
    end
end

for i=1:2
    H{i} = reshape(H{i},1,[]);
end

B_R = cell(size(H));
one_R = cell(size(H));
for i=1:length(H)
    for j=1:size(B,1)
        B_R_temp = B(j,:);
        B_R{i}(j,:) = B_R_temp(H{i}~=-1);
    end
end

% with rank similarity assn
dim_R = size(B_R{1},2);
zer_R = zeros(dim_R,1);
one_R = nan(K,dim_R);
for i=1:K
    for j=1:dim_R
        if mod(j-i,K)==0
            one_R(i,j) = 1;
        else
            one_R(i,j) = 0;
        end
    end
end

for i=1:length(H)
%    cvx_solver sedumi     % For SeDuMi
    % upper bound
    cvx_clear
    cvx_begin quiet
    variable theta(dim_R)
    dual variables lambdaEq lambdaEq2 lambdaIneq
    
    maximize( ones(1,dim_R) * theta )
    subject to
    
    lambdaEq: B_R{i} * theta == p
    lambdaEq2: one_R * theta == ones(K,1)
    lambdaIneq: theta >= zer_R
    cvx_end
    
    UB(i) = cvx_optval;
end

if sum(UB~=-inf)>1
    warning('Multiple candidates')
elseif sum(UB~=-inf)==0
    warning('Infesibility')
else
    H = H{find(UB~=-inf)};
    B_R = B_R{find(UB~=-inf)};
    A_R = A(H~=-1);
end
end