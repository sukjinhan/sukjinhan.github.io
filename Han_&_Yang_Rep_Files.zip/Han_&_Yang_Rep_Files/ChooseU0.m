function G_M = ChooseU0_New(A, B, p, K,dim_s,dim_w,Bi_s)
%H = mat2cell(repmat(zeros(K,dim_s),1,4),K,repmat(dim_s,1,4));
%H = cell(4,1);
%H1 = mat2cell(repmat(zeros(K,dim_s),1,2),K,repmat(dim_s,1,2));
%H2=H1;
dim_N = size(B,2);
G_M_W0 = mat2cell(repmat(zeros(K,dim_N),1,2),K,repmat(dim_N,1,2));
G_M_W1 = mat2cell(repmat(zeros(K,dim_N),1,2),K,repmat(dim_N,1,2));
for i = 1:K
    G_M_W0_temp{1} = zeros(K,dim_s); % W=0, complier larger than defier
    G_M_W0_temp{2} = zeros(K,dim_s); % W=0, defier larger than complier
    G_M_W1_temp{1} = zeros(K,dim_s); % W=1, complier larger than defier
    G_M_W1_temp{2} = zeros(K,dim_s); % W=1, defier larger than complier
    for j=1:dim_s
        if Bi_s(j,1)>Bi_s(j,3)
            G_M_W0_temp{1}(i,j) = -1;
            G_M_W0_temp{2}(i,j) = 1;
        elseif Bi_s(j,1)<Bi_s(j,3)
            G_M_W0_temp{1}(i,j) = 1;
            G_M_W0_temp{2}(i,j) = -1;
        end
        if Bi_s(j,2)>Bi_s(j,4)
            G_M_W1_temp{1}(i,j) = -1;
            G_M_W1_temp{2}(i,j) = 1;
        elseif Bi_s(j,2)<Bi_s(j,4)
            G_M_W1_temp{1}(i,j) = 1;
            G_M_W1_temp{2}(i,j) = -1;
        end
    end
    G_M_W0_temp{1} = reshape(G_M_W0_temp{1}, 1, []);
    G_M_W0_temp{2} = reshape(G_M_W0_temp{2}, 1, []);
    G_M_W1_temp{1} = reshape(G_M_W1_temp{1}, 1, []);
    G_M_W1_temp{2} = reshape(G_M_W1_temp{2}, 1, []);
    
    G_M_W0{1}(i,:)=G_M_W0_temp{1};
    G_M_W0{2}(i,:)=G_M_W0_temp{2};
    G_M_W1{1}(i,:)=G_M_W1_temp{1};
    G_M_W1{2}(i,:)=G_M_W1_temp{2};
end

G_M{1}=[G_M_W0{1};G_M_W1{1}];
G_M{2}=[G_M_W0{1};G_M_W1{2}];
G_M{3}=[G_M_W0{2};G_M_W1{1}];
G_M{4}=[G_M_W0{2};G_M_W1{2}];

% with rank similarity assn
dim = size(B,2);
zer = zeros(dim,1);
one = nan(K,dim);
for i=1:K
    for j=1:dim
        if mod(j-i,K)==0
            one(i,j) = 1;
        else
            one(i,j) = 0;
        end
    end
end

for i=1:length(G_M)
    %    cvx_solver sedumi     % For SeDuMi
    % upper bound
    cvx_clear
    cvx_begin quiet
    variable theta(dim)
    dual variables lambdaEq lambdaEq2 lambdaIneq lambdaIneq2
    
    maximize( ones(1,dim) * theta )
    subject to
    
    lambdaEq: B * theta == p
    %lambdaEq: B_R{i} * theta - p==0
    lambdaEq2: one * theta == ones(K,1)
    lambdaIneq: theta >= zer
    lambdaIneq2: G_M{i}*theta>=zeros(size(G_M{1},1),1)
    cvx_end
    
    UB(i) = cvx_optval;
end

if sum(UB~=-inf)>1
    warning('Multiple candidates')
elseif sum(UB~=-inf)==0
    warning('Infesibility')
    %elseif sum(UB~=-inf)==length(UB)
    %    H = H{find(UB~=-inf,1)};
    %    B_R = B{find(UB~=-inf,1)};
    %    A_R = A(H~=-1);
else
    G_M = G_M{UB~=-inf};
    %B_R = B_R{UB~=-inf};
    %A_R = A(H~=-1);
end
end