clear all;
%% DGP
N = 200000;        % sample size
rng(123);

nu = 0.3;
i=1;
sigma = eye((2*i+1)*(i<=2)+(2*i+3)*(i==3)+21*(i==4));
sigma(sigma==0)=0.5;
cop_mat = copularnd('Gaussian',sigma,N);

K = 50; % polynomial order
K = K+1;
u_Z = rand(N,1);

U = cop_mat(:,size(cop_mat,2));
e_0 = cop_mat(:,1:(size(cop_mat,2)-1)/2);
e_1 = cop_mat(:,(size(cop_mat,2)-1)/2+1:(size(cop_mat,2)-1));

%Group 1: Z takes 2 values
p_Z = 0.3;      % P(Z=1)
Z =  u_Z >=p_Z;

D = (0.5+nu*Z >= U);

mu_1 = 0.1;
mu_2 = 0.3;
sigma_1 = 0.2;
sigma_2 = 0.1;
lb = 0;
ub = 1;
cdf_1 = @(x) (normcdf(x, mu_1, sigma_1) - normcdf(lb, mu_1, sigma_1)) / (normcdf(ub, mu_1, sigma_1) - normcdf(lb, mu_1, sigma_1));
cdf_2 = @(x) (normcdf(x, mu_2, sigma_2) - normcdf(lb, mu_2, sigma_2)) / (normcdf(ub, mu_2, sigma_2) - normcdf(lb, mu_2, sigma_2));

u_y = rand();
Y_0 = zeros(N,1);
Y_1 = zeros(N,1);
for j=1:size(e_0,2)
    Y_0 = (norminv(cdf_1(u_y), mu_1, sigma_1) >=e_0(:,j));
end
for j=1:size(e_1,2)
    Y_1 = (norminv(cdf_2(u_y), mu_2, sigma_2) >=e_1(:,j));
end

Y = D.*Y_1 + (1-D).*Y_0;
True =  mean(Y_1-Y_0);

%% LP
for K_supp = 1:5
    % Basis function
    K = K_supp*10+1;
    b = cell(K,1);
    for i=1:K
        b{i} = @(u)bern(K-1,i-1,u);
    end
    
    % Defining A
    YGroup = findgroups(Y);
    Y_supp = splitapply(@mean, Y, YGroup); %find the support for Y
    
    DGroup = findgroups(D);
    D_supp = splitapply(@mean, D, DGroup); %find the support for D
    
    dim_s = (length(Y_supp))^length(D_supp);
    Bi_s = nan(dim_s,2);
    Bi_s(:,1) = repmat(Y_supp,length(Y_supp),1);
    
    for i=1:length(Y_supp)
        Bi_s(length(Y_supp)*(i-1)+1:length(Y_supp)*i,2) = repmat(Y_supp(i),length(Y_supp),1);
    end
    
    % A is for ATE
    my_d = 1;
    
    gam0_ATE = zeros(K,1);
    gam1_ATE = zeros(K,1);
    for i=1:K
        syms u
        gam0_ATE(i) = -int(b{i},u,0,1);
        gam1_ATE(i) = int(b{i},u,0,1);
    end
    
    A_0 = zeros(K,dim_s);
    A_1 = zeros(K,dim_s);
    
    for j = 1:dim_s
        for h = 1:length(Y_supp)
            if Bi_s(j,bi2de(my_d)) == Y_supp(h)  % in Bi_s, find the column for y(0) and choose s s.t. y(0) = 1
                A_0(:,j) = Y_supp(h);
            end
            if Bi_s(j,bi2de(my_d)+1) == Y_supp(h)  % in Bi_s, find the column for y(0) and choose s s.t. y(1) = 1
                A_1(:,j) = Y_supp(h);
            end
        end
        A_0(:,j) = A_0(:,j).*gam0_ATE;
        A_1(:,j) = A_1(:,j).*gam1_ATE;
    end
    
    A_0 = reshape(A_0,1,[]);
    A_1 = reshape(A_1,1,[]);
    A = A_0+A_1;
    
    % Defining p
    ZGroup = findgroups(Z);
    Z_supp = splitapply(@mean, Z, ZGroup); %find the support for Z
    
    Bi_temp = de2bi(0:2^1-1);    % create all value combos for (z,d,y)
    
    Bi = [];
    for i=1:size(Z_supp,1)
        Bi=[Bi;[Z_supp(i)*ones(size(Bi_temp,1),1),Bi_temp]];
    end
    Bi = sortrows(Bi,size(Bi,2));
    Bi_new = [];
    for i=1:length(Y_supp)
        Bi_new = [Bi_new;Bi,Y_supp(i)*ones(size(Bi,1),1)];
    end
    Bi = Bi_new;
    
    dim_p = length(Z_supp)*length(D_supp)*length(Y_supp); % dimension of data restriction
    p = zeros(dim_p,1); % p is p(y,d|z) from data
    
    for i = 1:dim_p
        summand1 = (D==Bi(i,2)).*(abs(Z-round(Bi(i,1),3))<=0.0001).*(abs(Y-round(Bi(i,3),3))<=0.0001);
        summand2 = (abs(Z-round(Bi(i,1),3))<=0.0001);
        p(i) = sum(summand1)/sum(summand2);
    end
    
    p_z = null(size(Z_supp,1),1); % the propensity score
    for i=1:size(Z_supp,1)
        p_z(i) = sum((D==1).*(abs(Z-Z_supp(i))<=0.0001))/sum((abs(Z-Z_supp(i))<=0.0001));
    end
    
    % Defining B
    % the left hand side coefficients
    B = [];
    N_B = [];
    for l = 1:dim_p
        d = Bi(l,2);
        y = Bi(l,3);
        z = Bi(l,1);
        delta = null(1,K);
        for m=1:K
            if d == 1
                delta(m) = int(b{m},u,0,p_z(find(abs(Z_supp-z)<=0.0001,1)));
            elseif d == 0
                delta(m) = int(b{m},u,p_z(find(abs(Z_supp-z)<=0.0001,1)),1);
            end
        end
        
        B0 = zeros(K,dim_s);
        
        for j = 1:dim_s
            if Bi_s(j,bi2de(d)+1) == y  % in Bi_s, find the column for y(d) and choose s (decimal value j) s.t. y(my_d) = my_y
                B0(:,j) = 1;
            end
            B0(:,j) = (B0(:,j)'.*delta)';
        end
        B0 = reshape(B0,1,[]);
        B(l,:) = B0;
    end
    
    % Restrictions on conditional probabilities
    % The one without rank similarity assn
    dim = size(B,2);
    zer = zeros(dim,1);
    
    one = null(K,dim);
    for i=1:K
        for j=1:dim
            if mod(j-i,K)==0
                one(i,j) = 1;
            else
                one(i,j) = 0;
            end
        end
    end
    
    % CVX - No Assumption
    % first determine the smallest error
    cvx_clear
    cvx_begin
    variable theta(dim)
    dual variables lambdaEq2 lambdaIneq lambdaIneq2
    minimize( norm(B * theta-p) )
    subject to
    lambdaEq2: one * theta == ones(K,1)
    lambdaIneq: theta >= zer
    cvx_end
    tuning = cvx_optval;
    
    % Choice of Solver:
    cvx_solver sedumi     % For SeDuMi
    % upper bound
    cvx_clear
    cvx_begin
    variable theta(dim)
    dual variables lambdaEq lambdaEq2 lambdaIneq lambdaIneq2
    
    maximize( A * theta )
    subject to
    lambdaEq: norm(B * theta - p)<=tuning + (1e-3)*tuning
    lambdaEq2: one * theta == ones(K,1)
    lambdaIneq: theta >= zer
    cvx_end
    
    UB{K_supp} = cvx_optval;
    
    % lower bound
    cvx_clear
    cvx_begin
    variable theta(dim)
    dual variables lambdaEq lambdaEq2 lambdaIneq lambdaIneq2
    
    minimize( A * theta )
    subject to
    lambdaEq: norm(B * theta - p)<=tuning + (1e-3)*tuning
    lambdaEq2: one * theta == ones(K,1)
    lambdaIneq: theta >= zer
    cvx_end
    
    LB{K_supp} = cvx_optval;
end

%% Manski's bounds
for i=1:length(Z_supp)
    L_1(i,1) = mean(Y(D==1&Z==Z_supp(i)))*(sum(D==1&Z==Z_supp(i))/sum(Z==Z_supp(i)));
    L_2(i,1) = mean(Y(D==0&Z==Z_supp(i)))*(sum(D==0&Z==Z_supp(i))/sum(Z==Z_supp(i)))+sum(D==1&Z==Z_supp(i))/sum(Z==Z_supp(i));
end

for i=1:length(Z_supp)
    U_1(i,1) = mean(Y(D==1&Z==Z_supp(i)))*(sum(D==1&Z==Z_supp(i))/sum(Z==Z_supp(i)))+sum(D==0&Z==Z_supp(i))/sum(Z==Z_supp(i));
    U_2(i,1) = mean(Y(D==0&Z==Z_supp(i)))*(sum(D==0&Z==Z_supp(i))/sum(Z==Z_supp(i)));
end

L = max(L_1)-min(L_2);
U = min(U_1)-max(U_2);

%% Plot
x = 0.01:0.01:0.99;
plot(x,True*ones(99,1),'r','linew',2)
hold on
plot (x,L*ones(99,1),'--','color','r','linew',2)
plot (x,U*ones(99,1),'--','color','r','linew',2,'HandleVisibility','off')
for k=1:5
    plot (x,LB{k}*ones(99,1),'--','color',[0 1 1]*0.1*(12-2*k),'linew',1.5)
    plot (x,UB{k}*ones(99,1),'--','color',[0 1 1]*0.1*(12-2*k),'linew',1.5,'HandleVisibility','off')
end
hold off
title('Bounds on ATE: Different K')
legend('True ATE','Manski Bound', 'K=10', 'K=20', 'K=30','K=40', 'K=50','Location','bestoutside','orientation','horizontal')
xlabel('u \in [0,1]')
set(0,'defaultfigurecolor','w')
