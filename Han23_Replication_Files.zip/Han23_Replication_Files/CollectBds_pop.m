%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Collect bounds from CalBds function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;

%% Preliminaries

T = 2;

tol = 0.01;

% Parameters
pi1 = 1.5;            % Z1 on A1; can't be negative (need to change matrix A)
mu1 = 0.8;            % A1 on Y1; can't be negative (need to change matrix A)
pi2 = [0.8 0.8 1.2];    % (Y1,A1,Z2) on A2; For one IV, set the last element = 0
mu2 = [0.8 1];      % (Y1,A2) on Y2; when the second element is negative, then use bds_M2_neg.m below; in practice, we estimate 'h' to know this sign
%mu2 = [0.4 -0.8 1];     % with interaction term; with these values, use my_integrand3.m

gam = [0 1];   % mean and variance of normal for fixed effect
beta = [0.5 0.3];  % Bernoulli p for Z1 and Z2
pi = [pi1 pi2];
mu = [mu1 mu2];



%% Defining p

dim_p = 2^(3*T);    % number of possibility in (A1,Y1,A2,Y2,Z1,Z2)
Bi = de2bi(0:dim_p-1);    % the order of column: (A1,Y1,A2,Y2,Z1,Z2); each ROW of this matrix correspond to each decimal number

sel_constr = (1:dim_p);

% Population distribution
p_pop = zeros(dim_p,1);
for i = sel_constr
    a1_pop = Bi(i,1);
    y1_pop = Bi(i,2);
    a2_pop = Bi(i,3);
    y2_pop = Bi(i,4);
    z1_pop = Bi(i,5);
    z2_pop = Bi(i,6);
    p_pop(i) = integral(@(a)normpdf(a,gam(1),gam(2))...
        .*my_integrand2(a1_pop,y1_pop,a2_pop,y2_pop,z1_pop,z2_pop,a,pi1,mu1,pi2,mu2,gam),...
        -Inf,Inf);
end



%% Bubble Sort

num_regime = 2^(2*T-1); % number of possible regimes
regime_all = 1:num_regime;
combos = nchoosek(regime_all,2);    % n choose k
sz_combos = size(combos,1);
BD_mat_M1 = -2*ones(sz_combos,2);
BD_mat_M2 = -2*ones(sz_combos,2);
for i = 1:sz_combos % 1:8 when T = 2
    regime1 = combos(i,1);
    regime2 = combos(i,2);
    [BD_mat_M1(i,1), BD_mat_M1(i,2)] = bds_M1(regime1,regime2,p_pop,tol);
end
for i = 1:sz_combos % 1:8 when T = 2
    regime1 = combos(i,1);
    regime2 = combos(i,2);
    [BD_mat_M2(i,1), BD_mat_M2(i,2)] = bds_M2(regime1,regime2,p_pop,tol);
end

% round to 4 digits
BD_mat_M1 = round(BD_mat_M1,4);
BD_mat_M2 = round(BD_mat_M2,4);



%% Plot (Figures 1-6 in the supplemental appendix)

% Bounds
figure(1)
regime_all = 1:8;   % 1:2 ~ 1:8
combos = nchoosek(regime_all,2);    % n choose k

X1 = BD_mat_M1(:,:)';
X2 = BD_mat_M2(:,:)';
Y = [1:sz_combos; 1:sz_combos];
myplot = plot(X1,Y,'black-o',X2,Y,'red-o');
xlim([-1 1])
ylim([0 sz_combos+1])
yticks(1:sz_combos)
str = {};
for i = 1:sz_combos
    str = [str , strcat(num2str(combos(i,1)), {' vs '}, num2str(combos(i,2)))];
end
yticklabels(str)
line([0 0], [0 sz_combos+1],'Color',[0.75 0.75 0.75])
set(myplot,'LineWidth',1)

% DAG
figure(2)
adjmat = compute_adjmat(BD_mat_M2);

G = digraph(adjmat)
h = plot(G,'Layout','Layered','Direction','down')
set(gca, 'XTick', [],'YTick', [])
labelnode(h,[1 2 3 4 5 6 7 8],{'W1' 'W2' 'W3' 'W4' 'W5' 'W6' 'W7' 'W8'})



%{
%% DGP

% Preliminaries

N = 10000;        % sample size
T = 2;

% Parameters

%pi1 = 0.8;
%mu1 = 0.3;
%pi2 = [0.4 0.5 0.6];
%mu2 = [0.5 0.3];
%gam = [0 1.5];   % mean and variance of normal
%beta = [0.5 0.3];  % Bernoulli p for Z1 and Z2

%% Sampling
%% CAUTION: make sure it matches the population p

% Random variables
u = rand(N,2);  % Z1 and Z2 are mutually indep
Z1 = (beta(1) >= u(:,1));
Z2 = (beta(2) >= u(:,2));
sz = size(Z1);
mu_err = [gam(1) gam(1) gam(1) gam(1) gam(1)]; % generate a at the same time
sigma_err = gam(2)*eye(5);
mat_err = mvnrnd(mu_err,sigma_err,N);
v1 = mat_err(:,1);
e1 = mat_err(:,2);
v2 = mat_err(:,3);
e2 = mat_err(:,4);
%a = mat_err(:,5);
a = 0
%v1 = random('Logistic',gam(1),gam(2),sz);
%e1 = random('Logistic',gam(1),gam(2),sz);
%v2 = random('Logistic',gam(1),gam(2),sz);
%e2 = random('Logistic',gam(1),gam(2),sz);
%a = 0;
%a = mean([Z1 Z2],2);   % This violates the exogeneity of Z...

% Potential outcomes (as functions of A's)
Y1_0 = (- (a + e1) >= 0);
Y1_1 = (mu1 - (a + e1) >= 0);
Y2_00 = (mu2(1)*Y1_0 - (a + e2) >= 0);
Y2_01 = (mu2(1)*Y1_0 + mu2(2) - (a + e2) >= 0);
Y2_10 = (mu2(1)*Y1_1 - (a + e2) >= 0);
Y2_11 = (mu2(1)*Y1_1 + mu2(2) - (a + e2) >= 0);

%Y2_0 = (a - e2 >= 0);
%Y2_1 = (mu2(2) + a - e2 >= 0);

% Potential treatments (as functions of Z's)
A1_0 = (-pi1 - (a + v1) >= 0);
A1_1 = (pi1 - (a + v1) >= 0);

A1 = Z1.*A1_1 + (1-Z1).*A1_0;
Y1 = A1.*Y1_1 + (1-A1).*Y1_0;

A2_00 = (pi2(1)*Y1 + pi2(2)*A1_0 - pi2(3) - (a + v2) >= 0);
A2_01 = (pi2(1)*Y1 + pi2(2)*A1_0 + pi2(3) - (a + v2) >= 0);
A2_10 = (pi2(1)*Y1 + pi2(2)*A1_1 - pi2(3) - (a + v2) >= 0);
A2_11 = (pi2(1)*Y1 + pi2(2)*A1_1 + pi2(3) - (a + v2) >= 0);

%A2_0 = (a - v2 >= 0);
%A2_1 = (pi2(3) + a - v2 >= 0);

A2 = Z1.*Z2.*A2_11 + Z1.*(1-Z2).*A2_10 + (1-Z1).*Z2.*A2_01 + (1-Z1).*(1-Z2).*A2_00;
Y2 = A1.*A2.*Y2_11 + A1.*(1-A2).*Y2_10 + (1-A1).*A2.*Y2_01 + (1-A1).*(1-A2).*Y2_00;

%A2 = Z2.*A2_1 + (1-Z2).*A2_0;
%Y2 = A2.*Y2_1 + (1-A2).*Y2_0;

% NOTE: Consider an alternative approach by defining A2_0, A2_1, Y2_0, Y2_1

%{
%% Estimated p
p = zeros(dim_p,1);
for i = sel_constr
    summand1 = (A1==Bi(i,1)).*(Y1==Bi(i,2)).*(A2==Bi(i,3)).*(Y2==Bi(i,4)).*(Z1==Bi(i,5)).*(Z2==Bi(i,6));
    summand2 = (Z1==Bi(i,5)).*(Z2==Bi(i,6));
    p(i) = sum(summand1)/sum(summand2);
end

%diff = norm(p - p_pop);
%}

%% Calculating (estimated) h

summand1 = (Y1==1).*(Z1==1);
summand2 = (Z1==1);
summand3 = (Y1==1).*(Z1==0);
summand4 = (Z1==0);
p1_1 = sum(summand1)/sum(summand2);
p1_0 = sum(summand3)/sum(summand4);

h1 = p1_1 - p1_0;

Bi_past = de2bi(0:2^3-1);    % the order of column: O1 = (A1,Y1,Z1)
h2 = zeros(2^3,1);
for i = 1:2^3
    summand5 = (Y2==1).*(Z2==1).*(Y1==Bi_past(i,1)).*(A1==Bi_past(i,2)).*(Z1==Bi_past(i,3));
    summand6 = (Z2==1).*(Y1==Bi_past(i,1)).*(A1==Bi_past(i,2)).*(Z1==Bi_past(i,3));
    summand7 = (Y2==1).*(Z2==0).*(Y1==Bi_past(i,1)).*(A1==Bi_past(i,2)).*(Z1==Bi_past(i,3));
    summand8 = (Z2==0).*(Y1==Bi_past(i,1)).*(A1==Bi_past(i,2)).*(Z1==Bi_past(i,3));
    p2_1 = sum(summand5)/sum(summand6);
    p2_0 = sum(summand7)/sum(summand8);
    
    h2(i) = p2_1 - p2_0;
end

%summand = (A1==0).*(A2==0).*(Y1==1).*(Y2==1);
%p_test = sum(summand)/N

%}