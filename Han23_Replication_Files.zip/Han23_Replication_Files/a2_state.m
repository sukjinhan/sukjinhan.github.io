%%
%% This function selects all values of r2 that are consistent with A2(a1,y1,z2) = a2
%%

function r2 = a2_state(a1,y1,z2,a2)

% Inputs: (a1,y1,z2)
% Output: 256x1 selector vector for r2 (dim = the card of space of r2)

    k_r2 = 3;  % number of arguments in a2(a1,y1,z2)
    dim_r2 = 2^(2^k_r2);
    Bi_r2 = de2bi((1:dim_r2)'-1);    % value of a2(000),a2(100),a2(010),a2(110),a2(001),a2(101),a2(011),a2(111)

    sel_r2 = bi2de([a1 y1 z2])+1;
    % in Bi_r2, find the column for a2(a1,y1,z2) and choose r2 (decimal value i) s.t. a2(a1,y1,z2) = a2
    r2 = zeros(dim_r2,1);
    for i = 1:dim_r2
        if Bi_r2(i,sel_r2) == a2
            r2(i) = 1;
        end
    end

end