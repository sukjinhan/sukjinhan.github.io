%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Calculate Adjacent Matrix Based on Bounds
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function admat = compute_adjmat(BD_mat)


    % Adjacency matrix.
    admat = zeros(8,8);
    for i= 1:7
        if BD_mat(i,2) <= 0 
            admat(i+1,1) = 1;
        elseif BD_mat(i,2) >0 && BD_mat(i,1) < 0 
            admat(1,i+1) = 0;
        elseif BD_mat(i,1) >= 0
            admat(1,i+1) = 1;
        end
    end    



    for i= 8:13
        if BD_mat(i,2) <= 0 
            admat(i-5,2) = 1;
        elseif BD_mat(i,2) >0 && BD_mat(i,1) < 0 
            admat(2,i-5) = 0;
        elseif BD_mat(i,1) >= 0
            admat(2,i-5) = 1;
        end
    end  
    

    for i= 14:18
        if BD_mat(i,2) <= 0 
            admat(i-10,3) = 1;
        elseif BD_mat(i,2) >0 && BD_mat(i,1) < 0 
            admat(3,i-10) = 0;
        elseif BD_mat(i,1) >= 0
            admat(3,i-10) = 1;
        end
    end  


    for i= 19:22
        if BD_mat(i,2) <= 0 
            admat(i-14,4) = 1;
        elseif BD_mat(i,2) >0 && BD_mat(i,1) < 0 
            admat(4,i-14) = 0;
        elseif BD_mat(i,1) >= 0
            admat(4,i-14) = 1;
        end
    end  
    

    for i= 23:25
        if BD_mat(i,2) <= 0 
            admat(i-17,5) = 1;
        elseif BD_mat(i,2) >0 && BD_mat(i,1) < 0 
            admat(5,i-17) = 0;
        elseif BD_mat(i,1) >= 0
            admat(5,i-17) = 1;
        end
    end  
    

    for i= 26:27
        if BD_mat(i,2) <= 0 
            admat(i-19,6) = 1;
        elseif BD_mat(i,2) >0 && BD_mat(i,1) < 0 
            admat(6,i-19) = 0;
        elseif BD_mat(i,1) >= 0
            admat(6,i-19) = 1;
        end
    end  


    if BD_mat(28,2) <= 0 
        admat(8,7) = 1;
    elseif BD_mat(28,2) >0 && BD_mat(28,1) < 0 
        admat(7,8) = 0;
    elseif BD_mat(28,1) >= 0
        admat(7,8) = 1;
    end

    %admat_real = admat - transpose(admat);

end
