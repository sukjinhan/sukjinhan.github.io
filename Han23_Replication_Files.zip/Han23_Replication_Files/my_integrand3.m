function p0 = my_integrand3(a1,y1,a2,y2,z1,z2,a,pi1,mu1,pi2,mu2,gam)

    quant1 = pi1*z1 - pi1*(1-z1);   % for A1
    quant2 = mu1*a1 - mu1*(1-a1);   % for Y1
    quant3 = pi2(1)*y1 + pi2(2)*a1 + pi2(3)*z2 - pi2(3)*(1-z2); % for A2
    quant4 = mu2(1)*y1 + mu2(2)*a2 - mu2(2)*(1-a2) + mu2(3)*y1*(2*a2-1); % for Y2
    %quant4 = mu2(1)*y1 + mu2(2)*a2 + mu2(3)*y1*a2; % for Y2

    if a1 == 1
        p_a1 = cdf('Normal',quant1,gam(1)+a,gam(2));    % mean is shifted by a
    else
        p_a1 = cdf('Normal',quant1,gam(1)+a,gam(2),'upper');
    end
    if y1 == 1
        p_y1 = cdf('Normal',quant2,gam(1)+a,gam(2));
    else
        p_y1 = cdf('Normal',quant2,gam(1)+a,gam(2),'upper');
    end
    if a2 == 1
        p_a2 = cdf('Normal',quant3,gam(1)+a,gam(2));
    else
        p_a2 = cdf('Normal',quant3,gam(1)+a,gam(2),'upper');
    end
    if y2 == 1
        p_y2 = cdf('Normal',quant4,gam(1)+a,gam(2));
    else
        p_y2 = cdf('Normal',quant4,gam(1)+a,gam(2),'upper');
    end
    
    p0 = p_a1.*p_y1.*p_a2.*p_y2;
    
end