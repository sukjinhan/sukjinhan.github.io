%%
%% This function selects all values of s1 that are consistent with Y1(a1) = y1
%%

function s1 = y1_state(a1,y1)

% Inputs: (a1,y1)
% Output: 4x1 selector vector for s1 (dim = the card of space of s1)

    k_s1 = 1;  % number of arguments in y1(a1)
    dim_s1 = 2^(2^k_s1);
    Bi_s1 = de2bi((1:dim_s1)'-1);    % value of y1(0), y1(1)

    sel_s1 = bi2de(a1)+1;
    % in Bi_s1, find the column for y1(a1) and choose s1 (decimal value i) s.t. y1(a1) = y1
    s1 = zeros(dim_s1,1);
    for i = 1:dim_s1
        if Bi_s1(i,sel_s1) == y1
            s1(i) = 1;
        end
    end

end