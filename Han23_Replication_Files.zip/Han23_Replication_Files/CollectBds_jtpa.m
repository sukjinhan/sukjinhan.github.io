%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Collect bounds from CalBds function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;

%% Loading Data

jtpa_han = tdfread('jtpa_han.tab','\t');
%startRow = 2;
%jtpa_han = textscan(startRow);

recid = jtpa_han.recid;
D2 = jtpa_han.D2;
sex = jtpa_han.sex;
edu = jtpa_han.edu;
prevearn = jtpa_han.prevearn;
n_hs2 = jtpa_han.n_hs2;
n_hs2_abv = jtpa_han.n_hs2_abv;
earnings = jtpa_han.earnings;
Z2 = jtpa_han.Z2;

% Define variables

Z1 = n_hs2_abv;
D1 = (edu >= 12);
%Y1 = (prevearn >= 1600);
Y1 = (prevearn >= 6300);    % 4300, >5300, *6300, 8300; 6300 is 82nd percentile
Y2 = (earnings >= 11187);   % above median or below

D1 = double(D1);
Y1 = double(Y1);
Y2 = double(Y2);

male = find(sex==1);
female = find(sex==0);
all = find(sex>=0);

gender = all;  % choose gender here for conditional analysis

Z1 = Z1(gender);
D1 = D1(gender);
Y1 = Y1(gender);
Z2 = Z2(gender);
D2 = D2(gender);
Y2 = Y2(gender);
N = length(gender);

%%
% When using only Z2
%Z1 = zeros(N,1);
% In this case, use bds_M2_jtpa_Z2.m below

%% Preliminaries
T = 2;
tol = 0.05;

dim_p = 2^(3*T);    % number of possibility in (D1,Y1,D2,Y2,Z1,Z2)
Bi = de2bi(0:dim_p-1);    % the order of column: (D1,Y1,D2,Y2,Z1,Z2); each ROW of this matrix correspond to each decimal number
sel_constr = (1:dim_p);

%% Estimated p
p = zeros(dim_p,1);
for i = sel_constr
    summand1 = (D1==Bi(i,1)).*(Y1==Bi(i,2)).*(D2==Bi(i,3)).*(Y2==Bi(i,4)).*(Z1==Bi(i,5)).*(Z2==Bi(i,6));
    summand2 = (Z1==Bi(i,5)).*(Z2==Bi(i,6));
    p(i) = sum(summand1)/sum(summand2);
end


%% Bubble Sort

num_regime = 2^(2*T-1); % number of possible regimes
regime_all = 1:num_regime;
combos = combntns(regime_all,2);    % n choose k
sz_combos = size(combos,1);
BD_mat_M1 = -2*ones(sz_combos,2);
BD_mat_M2 = -2*ones(sz_combos,2);
%for i = 1:sz_combos % 1:8 when T = 2
%    regime1 = combos(i,1);
%    regime2 = combos(i,2);
%    [BD_mat_M1(i,1), BD_mat_M1(i,2)] = bds_M1(regime1,regime2,p,tol);
%end
for i = 1:sz_combos % 1:8 when T = 2
    regime1 = combos(i,1);
    regime2 = combos(i,2);
    [BD_mat_M2(i,1), BD_mat_M2(i,2)] = bds_M2_jtpa(regime1,regime2,p,tol);  % bds_M2_jtpa_wel2; bds_M2_jtpa_Z2; bds_M2_jtpa_wel2_Z2 
end

% round to 4 digits
BD_mat_M1 = round(BD_mat_M1,4);
BD_mat_M2 = round(BD_mat_M2,4);


%% Plot  (Figures 2 and 3 in the main paper)

set(groot,'defaultAxesTickLabelInterpreter','latex');  
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
figure('DefaultAxesFontSize',13);

% Bounds
figure(1)
regime_all = 1:8;   % 1:2 ~ 1:8
combos = combntns(regime_all,2);    % n choose k

X1 = BD_mat_M1(:,:)';
X2 = BD_mat_M2(:,:)';
Y = [1:sz_combos; 1:sz_combos];
myplot = plot(X1,Y,'black-o',X2,Y,'red-o');
xlim([-1 1])
ylim([0 sz_combos+1])
yticks(1:sz_combos)
str = {};
for i = 1:sz_combos
    str = [str , strcat(num2str(combos(i,1)), {' vs '}, num2str(combos(i,2)))];
end
yticklabels(str)
line([0 0], [0 sz_combos+1],'Color',[0.75 0.75 0.75])
set(myplot,'LineWidth',1)

% DAG
figure(2)
adjmat = compute_adjmat(BD_mat_M2);

G = digraph(adjmat);
h = plot(G,'Layout','Layered','Direction','down');
set(gca, 'XTick', [],'YTick', [])
labelnode(h,[1 2 3 4 5 6 7 8],{'W1' 'W2' 'W3' 'W4' 'W5' 'W6' 'W7' 'W8'})



%% Calculating (estimated) h
% Under M2, the sign of h is the sign of treatment effect 
% See Shaikh and Vytlacil (2011, Econometrica) for related results
% The sign info is used to construct matrix A in bds_M2_jtpa.m

%Y1 = (prevearn >= 6300);    % 4300, >5300, *6300 (for all or male), *8300 (for female)
%gender = male;  % choose gender here for conditional analysis

%Z1 = Z1(gender);
%D1 = D1(gender);
%Y1 = Y1(gender);
%Z2 = Z2(gender);
%D2 = D2(gender);
%Y2 = Y2(gender);

summand1 = (Y1==1).*(Z1==1);
summand2 = (Z1==1);
summand3 = (Y1==1).*(Z1==0);
summand4 = (Z1==0);
p1_1 = sum(summand1)/sum(summand2);
p1_0 = sum(summand3)/sum(summand4);

h1 = p1_1 - p1_0;

Bi_past = de2bi(0:2^2-1);    % the order of column: O1 = (Y1,D1)
h2 = zeros(2^2,1);
for i = 1:2^2
    summand5 = (Y2==1).*(Z2==1).*(Y1==Bi_past(i,1)).*(D1==Bi_past(i,2));
    summand6 = (Z2==1).*(Y1==Bi_past(i,1)).*(D1==Bi_past(i,2));
    summand7 = (Y2==1).*(Z2==0).*(Y1==Bi_past(i,1)).*(D1==Bi_past(i,2));
    summand8 = (Z2==0).*(Y1==Bi_past(i,1)).*(D1==Bi_past(i,2));
    p2_1 = sum(summand5)/sum(summand6);
    p2_0 = sum(summand7)/sum(summand8);
    
    h2(i) = p2_1 - p2_0;
end



