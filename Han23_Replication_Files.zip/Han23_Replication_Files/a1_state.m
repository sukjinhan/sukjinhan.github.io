%%
%% This function selects all values of r1 that are consistent with A1(z1) = a1
%%

function r1 = a1_state(z1,a1)

% Inputs: (z1,a1)
% Output: 4x1 selector vector for r1 (dim = the card of space of r1)

    k_r1 = 1;  % number of arguments in a1(z1)
    dim_r1 = 2^(2^k_r1);
    Bi_r1 = de2bi((1:dim_r1)'-1);    % value of a1(0), a1(1)

    sel_r1 = bi2de(z1)+1;
    % in Bi_r1, find the column for a1(z1) and choose r1 (decimal value i1) s.t. a1(z1) = a1
    r1 = zeros(dim_r1,1);
    for i = 1:dim_r1
        if Bi_r1(i,sel_r1) == a1
            r1(i) = 1;
        end
    end

end