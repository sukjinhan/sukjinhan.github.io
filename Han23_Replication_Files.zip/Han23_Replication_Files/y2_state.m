%%
%% This function selects all values of s2 that are consistent with Y2(y1,a2) = y2
%%

function s2 = y2_state(y1,a2,y2)

% Inputs: (y1,a2)
% Output: 16x1 selector vector for s2 (dim = the card of space of s2)

    k_s2 = 2;  % number of arguments in y2(y1,a2)
    dim_s2 = 2^(2^k_s2);
    Bi_s2 = de2bi((1:dim_s2)'-1);    % value of y2(00),y2(10),y2(01),y2(11)

    sel_s2 = bi2de([y1 a2])+1;
    % in Bi_s2, find the column for y2(y1,a2) and choose s2 (decimal value i) s.t. y2(y1,a2) = y2
    s2 = zeros(dim_s2,1);
    for i = 1:dim_s2
        if Bi_s2(i,sel_s2) == y2
            s2(i) = 1;
        end
    end

end