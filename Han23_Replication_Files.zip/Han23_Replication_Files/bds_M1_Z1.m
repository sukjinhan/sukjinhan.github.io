%%
%% This function calculates bounds on welfare E[Y(d(.))]
%% With only Z1


function [LB, UB] = bds_M1_Z1(regime1,regime2,p,tol)


%% Preliminaries
dim_r1 = 2^2;   % size(r1,1)
dim_s1 = 2^2;   % size(s1,1)
dim_r2 = 2^8;   % size(r2,1)
dim_s2 = 2^4;   % size(s2,1)
%d = dim_r1*dim_s1*dim_r2*dim_s2;
%d = 2^2 * 2^2 * 2^8 * 2^4; % Dim of q = 65536


%% Incorporating Assumption M1

A = zeros(dim_r1,dim_s1,dim_r2,dim_s2);

% for A
% for t = 1    
% finding defiers
r1_01 = a1_state(0,1);  % r1 = a1_state(z1,a1)
r1_10 = a1_state(1,0);  % r1 = a1_state(z1,a1)
% finding compliers
%r1_00 = a1_state(0,0);  % r1 = a1_state(z1,a1)
%r1_11 = a1_state(1,1);  % r1 = a1_state(z1,a1)
for i = 1:dim_r1
    if r1_01(i)==1 && r1_10(i)==1
        A(i,:,:,:) = -1;
    end
end
%{
% for t = 2
Bi_M1 = de2bi(0:2^2-1);    % combi of (A1,Y1,A2,Z1); each ROW of this matrix correspond to each decimal number
for l = 1:size(Bi_M1,1)
    a1 = Bi_M1(l,1);
    y1 = Bi_M1(l,2);
    
    % Comment with only Z1
    % finding defiers
    r2_01 = a2_state(a1,y1,0,1);    % r2 = a2_state(a1,y1,z2,a2)
    r2_10 = a2_state(a1,y1,1,0);    % r2 = a2_state(a1,y1,z2,a2)
    % finding compliers
    r2_00 = a2_state(a1,y1,0,0);    % r2 = a2_state(a1,y1,z2,a2)
    r2_11 = a2_state(a1,y1,1,1);    % r2 = a2_state(a1,y1,z2,a2)

    for i3 = 1:dim_r2
        if (r2_01(i3)==1 && r2_10(i3)==1) ...
            || (r2_00(i3)==1 && r2_11(i3)==1)
            A(:,:,i3,:) = -1;
        end
    end
end
%}

A = reshape(A,1,[]);

%% Defining B
% for Pr[Y1(a1) = 1, Y2(a1,a2) = 1] + Pr[Y1(a1) = 0, Y2(a1,a2) = 1]
% First regime
Bi_regime = de2bi(0:7); % When T = 2
my_a1 = Bi_regime(regime1,1);
my_y1 = 1;
my_a2 = Bi_regime(regime1,2);
my_y2 = 1;

s1 = y1_state(my_a1,my_y1);
s2 = y2_state(my_y1,my_a2,my_y2);

B1 = zeros(dim_r1,dim_s1,dim_r2,dim_s2);
for i = 1:dim_s1
    for j = 1:dim_s2
        if s1(i)==1 && s2(j)==1   % y1(a1) = 1 & y2(1,a2) = 1
            B1(:,i,:,j) = 1;
        end
    end
end

B1 = reshape(B1,1,[]);
B1(A==-1) = [];     % incorporating assumptions

my2_a1 = Bi_regime(regime1,1);
my2_y1 = 0;
my2_a2 = Bi_regime(regime1,3);
my2_y2 = 1;

s1 = y1_state(my2_a1,my2_y1);
s2 = y2_state(my2_y1,my2_a2,my2_y2);

B2 = zeros(dim_r1,dim_s1,dim_r2,dim_s2);
for i = 1:dim_s1
    for j = 1:dim_s2
        if s1(i)==1 && s2(j)==1   % y1(a1) = 0 & y2(0,a2) = 1
            B2(:,i,:,j) = 1;
        end
    end
end

B2 = reshape(B2,1,[]);
B2(A==-1) = [];     % incorporating assumptions

% Second regime
my_a1 = Bi_regime(regime2,1);
my_y1 = 1;
my_a2 = Bi_regime(regime2,2);
my_y2 = 1;

s1 = y1_state(my_a1,my_y1);
s2 = y2_state(my_y1,my_a2,my_y2);

B3 = zeros(dim_r1,dim_s1,dim_r2,dim_s2);
for i = 1:dim_s1
    for j = 1:dim_s2
        if s1(i)==1 && s2(j)==1   % y1(a1) = 1 & y2(1,a2) = 1
            B3(:,i,:,j) = 1;
        end
    end
end

B3 = reshape(B3,1,[]);
B3(A==-1) = [];     % incorporating assumptions

my2_a1 = Bi_regime(regime2,1);
my2_y1 = 0;
my2_a2 = Bi_regime(regime2,3);
my2_y2 = 1;

s1 = y1_state(my2_a1,my2_y1);
s2 = y2_state(my2_y1,my2_a2,my2_y2);

B4 = zeros(dim_r1,dim_s1,dim_r2,dim_s2);
for i = 1:dim_s1
    for j = 1:dim_s2
        if s1(i)==1 && s2(j)==1   % y1(a1) = 0 & y2(0,a2) = 1
            B4(:,i,:,j) = 1;
        end
    end
end

B4 = reshape(B4,1,[]);
B4(A==-1) = [];     % incorporating assumptions

B = (B1 + B2) - (B3 + B4);
B_1 = B1 - B3;
B_2 = B2 - B4;


%% Defining D

dim_p = size(p,1);
% Debugging with constraints
%sel_constr = (1:dim_p-19);
%sel_constr = [(1:44) (53:64)];
%sel_constr = [(1:12) (22:64)];
sel_constr = (1:dim_p);

Bi = de2bi(0:dim_p-1);    % the order of column: (A1,Y1,A2,Y2,Z1,Z2); each ROW of this matrix correspond to each decimal number

%D = zeros(dim_p,d);
D = [];
for l = sel_constr
    % focus on p(l) and find corresponding (a1,y1,a2,y2,z1,z2) in p(a1,y1,a2,y2|z1,z2)
    a1 = Bi(l,1);
    y1 = Bi(l,2);
    a2 = Bi(l,3);
    y2 = Bi(l,4);
    z1 = Bi(l,5);
    z2 = Bi(l,6);
    
    r1 = a1_state(z1,a1);
    s1 = y1_state(a1,y1);
    r2 = a2_state(a1,y1,z2,a2);
    s2 = y2_state(y1,a2,y2);

    D0 = zeros(dim_r1,dim_s1,dim_r2,dim_s2);
    for i1 = 1:dim_r1
        for i2 = 1:dim_s1
            for i3 = 1:dim_r2
                for i4 = 1:dim_s2
                    if r1(i1) == 1 && s1(i2) == 1 && r2(i3) == 1 && s2(i4) == 1
                        D0(i1,i2,i3,i4) = 1;
                    end
                end
            end
        end
    end
    
    D0 = reshape(D0,1,[]);
    D0(A==-1) = [];     % incorporating assumptions
    D(l,:) = D0; 

end


%% CVX
d = size(D,2);
%D_short = D([(1:15) (17:31) (33:47) (49:63)],:);
%p_short = p([(1:15) (17:31) (33:47) (49:63)]);
D_short = D([(1:15) (17:31)],:);    % for only Z1
p_short = p([(1:15) (17:31)]);      % for only Z1
one = ones(1,d);
zer = zeros(d,1);

% Choice of Solver:

%cvx_solver sedumi     % For SeDuMi
%cvx_solver mosek      % For MOSEK
%cvx_solver sdpt3        % For SDPT3
cvx_solver gurobi

cvx_clear
cvx_begin 
    variable q(d)
    dual variables lambdaIneq0
%    dual variables lambdaEq lambdaIneq lambdaBds
    minimize( norm([D_short; one] * q - [p_short; 1]) )
    subject to
    lambdaIneq0: q >= zer
cvx_end

min_dev = cvx_optval;

cvx_clear
cvx_begin 
    variable q(d)
    dual variables lambdaEq lambdaEq1 lambdaIneq
%    dual variables lambdaEq lambdaIneq lambdaBds
    maximize( B * q )
    subject to 
%    lambda: D * q == p
%    lambdaEq: D_short * q == p_pop_short
    lambdaEq: norm([D_short; one] * q - [p_short; 1]) <= min_dev + tol  % To allow estimation error in p
%    lambdaEq1: one * q == 1
    lambdaIneq: q >= zer
cvx_end

UB = cvx_optval;

cvx_clear
cvx_begin 
    variable q(d)
    dual variables lambdaEq2 lambdaEq12 lambdaIneq2
%    dual variables lambdaEq lambdaIneq lambdaBds
    minimize( B * q )
    subject to 
%    lambda: D * q == p
%    lambdaEq2: D_short * q == p_pop_short
    lambdaEq2: norm([D_short; one] * q - [p_short; 1]) <= min_dev + tol  % To allow estimation error in p; or when problem with some B
%    lambdaEq12: one * q == 1
    lambdaIneq2: q >= zer
cvx_end

LB = cvx_optval;

%BDS = [LB UB];

end




