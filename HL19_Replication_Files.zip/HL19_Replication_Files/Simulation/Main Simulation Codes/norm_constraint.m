function [c,ceq] = norm_constraint(par, dx, dz, kk, beta_base, alpha_base, rho_H, rho_L) 

alpha = par(1:dx) ;
%gamma = par(dx+1:dx+dz) ;
beta = par(dx+dz+1:dx+dz+dx) ;
%delta = par(dx+dz+dx+1) ;
rho = par(kk) ;
sigmae = par(kk+3) ;
sigmav = par(kk+4) ;

%sieve_par_e = [xie; conse] ;
%sieve_par_v = [xiv; consv] ;

%c = [] ;
c(1) = rho - rho_H ;
c(2) = rho_L - rho; 
c(3) = 1e-10 - sigmae ;
c(4) = 1e-10 - sigmav ; 

ceq(1) = beta(1) - beta_base ;
ceq(2) = alpha(1) - alpha_base ;
