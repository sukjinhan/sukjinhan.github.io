function [c,ceq] = semi_constraint_emp(par, cop_opt, dx, dz, beta_base, alpha_base, fix)


kk = 2*dx + dz + 2 ;

alpha = par(1:dx) ;
%gamma = par(dx+1:dx+dz) ;
beta = par(dx+dz+1:dx+dz+dx) ;
%delta = par(dx+dz+dx+1) ;
rho = par(kk) ;
%xie = par(kk+1:kk+kne) ;
%conse = par(kk+kne+1) ;
%xiv = par(kk+kne+2:kk+kne+1+knv) ;
%consv = par(kk+kne+knv+2) ;

%sieve_par_e = [xie; conse] ;
%sieve_par_v = [xiv; consv] ;

%c = [] ;

if cop_opt == 0 
    c(1) = rho - 0.9 ;
    c(2) = -0.9 - rho; 
    
end

if cop_opt == 2 
    c(1) = rho + 0.01 ;
    c(2) = -10 - rho ;
end

%ceq(1) = conse - 1 ; 
%ceq(2) = consv - 1 ;
ceq(1) = beta(fix) - beta_base ;
ceq(2) = alpha(fix) - alpha_base ;


