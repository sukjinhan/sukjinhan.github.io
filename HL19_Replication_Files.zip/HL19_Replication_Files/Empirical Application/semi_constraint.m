function [c,ceq] = semi_constraint(par, dx, dz, kk, kne, knv, beta_base, alpha_base) 

alpha = par(1:dx) ;
%gamma = par(dx+1:dx+dz) ;
beta = par(dx+dz+1:dx+dz+dx) ;
%delta = par(dx+dz+dx+1) ;
rho = par(kk) ;
%xie = par(kk+1:kk+kne) ;
conse = par(kk+kne+1) ;
%xiv = par(kk+kne+2:kk+kne+1+knv) ;
consv = par(kk+kne+knv+2) ;

%sieve_par_e = [xie; conse] ;
%sieve_par_v = [xiv; consv] ;

%c = [] ;
c(1) = rho - 0.8 ;
c(2) = -0.8 - rho; 

%ceq(1) = conse - 1 ; 
%ceq(2) = consv - 1 ;
ceq(1) = beta(1) - beta_base ;
ceq(2) = alpha(1) - alpha_base ;


