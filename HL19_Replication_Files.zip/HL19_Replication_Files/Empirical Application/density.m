function density = density(x, par, kn) 

xi = par(1:kn) ;
cons = par(kn+1) ;

num_lin = 0 ;
num_sq = 0 ;
denom_lin = 0 ;
denom_sq = 0 ;


for i = 1 : kn
    num_lin = num_lin + (xi(i).* (x.^i)) ;
    denom_lin = denom_lin + (xi(i) .* (1/(i+1))) ;
    
    for j = 1:kn
        
        num_sq = num_sq + (xi(i) .* xi(j) .* (x.^(i+j))) ;
        denom_sq = denom_sq + (xi(i) .* xi(j) .* (1/(i+j+1))) ;
        
    end
end
num_lin = 2 * cons .* num_lin ;
denom_lin = 2 * cons .* denom_lin ; 

num = cons.^2 + num_lin + num_sq ;
denom = cons.^2 + denom_lin + denom_sq ;

density = num ./ denom ; 


        
