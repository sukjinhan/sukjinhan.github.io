function F = mnpdf(X, mu, sigma, mix)

F = mix*normpdf(X, mu(1), sigma(1)) + (1-mix)*normpdf(X, mu(2), sigma(2));