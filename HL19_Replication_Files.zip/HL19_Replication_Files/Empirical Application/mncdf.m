function F = mncdf(X, mu, sigma, mix)

F = mix*normcdf(X, mu(1), sigma(1)) + (1-mix)*normcdf(X, mu(2), sigma(2));
