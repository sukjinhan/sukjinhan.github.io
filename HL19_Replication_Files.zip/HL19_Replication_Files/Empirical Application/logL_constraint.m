function [c,ceq] = logL_constraint(par, dx, dz, cop_opt) 

rho = par(2*dx+dz+2);

if cop_opt == 0 
    c(1) = rho - 0.8 ;
    c(2) = -0.8 - rho ;
    
end

if cop_opt == 2
    c(1) = rho + 0.1 ;
    c(2) = -6 - rho ;
end

ceq =[] ;
