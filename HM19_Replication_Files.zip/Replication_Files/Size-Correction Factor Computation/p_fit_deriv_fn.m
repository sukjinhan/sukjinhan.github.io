function p_fit_deriv = p_fit_deriv_fn(ind, theta)

%This function calculates the first derivative vector wrt theta of the fitted probabilities P(Y=h, D=j|Z=k) under
%parameter values theta = (alpha, delta, beta1, beta2, beta3), where ind =
%(h,j,k)

if ind == [1 1 0]
    p_fit_deriv = [0 cop_deriv_fn(2,theta(4),theta(2),theta(5)) 0 cop_deriv_fn(1,theta(4),theta(2),theta(5)) cop_deriv_fn(3,theta(4),theta(2),theta(5))];
elseif ind == [1 1 1]
    p_fit_deriv = [cop_deriv_fn(2,theta(4),theta(2)+theta(1),theta(5)) cop_deriv_fn(2,theta(4),theta(2)+theta(1),theta(5)) 0 cop_deriv_fn(1,theta(4),theta(2)+theta(1),theta(5)) cop_deriv_fn(3,theta(4),theta(2)+theta(1),theta(5))];
elseif ind == [1 0 0]
    p_fit_deriv = [0 -cop_deriv_fn(2,theta(3),theta(2),theta(5)) 1-cop_deriv_fn(1,theta(3),theta(2),theta(5)) 0 -cop_deriv_fn(3,theta(3),theta(2),theta(5))];
elseif ind == [1 0 1]
    p_fit_deriv = [-cop_deriv_fn(2,theta(3),theta(2)+theta(1),theta(5)) -cop_deriv_fn(2,theta(3),theta(2)+theta(1),theta(5)) 1-cop_deriv_fn(1,theta(3),theta(2)+theta(1),theta(5)) 0 -cop_deriv_fn(3,theta(3),theta(2)+theta(1),theta(5))];
elseif ind == [0 1 0]
    p_fit_deriv = [0 1-cop_deriv_fn(2,theta(4),theta(2),theta(5)) 0 -cop_deriv_fn(1,theta(4),theta(2),theta(5)) -cop_deriv_fn(3,theta(4),theta(2),theta(5))];
elseif ind == [0 1 1]
    p_fit_deriv = [1-cop_deriv_fn(2,theta(4),theta(2)+theta(1),theta(5)) 1-cop_deriv_fn(2,theta(4),theta(2)+theta(1),theta(5)) 0 -cop_deriv_fn(1,theta(4),theta(2)+theta(1),theta(5)) -cop_deriv_fn(3,theta(4),theta(2)+theta(1),theta(5))];
elseif ind == [0 0 0]
    p_fit_deriv = [0 -1+cop_deriv_fn(2,theta(3),theta(2),theta(5)) -1+cop_deriv_fn(1,theta(3),theta(2),theta(5)) 0 cop_deriv_fn(3,theta(3),theta(2),theta(5))];
elseif ind == [0 0 1]
    p_fit_deriv = [-1+cop_deriv_fn(2,theta(3),theta(2)+theta(1),theta(5)) -1+cop_deriv_fn(2,theta(3),theta(2)+theta(1),theta(5)) -1+cop_deriv_fn(1,theta(3),theta(2)+theta(1),theta(5)) 0 cop_deriv_fn(3,theta(3),theta(2)+theta(1),theta(5))];
end
