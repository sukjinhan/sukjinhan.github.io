format long

load local_quant_emp

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This code computes the size-correction factor necessary for using with the
%adjusted-Bonferroni CVs used for the threshold crossing model in HM.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%User-chosen Inputs
a = 0.5; %nominal level of CI used in cv construciton
pi_0 = [0.01:0.1:0.91]; %Not consistently estimable
zetatil_hat = 0.306; %0.2; %Consistently estimable
phiz_hat = 0.339; %0.5; %Consistently estimable
quant_level = 0.95;
n = 184171; %1000; %Sample size
b_grid = [-13:0.25:0];

CIb_quant = chi2inv(a,1);
SC_pre = zeros(length(b_grid),length(pi_0));

for j=1:length(pi_0) %Note: parfor loop inside of local_quantile_gen
    thetatil_true = [-0.0137;zetatil_hat;0.026;0.0782;pi_0(j)];%[0.4;zetatil_hat;0.6;0.4;pi_0(j)]; %Not consistently estimable but only used to compute p_hat
    p_hat = [p_fit_fn([1 1 0],thetatil_true);p_fit_fn([1 0 0],thetatil_true)]; %Consistently estimable
    for i=1:length(b_grid) %Note: parfor loop inside of local_quantile_gen
        SC_pre(i,j) = SC_factor_gen_fn(b_grid(i),pi_0(j),zetatil_hat,p_hat, phiz_hat, quant_level, n, CIb_quant, local_quant);
    end;
end;

SC_factor = max(SC_pre);