function G_tilde_process = G_tilde_process_fn(tilde_Z, theta_0, pi)

%This function calculate the asymptotic stochastic process G-tilde for the maximum
%likelihood criterion function for the Threshold Crossing Model. tilde_Z is the
%8-by-1 realization of a correlated normal random variable.

psi_0 = [theta_0(1); theta_0(2); theta_0(3); theta_0(4)];

M = (dec2bin(0:(2^3)-1)=='1')*eye(3);

%G-tilde process
G_tilde_process = zeros(4,1);

for j=1:length(M)
    G_tilde_process = G_tilde_process+tilde_Z(j)*p_bar_grad_fn(M(j,:)',[psi_0;pi])/p_bar_fn(M(j,:)',[psi_0;pi]);
end