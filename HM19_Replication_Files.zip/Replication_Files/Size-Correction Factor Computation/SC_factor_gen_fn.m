function SC_factor_gen = SC_factor_gen_fn(b,pi_0,zetatil_hat,p_hat, phiz_hat, quant_level, n, CIb_quant, local_quant)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This function computes the size-correction factor necessary for using with the
%adjusted-Bonferroni CVs used for the threshold crossing model in HM if one
%new the (not consistently estimable) parameters b and pi_0.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

theta_0 = [0;zetatil_hat;p_hat(1);p_hat(2);pi_0];
R = 10000;  %Number of replications
pi_H = 0.99; %Upper and lower bound in optimization
pi_L = -0.99;
pitil_20 = h1_fn(2,zetatil_hat,p_hat(1),p_hat(2),pi_0); %True value of tildepi_2 implied by zetatil_hat, p_hat and pi_0

%%Simulation Preliminaries
options = optimset('LargeScale','off', ...
               'HessUpdate','bfgs', ...
               'Algorithm', 'active-set',...
               'Hessian','off', ...
               'GradObj','off', ...
               'DerivativeCheck','off',...
               'Display', 'off');
Wald_stat = zeros(R,1);
cv = zeros(R,1);
pitil2_star = zeros(R,1);

%Generate Covariance Matrix for Z-tilde
M = (dec2bin(0:(2^3)-1)=='1')*eye(3);
Omega_tilde = zeros(length(M),length(M));
phi_vec = zeros(length(M),1);
for j=1:2:(length(M)-1)
    phi_vec(j) = phiz_hat;
    phi_vec(j+1) = 1-phiz_hat;
end
for j=1:length(M)
    for i=1:length(M)
        if i==j
            Omega_tilde(i,j) = p_bar_fn(M(j,:)', theta_0)*phi_vec(j)*(1-p_bar_fn(M(j,:)', theta_0)*phi_vec(j));
        else
            Omega_tilde(i,j) = -p_bar_fn(M(i,:)', theta_0)*p_bar_fn(M(j,:)', theta_0)*phi_vec(j)*phi_vec(i);
        end
    end
end
sqrt_Omega_tilde = sqrtm(Omega_tilde);

parfor r = 1:R
    tilde_Z = sqrt_Omega_tilde*randn(length(M),1);
    [pi_star, Q_unres] = fmincon(@(pi)stoch_process_fn(tilde_Z, theta_0, phi_vec, pi, b),0.2, [], [], [], [], pi_L, pi_H, [], options);
    pi_star = real(pi_star);
    tau_star = -(H_mtx_fn(pi_star,theta_0,phi_vec))\(G_tilde_process_fn(tilde_Z,theta_0,pi_star)+K_vec_fn(pi_star,theta_0,phi_vec)*b)-[b;zeros(3,1)];
    beta_star = real(b/sqrt(n)+tau_star(1)/sqrt(n));
    zetatil_star = real(theta_0(2)+tau_star(2)/sqrt(n));
    xi1_star = real(theta_0(3)+tau_star(3)/sqrt(n));
    xi2_star = real(theta_0(4)+tau_star(4)/sqrt(n));
    pi1_star = [h1_fn(1, zetatil_star, xi1_star, xi2_star, pi_star);h1_fn(2, zetatil_star, xi1_star, xi2_star, pi_star)];
    pitil1_star = real(pi1_star(1));
    pitil2_star(r) = real(pi1_star(2));
    thetatil_est = [beta_star;zetatil_star;pitil1_star;pitil2_star(r);pi_star];
    asy_var_est = var_theta_fn(thetatil_est)/phiz_hat;
    Wald_stat(r) = n*(pitil2_star(r)-pitil_20)^2/(asy_var_est(4,4));
    CIb_lb = min(0,b+beta_star-sqrt(asy_var_est(1,1)*CIb_quant));
    CIb_ub = min(0,b+beta_star+sqrt(asy_var_est(1,1)*CIb_quant));
    cv(r) = max(local_quant(max((round(4*CIb_lb)+53),1):max((round(4*CIb_ub)+53),1)));
end

sorted_diff = sort(Wald_stat-cv);
SC_factor_gen = sorted_diff(floor(R*quant_level));