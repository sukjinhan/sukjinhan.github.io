function p_bar_hess = p_bar_hess_fn(ind, theta)

%This function computes the Hessian of the fitted probabilities wrt psi (first four elements of theta) in terms of the transformed
%parameter theta.  ind is a 3-by-1 vector denoting the values of
%(y,d,z) in the fitted probability. theta=(alpha,delta,xi1,xi2,pi)=(psi,pi)

theta_sym = sym('theta_sym',[5 1]);

p_bar_hess_sym = hessian(p_bar_fn(ind,theta_sym),[theta_sym(1);theta_sym(2);theta_sym(3);theta_sym(4)]);
p_bar_hess = double(subs(p_bar_hess_sym,theta_sym,theta));