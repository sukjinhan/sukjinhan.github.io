function stoch_process = stoch_process_fn(tilde_Z, theta_0, phi_vec, pi, a)

%This function calculates the asymptotic stochasstic process for the maximum
%likelihood criterion function for the Threshold Crossing Model. tilde_Z is the
%8-by-1 realization of a correlated normal random variable. a is the
%localization parameter

psi_0 = [theta_0(1); theta_0(2); theta_0(3); theta_0(4)];

M = (dec2bin(0:(2^3)-1)=='1')*eye(3);

%G-tilde process
G_tilde = zeros(4,1);


for j=1:length(M)
    G_tilde = G_tilde+tilde_Z(j)*p_bar_grad_fn(M(j,:)',[psi_0;pi])/p_bar_fn(M(j,:)',[psi_0;pi]);
end

%QLR Statistic
stoch_process = -0.5*(G_tilde+K_vec_fn(pi,theta_0,phi_vec)*a)'*((H_mtx_fn(pi,theta_0,phi_vec))\(G_tilde+K_vec_fn(pi,theta_0,phi_vec)*a));