function SR_AR = SR_AR_fn(pitil_2, thetatilminus, indicator, n, cvchisq4, cvchisq5)

%This function calculates the SR-AR statistic at the null hypothesized value
%thetatil=[thetatilminus(1);thetatilminus(2);thetatilminus(3);pitil_2;thetatilminus(4)]
%given the data in indicator

indmat = [1 1 0; 1 1 1; 1 0 0; 1 0 1; 0 1 0; 0 1 1; 0 0 0; 0 0 1];

thetatil_sym = sym('thetatil_sym',[5 1]);
log_p_fit_grad_sym1 = gradient(log_p_fit_fn(indmat(1,:),thetatil_sym),thetatil_sym);
log_p_fit_grad_sym2 = gradient(log_p_fit_fn(indmat(2,:),thetatil_sym),thetatil_sym);
log_p_fit_grad_sym3 = gradient(log_p_fit_fn(indmat(3,:),thetatil_sym),thetatil_sym);
log_p_fit_grad_sym4 = gradient(log_p_fit_fn(indmat(4,:),thetatil_sym),thetatil_sym);
log_p_fit_grad_sym5 = gradient(log_p_fit_fn(indmat(5,:),thetatil_sym),thetatil_sym);
log_p_fit_grad_sym6 = gradient(log_p_fit_fn(indmat(6,:),thetatil_sym),thetatil_sym);
log_p_fit_grad_sym7 = gradient(log_p_fit_fn(indmat(7,:),thetatil_sym),thetatil_sym);
log_p_fit_grad_sym8 = gradient(log_p_fit_fn(indmat(8,:),thetatil_sym),thetatil_sym);

log_p_fit_grad = zeros(5,8);
thetatil = [thetatilminus(1);thetatilminus(2);thetatilminus(3);pitil_2;thetatilminus(4)];
log_p_fit_grad(:,1) = double(subs(log_p_fit_grad_sym1,thetatil_sym,thetatil));
log_p_fit_grad(:,2) = double(subs(log_p_fit_grad_sym2,thetatil_sym,thetatil));
log_p_fit_grad(:,3) = double(subs(log_p_fit_grad_sym3,thetatil_sym,thetatil));
log_p_fit_grad(:,4) = double(subs(log_p_fit_grad_sym4,thetatil_sym,thetatil));
log_p_fit_grad(:,5) = double(subs(log_p_fit_grad_sym5,thetatil_sym,thetatil));
log_p_fit_grad(:,6) = double(subs(log_p_fit_grad_sym6,thetatil_sym,thetatil));
log_p_fit_grad(:,7) = double(subs(log_p_fit_grad_sym7,thetatil_sym,thetatil));
log_p_fit_grad(:,8) = double(subs(log_p_fit_grad_sym8,thetatil_sym,thetatil));

g = log_p_fit_grad*indicator';
ghat = sum(g,2)/n;
Omegahat = zeros(5,5);
for k=1:n
    Omegahat = Omegahat+g(:,k)*g(:,k)'/n;
end
Omegahat = Omegahat-ghat*ghat';
[V_Omega,D_Omega] = eig(Omegahat);
if D_Omega(1,1)>1e-15
    SR_AR = n*ghat'*(Omegahat\ghat)-cvchisq5;
else
    Ahat = V_Omega(:,2:5);
    gAhat = Ahat'*ghat;
    OmegaAhat = Ahat'*Omegahat*Ahat;
    SR_AR = n*gAhat'*(OmegaAhat\gAhat)-cvchisq4;
end
    