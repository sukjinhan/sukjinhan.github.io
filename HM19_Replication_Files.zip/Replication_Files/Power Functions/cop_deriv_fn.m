function cop_deriv = cop_deriv_fn(ind, x, y, z)

%This function calculates the partial derivatives of the AMH copula.  ind
%denotes which argument the derivative is wrt.

if ind == 1
    cop_deriv = y*(1-z*(1-y))/((1-z*(1-x)*(1-y))^2);
elseif ind == 2
    cop_deriv = x*(1-z*(1-x))/((1-z*(1-x)*(1-y))^2);
elseif ind == 3
    cop_deriv = x*y*(1-x)*(1-y)/((1-z*(1-x)*(1-y))^2);
end