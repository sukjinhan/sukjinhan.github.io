function p_fit = p_fit_fn(ind, thetatil)

%This function calculates the fitted probabilities P(Y=h, D=j|Z=k) under
%parameter values thetatil = (beta, zetatil, pitil_1, pitil_2, pitil_3), 
%where ind = (h,j,k)

%Define local fn copula
copula = @(x,y,z)(x*y/(1-z*(1-x)*(1-y)));

if ind == [1 1 0]
    p_fit = copula(thetatil(4),thetatil(2),thetatil(5));
elseif ind == [1 1 1]
    p_fit = copula(thetatil(4),thetatil(2)+thetatil(1),thetatil(5));
elseif ind == [1 0 0]
    p_fit = thetatil(3)-copula(thetatil(3),thetatil(2),thetatil(5));
elseif ind == [1 0 1]
    p_fit = thetatil(3)-copula(thetatil(3),thetatil(2)+thetatil(1),thetatil(5));
elseif ind == [0 1 0]
    p_fit = thetatil(2)-copula(thetatil(4),thetatil(2),thetatil(5));
elseif ind == [0 1 1]
    p_fit = thetatil(2)+thetatil(1)-copula(thetatil(4),thetatil(2)+thetatil(1),thetatil(5));
elseif ind == [0 0 0]
    p_fit = 1-thetatil(3)+copula(thetatil(3),thetatil(2),thetatil(5))-thetatil(2);
elseif ind == [0 0 1]
    p_fit = 1-thetatil(3)+copula(thetatil(3),thetatil(2)+thetatil(1),thetatil(5))-thetatil(2)-thetatil(1);
end
