format long

load local_quant

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Finite sample power curves for Robust Wald test using Adjusted-Bonferroni 
%CVs of Han and McCloskey (2016) (HM hereafter) and the projected version 
%of the SR-AR test of 
%Andrews and Guggenberger
%(2014) (AG2 hereafter) in TC model described in example 2.3 of HM.  The
%null hypothesis is H_0: tildepi_2=0.4 so that
%(beta,tilde_zeta,tildepi_1,tildepi_3) are nuisance parameters.
%Program computes (size-corrected) rejection probabilities for a grid of
%alternative values `tildepi_20', where `tildepi_20' equals the true parameter beta
%minus the hypothesized parameter and the nuisance parameters 
%(beta,tilde_zeta,tildepi_1,tildepi_3) are fixed at user-chosen values.
%The parameter beta controls identification strength and values 
%beta=0,0.1,0.2 and 0.4 should be examined to cover a wide range of 
%identification strengths.  The grid of tildepi_20 values is over the interval
%[-`largest_x','largest_x'] and the number of points in the grid is the
%variable 'points'.  In order to satisfy parameter space restrictions, 
%largest _x must be strictly less than 0.395.  Program separately outputs 
%the null rejection probabilities.  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Rdraws = 10000;%4; %number of simulation repetitions used to compute rejection probabilities;

alpha = 0.05; %nominal size
a = 0.5; %Level of "CI" used in CV construciton (must match with simulated SCF)
SCF_Wald = 0.0984; %Size-Correction Factor computed using *SC_factor_gen.m program
CIb_quant = chi2inv(1-a,1); %chi-squared quantile used in CV construction

%The following info pins down the DGP (under null)
n = 1000; %sample size
pitil = [0.6;0.4;0.4];
beta = 0.2;
zetatil = 0.2;
phiz = 0.5;    % mean of binary instrument

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Optimization Preliminaries%%%%%%%%%%%%%%%%

options = optimset('LargeScale','off', ...
               'HessUpdate','bfgs', ...
               'Algorithm', 'active-set',...
               'Hessian','off', ...
               'GradObj','off', ...
               'DerivativeCheck','off',...
               'Display', 'off');

%Bounds for Optimization
A = [1 1 0 0 0; -1 -1 0 0 0];
b = [0.99; -0.01];
thetatil_L = [-0.98;0.01;0.01;0.01;-0.99];
thetatil_H = [0.98;0.99;0.99;0.99;0.99];
Aminus = [1 1 0 0 ; -1 -1 0 0 ];
Bminus = [0.99; -0.01];
thetatilminus_L = [-0.98;0.01;0.01;-0.99];
thetatilminus_H = [0.98;0.99;0.99;0.99];
thetatilminus_true = [beta; zetatil; pitil(1);  pitil(3)];

%True Deviations from the Null
tildepi_20 = [-0.247;0.304];
points = length(tildepi_20)-1; %number of deviations considered

%chi-squared critical values
cvchisq4 = chi2inv(1-alpha,4);
cvchisq5 = chi2inv(1-alpha,5);

SR_AR_power = zeros(points+1,1); %here we store the power for the projected SR-AR test
Wald_power = zeros(points+1,1); %here we store the power for the Wald test

%%%%%%%%%%%%%%%%%%%%%Compute Size-Corrected Power%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% FIRST MAIN LOOP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%loop over tildepi_2 values; when tildepi_20=0 the null is true; otherwise the truth
%is in the alternative hypothesis
for i=1:(points+1)
    pitil_2 = pitil(2)+tildepi_20(i); %true value of pitilde_2
    rej = zeros(Rdraws,1); %here we count the number of rejections of SR-AR
    rejW = zeros(Rdraws,1); %here we count the number of rejections of the Wald test
    %%%%%%%%%%%%%%%%%%%%%% SECOND MAIN LOOP %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%% loop in R of length Rdraws %%%%%%%%%%%%%%%%%%%%%%%
    parfor R=1:Rdraws
        %next,  we create a draw from the DGP in example 2.3 of HM
        u = AMH_copula_rng_fn(pitil(3),n);
        eps = u(:,1);
        v = u(:,2);
        z = binornd(1,phiz,n,1);
        d = (zetatil+beta*z >= eps);
        y = (pitil(1)+(pitil_2-pitil(1))*d >= v);
        data = [y,d,z];
        indicator = [(y==1).*(d==1).*(z==0),(y==1).*(d==1).*(z==1),(y==1).*(d==0).*(z==0),(y==1).*(d==0).*(z==1),(y==0).*(d==1).*(z==0),(y==0).*(d==1).*(z==1),(y==0).*(d==0).*(z==0),(y==0).*(d==0).*(z==1)];
        
        %%%%%%%%%%%%%%%%%%%%Compute SR_AR Test%%%%%%%%%%%%%%%%%%%%%%%%%
        [minimizer,SR_AR_min] = fmincon(@(thetatilminus)SR_AR_fn(pitil(2),thetatilminus,indicator,n,cvchisq4,cvchisq5),thetatilminus_true, Aminus, Bminus, [], [], thetatilminus_L, thetatilminus_H, []);
        % optimization with random starting points
        rnd = rand(10,1); % random number for starting points in global minimization
        for k=1:length(rnd)
            pitil3_0 = -0.99+rnd(k)*(0.99+0.99);
            thetatilminus_0 = [beta; zetatil; pitil(1);  pitil3_0];
            [minimizer1,SR_AR_min1] = fmincon(@(thetatilminus)SR_AR_fn(pitil(2),thetatilminus,indicator,n,cvchisq4,cvchisq5),thetatilminus_0, Aminus, Bminus, [], [], thetatilminus_L, thetatilminus_H, []);
            if SR_AR_min1 < SR_AR_min
                minimizer = minimizer1;
                SR_AR_min = SR_AR_min1;
            end;
        end;
        
        rej(R) = SR_AR_min>0;
        
        %%%%%%%%%%%%%%%%%%%%Compute Wald Test%%%%%%%%%%%%%%%%%%%%%%%%%
        rnd = rand(10,1); % random number for starting points in global minimization
        %Estimation
        thetatil_true = [beta; zetatil; pitil(1); pitil_2; pitil(3)];
        [thetatil_est, logL_val] = fmincon(@(thetatil)logL_fn(data, thetatil),thetatil_true, A, b, [], [], thetatil_L, thetatil_H, [], options);
        % optimization with random starting points
        for k=1:10
            pitil3_0 = -0.99+rnd(k)*(0.99+0.99);
            thetatil_0 = [beta; zetatil; pitil(1); pitil(2); pitil3_0];
            [thetatil_est1, logL_val1] = fmincon(@(thetatil)logL_fn(data, thetatil),thetatil_0, A, b, [], [], thetatil_L, thetatil_H, [], options);
            if logL_val1 < logL_val
                thetatil_est = thetatil_est1;
                logL_val = logL_val1;
            end;
        end;
        %Also try endpoints
        thetatil_0 = [beta; zetatil; 0.65; 0.15; 0.99];
        [thetatil_est1, logL_val1] = fmincon(@(thetatil)logL_fn(data, thetatil),thetatil_0, A, b, [], [], thetatil_L, thetatil_H, [], options);
        if logL_val1 < logL_val
            thetatil_est = thetatil_est1;
            logL_val = logL_val1;
        end;
        thetatil_0 = [beta; zetatil; 0.6; 0.54; -0.99];
        [thetatil_est1, logL_val1] = fmincon(@(thetatil)logL_fn(data, thetatil),thetatil_0, A, b, [], [], thetatil_L, thetatil_H, [], options);
        if logL_val1 < logL_val
            thetatil_est = thetatil_est1;
            logL_val = logL_val1;
        end;
        var_est = 2*var_theta_fn(thetatil_est); %variance-covariance estimator
        Wald = n*(thetatil_est(4)-pitil(2))^2/var_est(4,4);
        CIb_lb = max(0,sqrt(n)*thetatil_est(1)-sqrt(var_est(1,1)*CIb_quant));
        CIb_ub = max(0,sqrt(n)*thetatil_est(1)+sqrt(var_est(1,1)*CIb_quant));
        cv(R) = max(local_quant(min((round(4*CIb_lb)+1),53):min((round(4*CIb_ub)+1),53)));
        rejW(R) = Wald>(cv(R)+SCF_Wald);
    end;
    %%%%%%%%end loop over simulation draws%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    SR_AR_power(i) = sum(rej)/Rdraws;
    Wald_power(i) = sum(rejW)/Rdraws;
end;
%%%%%%%end loop over different tildepi_2 values%%%%%%%