load loc_lim_est_04;
load fs_est_04;


%%alpha
xmin = 0.2;
xmax = 0.6;
ymin = 0;
ymax = 20;

%Finite Sample Histogram
subplot(2,5,1)
B = theta_hat(:,1);
[nn,x]=hist(B,40);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','r','EdgeColor','r');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('n=1000, beta'));

%Asymptotic Histogram
subplot(2,5,6)
B = theta_star(:,1);
[nn,x]=hist(B,40);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','b','EdgeColor','b');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('Asy, beta'));


%%delta
xmin = 0;
xmax = 0.4;
ymin = 0;
ymax = 25;

%Finite Sample Histogram
subplot(2,5,2)
B = theta_hat(:,2);
[nn,x]=hist(B,40);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','r','EdgeColor','r');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('n=1000, zeta'));

%Asymptotic Histogram
subplot(2,5,7)
B = theta_star(:,2);
[nn,x]=hist(B,40);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','b','EdgeColor','b');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('Asy, zeta'));


%%beta1
xmin = 0.4;
xmax = 0.8;
ymin = 0;
ymax = 15;

%Finite Sample Histogram
subplot(2,5,3)
B = theta_hat(:,3);
[nn,x]=hist(B,40);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','r','EdgeColor','r');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('n=1000, pi_1^1'));

%Asymptotic Histogram
subplot(2,5,8)
B = theta_star(:,3);%B = theta_star(:,4);%
[nn,x]=hist(B,40);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','b','EdgeColor','b');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('Asy, pi_1^11'));


%%beta2
xmin = 0;
xmax = 0.8;
ymin = 0;
ymax = 10;

%Finite Sample Histogram
subplot(2,5,4)
B = theta_hat(:,4);
[nn,x]=hist(B,40);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','r','EdgeColor','r');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('n=1000, pi_2^1'));

%Asymptotic Histogram
subplot(2,5,9)
B = theta_star(:,4);%B = theta_star(:,6);%
[nn,x]=hist(B,40);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','b','EdgeColor','b');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('Asy, pi_2^1'));


%%beta3
xmin = -0.3;
xmax = 1.1;
ymin = 0;
ymax = 15;

%Finite Sample Histogram
subplot(2,5,5)
B = theta_hat(:,5);
[nn,x]=hist(B,40);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','r','EdgeColor','r');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('n=1000, pi'));

%Asymptotic Histogram
subplot(2,5,10)
B = theta_star(:,5);%B = theta_star(:,7);%
[nn,x]=hist(B,40);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','b','EdgeColor','b');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('Asy, pi'));