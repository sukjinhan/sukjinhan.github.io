function logL = logL_fn(data, theta)

%This function calculates the log likelihood of the TC model with an AMH
%copula

%Define local fn copula
copula = @(u1,u2,rho)(u1*u2/(1-rho*(1-u1)*(1-u2)));

%Define variables
y = data(:,1);
d = data(:,2);
z = data(:,3);

% Fitted probabilities
alpha = theta(1);
delta = theta(2);
beta = theta(3:5);

p110 = copula(beta(2),delta,beta(3));
p111 = copula(beta(2),delta+alpha,beta(3));
p100 = beta(1)-copula(beta(1),delta,beta(3));
p101 = beta(1)-copula(beta(1),delta+alpha,beta(3));
p010 = delta-copula(beta(2),delta,beta(3));
p011 = delta+alpha-copula(beta(2),delta+alpha,beta(3));
p000 = 1-p110-p100-p010;
p001 = 1-p111-p101-p011;

% Exclude negative values close to zero
p110(p110<=0) = 0;
p111(p111<=0) = 0;
p100(p100<=0) = 0;
p101(p101<=0) = 0;
p010(p010<=0) = 0;
p011(p011<=0) = 0;
p000(p000<=0) = 0;
p001(p001<=0) = 0;

%Form the log-likelihood
L110 = (y==1).*(d==1).*(z==0).*log(p110);
L111 = (y==1).*(d==1).*(z==1).*log(p111);
L100 = (y==1).*(d==0).*(z==0).*log(p100);
L101 = (y==1).*(d==0).*(z==1).*log(p101);
L010 = (y==0).*(d==1).*(z==0).*log(p010);
L011 = (y==0).*(d==1).*(z==1).*log(p011);
L000 = (y==0).*(d==0).*(z==0).*log(p000);
L001 = (y==0).*(d==0).*(z==1).*log(p001);

logL0 = L110 + L111 + L100 + L101 + L010 + L011 + L000 + L001;
logL0_s = logL0(0==isnan(logL0));
logL0_s = logL0_s(0==isinf(logL0_s));
n_s = size(logL0_s,1);

logL = - sum(logL0_s)/n_s;	% CAUTION: make it minimization problem