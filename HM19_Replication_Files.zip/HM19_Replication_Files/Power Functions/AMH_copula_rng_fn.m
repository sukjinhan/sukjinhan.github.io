function [output] = AMH_copula_rng_fn(rho,n)
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   This function generates a set of 2-dimensional realizations of random
%   variables with uniform(0,1) marginal distributions and an AMH copula
%   parameterized by rho
%   
%   rho     = AMH copula dependence parameter (must be weakly greater than
%              -1 and strictly less than 1)
%   n       = sample size
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eps = rand(n,1);
t = rand(n,1);

a = 1-eps;
b = -rho*(2*a.*t+1)+2*rho^2*(a.^2).*t+1;
c = rho^2*(4*(a.^2).*t-4*a.*t+1)-rho*(4*a.*t-4*t+2)+1;

v = (2*t.*(rho*a-1).^2)./(b+sqrt(c));

output = [eps v];

