function H_mtx = H_mtx_fn(pi,theta_0,phi_vec)

%This function calculates the quantity H(pi;gamma_0) that enters the
%limiting distribution of the transformed parameter estiamtes under weak
%identification. Phi_vec is a vector of probabilities that Z is equal to
%zero and 1.  It must match the last column of the M matrix.

psi_0 = [theta_0(1); theta_0(2); theta_0(3); theta_0(4)];

M = (dec2bin(0:(2^3)-1)=='1')*eye(3);

H_mtx = zeros(4,4);

for j=1:length(M)
    H_mtx = H_mtx+phi_vec(j)*p_bar_fn(M(j,:)',theta_0)*(p_bar_grad_fn(M(j,:)',[psi_0;pi])*p_bar_grad_fn(M(j,:)',[psi_0;pi])'/(p_bar_fn(M(j,:)',[psi_0;pi])^2)-p_bar_hess_fn(M(j,:)',[psi_0;pi])/p_bar_fn(M(j,:)',[psi_0;pi]));
end