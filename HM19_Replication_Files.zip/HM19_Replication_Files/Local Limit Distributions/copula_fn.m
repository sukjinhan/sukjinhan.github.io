function copula = copula_fn(x,y,z)

%This function calculates the AMH copula at values x, y and z

copula = (x*y/(1-z*(1-x)*(1-y)));