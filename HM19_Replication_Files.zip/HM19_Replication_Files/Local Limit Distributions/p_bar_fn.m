function p_bar = p_bar_fn(ind, theta)

%This function computes the fitted probabilities in terms of the transformed
%parameter theta.  ind is a 3-by-1 vector denoting the values of
%(y,d,z) in the fitted probability. theta=(alpha,delta,xi1,xi2,pi)

if ind == [1; 1; 0]
    p_bar = theta(3);
elseif ind == [1; 1; 1]
    p_bar = copula_fn(h1_fn(2,theta(2),theta(3),theta(4),theta(5)),theta(2)+theta(1),theta(5));
elseif ind == [1; 0; 0]
    p_bar = theta(4);
elseif ind == [1; 0; 1]
    p_bar = h1_fn(1,theta(2),theta(3),theta(4),theta(5))-copula_fn(h1_fn(1,theta(2),theta(3),theta(4),theta(5)),theta(2)+theta(1),theta(5));
elseif ind == [0; 1; 0]
    p_bar = theta(2)-theta(3);
elseif ind == [0; 1; 1]
    p_bar = theta(2)+theta(1)-copula_fn(h1_fn(2,theta(2),theta(3),theta(4),theta(5)),theta(2)+theta(1),theta(5));
elseif ind == [0; 0; 0]
    p_bar = 1-theta(4)-theta(2);
elseif ind == [0; 0; 1]
    p_bar = 1-h1_fn(1,theta(2),theta(3),theta(4),theta(5))+copula_fn(h1_fn(1,theta(2),theta(3),theta(4),theta(5)),theta(2)+theta(1),theta(5))-theta(2)-theta(1);
end
