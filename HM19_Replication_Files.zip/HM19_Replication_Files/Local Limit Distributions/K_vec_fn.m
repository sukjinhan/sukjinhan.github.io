function K_vec = K_vec_fn(pi,theta_0,phi_vec)

%This function calculates the quantity K(pi;gamma_0) that enters the
%limiting distribution of the transformed parameter estiamtes under weak
%identification

psi_0 = [theta_0(1); theta_0(2); theta_0(3); theta_0(4)];

M = (dec2bin(0:(2^3)-1)=='1')*eye(3);

K_vec = zeros(4,1);

for j=1:length(M)
    K_vec = K_vec-phi_vec(j)*[1 0 0 0]*p_bar_grad_fn(M(j,:)',theta_0)*p_bar_grad_fn(M(j,:)',[psi_0;pi])/p_bar_fn(M(j,:)',[psi_0;pi]);
end