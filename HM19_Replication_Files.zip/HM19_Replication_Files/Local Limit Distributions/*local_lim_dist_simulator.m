%This code simulates draws from the asymptotic distributions of the estimators and one-dimensional Wald statistics (squared t-statistics) 
%of the parameters of the threshold crossing model with a dummy endogenous variable (Example 2.3) under weak-identification
%sequences with localization parameter a.

%Set Parameter Values
alpha = 0.7;
delta_0 = 0.2;
beta1_0 = 0.6;
beta2_0 = 0.4;
beta3_0 = 0.4;
theta_tilde_0 = [0;delta_0;beta1_0;beta2_0;beta3_0];
theta_true = [alpha; delta_0; beta1_0; beta2_0; beta3_0];
xi1_0 = p_fit_fn([1 1 0],theta_tilde_0);
xi2_0 = p_fit_fn([1 0 0],theta_tilde_0);
theta_0 = [0;delta_0;xi1_0;xi2_0;beta3_0];
phi0_0 = 0.5;
phi1_0 = 1-phi0_0;
a = alpha*sqrt(n); %localization parameter

% Preliminaries 
n = 1000; %Sample Size
R = 10000;  %Number of replications
pi_H = 0.99; %Upper and lower bound in optimization
pi_L = -0.99;

%%Simulation Preliminaries
options = optimset('LargeScale','off', ...
               'HessUpdate','bfgs', ...
               'Algorithm', 'active-set',...
               'Hessian','off', ...
               'GradObj','off', ...
               'DerivativeCheck','off',...
               'Display', 'off');
           
 % matrices that store results
 pi_star = zeros(R,1);
 alpha_star = zeros(R,1);
 delta_star = zeros(R,1);
 xi1_star = zeros(R,1);
 xi2_star = zeros(R,1);
 beta1_star = zeros(R,1);
 beta2_star = zeros(R,1);
 t_stats = zeros(R,5);
 Q_unres = zeros(R,1);

%Generate Covariance Matrix for Z-tilde
M = (dec2bin(0:(2^3)-1)=='1')*eye(3);
Omega_tilde = zeros(length(M),length(M));
phi_vec = zeros(length(M),1);
for j=1:2:(length(M)-1)
    phi_vec(j) = phi0_0;
    phi_vec(j+1) = phi1_0;
end;
for j=1:length(M)
    for i=1:length(M)
        if i==j
            Omega_tilde(i,j) = p_bar_fn(M(j,:)', theta_0)*phi_vec(j)*(1-p_bar_fn(M(j,:)', theta_0)*phi_vec(j));
        else
            Omega_tilde(i,j) = -p_bar_fn(M(i,:)', theta_0)*p_bar_fn(M(j,:)', theta_0)*phi_vec(j)*phi_vec(i);
        end;
    end;
end;
sqrt_Omega_tilde = sqrtm(Omega_tilde);

parfor r = 1:R
    tilde_Z = sqrt_Omega_tilde*randn(length(M),1);
    [pi_star(r), Q_unres(r)] = fmincon(@(pi)stoch_process_fn(tilde_Z, theta_0, phi_vec, pi, a),0.2, [], [], [], [], pi_L, pi_H, [], options);
    pi_star(r) = real(pi_star(r));
    tau_star = -(H_mtx_fn(pi_star(r),theta_0,phi_vec))\(G_tilde_process_fn(tilde_Z,theta_0,pi_star(r))+K_vec_fn(pi_star(r),theta_0,phi_vec)*a)-[a;zeros(3,1)];
    alpha_star(r) = real(a/sqrt(n)+tau_star(1)/sqrt(n));
    delta_star(r) = real(theta_0(2)+tau_star(2)/sqrt(n));
    xi1_star(r) = real(theta_0(3)+tau_star(3)/sqrt(n));
    xi2_star(r) = real(theta_0(4)+tau_star(4)/sqrt(n));
    pi1_star = [h1_fn(1, delta_star(r), xi1_star(r), xi2_star(r), pi_star(r));h1_fn(2, delta_star(r), xi1_star(r), xi2_star(r), pi_star(r))];
    beta1_star(r) = real(pi1_star(1));
    beta2_star(r) = real(pi1_star(2));
    theta_est = [alpha_star(r);delta_star(r);beta1_star(r);beta2_star(r);pi_star(r)];
    asy_var_est = 2*var_theta_fn(theta_est); 
    t_stats(r,:) = [n*(alpha_star(r)-alpha)^2/asy_var_est(1,1) n*(delta_star(r)-delta_0)^2/asy_var_est(2,2) n*(pi_star(r)-beta3_0)^2/asy_var_est(5,5) n*(beta1_star(r)-beta1_0)^2/asy_var_est(3,3) n*(beta2_star(r)-beta2_0)^2/asy_var_est(4,4)]; 
end;