function p_fit = p_fit_fn(ind, theta)

%This function calculates fitted probabilities P(Y=h, D=j|Z=k) under
%parameter values theta = (alpha, delta, beta1, beta2, beta3), where ind =
%(h,j,k)

%Define local fn copula
copula = @(x,y,z)(x*y/(1-z*(1-x)*(1-y)));

if ind == [1 1 0]
    p_fit = copula(theta(4),theta(2),theta(5));
elseif ind == [1 1 1]
    p_fit = copula(theta(4),theta(2)+theta(1),theta(5));
elseif ind == [1 0 0]
    p_fit = theta(3)-copula(theta(3),theta(2),theta(5));
elseif ind == [1 0 1]
    p_fit = theta(3)-copula(theta(3),theta(2)+theta(1),theta(5));
elseif ind == [0 1 0]
    p_fit = theta(2)-copula(theta(4),theta(2),theta(5));
elseif ind == [0 1 1]
    p_fit = theta(2)+theta(1)-copula(theta(4),theta(2)+theta(1),theta(5));
elseif ind == [0 0 0]
    p_fit = 1-theta(3)+copula(theta(3),theta(2),theta(5))-theta(2);
elseif ind == [0 0 1]
    p_fit = 1-theta(3)+copula(theta(3),theta(2)+theta(1),theta(5))-theta(2)-theta(1);
end
