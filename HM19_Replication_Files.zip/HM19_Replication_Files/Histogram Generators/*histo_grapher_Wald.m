load loc_lim_Wald_02;
load fs_Wald_02;


%%beta
xmin = 0;
xmax = 5;
ymin = 0;
ymax = 3;

%Finite Sample Histogram
subplot(2,5,1)
B = theta_tilde_WaldFS(:,1);
[nn,x]=hist(B,1000);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','r','EdgeColor','r');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('n=1000, beta'));
xline = 0:0.01:5;
yline = chi2pdf(xline,1);
line (xline, yline, 'LineWidth',2, 'Color','k');

%Asymptotic Histogram
subplot(2,5,6)
B = theta_tilde_Waldasy(:,1);
[nn,x]=hist(B,1000);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','b','EdgeColor','b');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('Asy, beta'));
xline = 0:0.01:5;
yline = chi2pdf(xline,1);
line (xline, yline, 'LineWidth',2, 'Color','k');


%%zeta

%Finite Sample Histogram
subplot(2,5,2)
B = theta_tilde_WaldFS(:,2);
[nn,x]=hist(B,1000);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','r','EdgeColor','r');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('n=1000, zeta'));
xline = 0:0.01:5;
yline = chi2pdf(xline,1);
line (xline, yline, 'LineWidth',2, 'Color','k');

%Asymptotic Histogram
subplot(2,5,7)
B = theta_tilde_Waldasy(:,2);
[nn,x]=hist(B,1000);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','b','EdgeColor','b');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('Asy, zeta'));
xline = 0:0.01:5;
yline = chi2pdf(xline,1);
line (xline, yline, 'LineWidth',2, 'Color','k');


%%pi

%Finite Sample Histogram
subplot(2,5,3)
B = theta_tilde_WaldFS(:,3);
[nn,x]=hist(B,1000);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','r','EdgeColor','r');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('n=1000, pi'));
xline = 0:0.01:5;
yline = chi2pdf(xline,1);
line (xline, yline, 'LineWidth',2, 'Color','k');

%Asymptotic Histogram
subplot(2,5,8)
B = theta_tilde_Waldasy(:,3);
[nn,x]=hist(B,1000);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','b','EdgeColor','b');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('Asy, pi'));
xline = 0:0.01:5;
yline = chi2pdf(xline,1);
line (xline, yline, 'LineWidth',2, 'Color','k');


%%beta1

%Finite Sample Histogram
subplot(2,5,4)
B = theta_tilde_WaldFS(:,4);
[nn,x]=hist(B,1000);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','r','EdgeColor','r');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('n=1000, pi_1^1'));
xline = 0:0.01:5;
yline = chi2pdf(xline,1);
line (xline, yline, 'LineWidth',2, 'Color','k');

%Asymptotic Histogram
subplot(2,5,9)
B = theta_tilde_Waldasy(:,4);
[nn,x]=hist(B,1000);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','b','EdgeColor','b');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('Asy, pi_1^11'));
xline = 0:0.01:5;
yline = chi2pdf(xline,1);
line (xline, yline, 'LineWidth',2, 'Color','k');


%%beta2

%Finite Sample Histogram
subplot(2,5,5)
B = theta_tilde_WaldFS(:,5);
[nn,x]=hist(B,1000);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','r','EdgeColor','r');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('n=1000, pi_2^1'));
xline = 0:0.01:5;
yline = chi2pdf(xline,1);
line (xline, yline, 'LineWidth',2, 'Color','k');

%Asymptotic Histogram
subplot(2,5,10)
B = theta_tilde_Waldasy(:,5);
[nn,x]=hist(B,1000);
delta_x = x(2)-x(1);
bar(x,nn./sum(nn)/delta_x,1,'FaceColor','b','EdgeColor','b');
axis([xmin,xmax,ymin,ymax]);
title(sprintf('Asy, pi_2^1'));
xline = 0:0.01:5;
yline = chi2pdf(xline,1);
line (xline, yline, 'LineWidth',2, 'Color','k');