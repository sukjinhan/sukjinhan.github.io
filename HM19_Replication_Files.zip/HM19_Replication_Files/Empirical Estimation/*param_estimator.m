format long

load ca11_black_BvB
load drop_black_BvB
load prison_black_BvB

options = optimset('LargeScale','off', ...
               'HessUpdate','bfgs', ...
               'Algorithm', 'active-set',...
               'Hessian','off', ...
               'GradObj','off', ...
               'DerivativeCheck','off',...
               'Display', 'off');

%Bounds for Optimization
A = [1 1 0 0 0; -1 -1 0 0 0];
b = [0.99; -0.01];
thetatil_L = [-0.98;0.01;0.01;0.01;0];
thetatil_H = [0.98;0.99;0.99;0.99;0.99];
Aminus = [1 1 0 0 ; -1 -1 0 0 ];
Bminus = [0.99; -0.01];
thetatilminus_L = [-0.98;0.01;0.01;0];
thetatilminus_H = [0.98;0.99;0.99;0.99];

data = [prison,drop,ca11];

theta_til_initial = [0.2;0.2;0.6;0.4;0.4];
[thetatil_est, logL_val] = fmincon(@(thetatil)logL_fn(data, thetatil),theta_til_initial, A, b, [], [], thetatil_L, thetatil_H, [], options);

% optimization with random starting points
rnd = rand(10,1); % random number for starting points in global minimization
for k=1:length(rnd)
    pitil3_0 = -0.99+rnd(k)*(0.99+0.99);
    thetatil_0 = [theta_til_initial(1); theta_til_initial(2); theta_til_initial(3); theta_til_initial(4); pitil3_0];
    [thetatil_est1, logL_val1] = fmincon(@(thetatil)logL_fn(data, thetatil),thetatil_0, A, b, [], [], thetatil_L, thetatil_H, [], options);
    if logL_val1 < logL_val
        thetatil_est = thetatil_est1;
        logL_val = logL_val1;
    end;
end;

%Also try endpoints
thetatil_0 = [beta; zetatil; 0.65; 0.15; 0.99];
[thetatil_est1, logL_val1] = fmincon(@(thetatil)logL_fn(data, thetatil),thetatil_0, A, b, [], [], thetatil_L, thetatil_H, [], options);
if logL_val1 < logL_val
    thetatil_est = thetatil_est1;
    logL_val = logL_val1;
end;
thetatil_0 = [beta; zetatil; 0.6; 0.54; -0.99];
[thetatil_est1, logL_val1] = fmincon(@(thetatil)logL_fn(data, thetatil),thetatil_0, A, b, [], [], thetatil_L, thetatil_H, [], options);
if logL_val1 < logL_val
   thetatil_est = thetatil_est1;
    logL_val = logL_val1;
end;