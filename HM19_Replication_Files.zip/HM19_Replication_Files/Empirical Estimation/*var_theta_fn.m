function var_theta = var_theta_fn(theta)

%This function calculates an estimator of the asymptotic
%variance-covariance matrix of the MLE of theta = (alpha, delta, beta1,
%beta2, beta3) for the AMH copula

M = (dec2bin(0:(2^3)-1)=='1')*eye(3);

J_theta = zeros(5,5);

for j=1:length(M)
    J_theta = J_theta+p_fit_deriv_fn(M(j,:),theta)'*p_fit_deriv_fn(M(j,:),theta)/p_fit_fn(M(j,:),theta);
end;

var_theta = inv(J_theta);