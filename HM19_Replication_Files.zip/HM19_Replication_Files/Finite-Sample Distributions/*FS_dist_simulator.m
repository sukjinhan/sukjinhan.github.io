%This code simulates finite-sample draws of the estimators and one-dimensional Wald statistics (squared t-statistics) of the parameters of the threshold crossing
%model with a dummy endogenous variable (Example 2.3)

% Preliminaries           
R = 10000; %Simulation Replications
n = 1000;  %Sample Size

%Set Parameter Values
beta = [0.6;0.4;0.4];
alpha = 0.7;
delta = 0.2;
theta_true = [alpha; delta; beta];
mu_z = 0.5;    % mean of binary instrument



%%%%Simulation Preliminaries
options = optimset('LargeScale','off', ...
               'HessUpdate','bfgs', ...
               'Algorithm', 'active-set',...
               'Hessian','off', ...
               'GradObj','off', ...
               'DerivativeCheck','off',...
               'Display', 'off');

% matrices that store results
theta_est_all = zeros(R,5);
t_stats = zeros(R,5);

%Bounds for Optimization
A = [1 1 0 0 0; -1 -1 0 0 0];
b = [0.99; -0.01];
theta_L = [-0.98;0.01;0.01;0.01;-0.99];
theta_H = [0.98;0.99;0.99;0.99;0.99];

%% Simulation Repetition Starts

parfor j=1:R
    %Generate Data
    u = AMH_copula_rng_fn(beta(3),n);
    eps = u(:,1);
    v = u(:,2);
    z = binornd(1,mu_z,n,1);
    d = (delta+alpha*z >= eps);
    y = (beta(1)+(beta(2)-beta(1))*d >= v);
    data = [y,d,z];
    rnd = rand(10,1); % random number for starting points in global minimization
    %Estimation
    [theta_est, logL_val] = fmincon(@(theta)logL_fn(data, theta),theta_true, A, b, [], [], theta_L, theta_H, [], options);
    % optimization with random starting points
    for i=1:10
        beta3_0 = -0.99+rnd(i)*(0.99+0.99);
        theta_0 = [alpha; delta; beta(1); beta(2); beta3_0];
        [theta_est1, logL_val1] = fmincon(@(theta)logL_fn(data, theta),theta_0, A, b, [], [], theta_L, theta_H, [], options);
        if logL_val1 < logL_val
            theta_est = theta_est1;
            logL_val = logL_val1;
        end;
    end;
    %Also try endpoints
    theta_0 = [alpha; delta; 0.65; 0.15; 0.99];
    [theta_est1, logL_val1] = fmincon(@(theta)logL_fn(data, theta),theta_0, A, b, [], [], theta_L, theta_H, [], options);
    if logL_val1 < logL_val
        theta_est = theta_est1;
        logL_val = logL_val1;
    end;
    beta3_0 = theta_H(5);
    theta_0 = [alpha; delta; 0.6; 0.54; -0.99];
    [theta_est1, logL_val1] = fmincon(@(theta)logL_fn(data, theta),theta_0, A, b, [], [], theta_L, theta_H, [], options);
    if logL_val1 < logL_val
        theta_est = theta_est1;
        logL_val = logL_val1;
    end;
    var_est = 2*var_theta_fn(theta_est); %variance-covariance estimator
    var_est_diag = diag(var_est);
    theta_est_all(j,:) = theta_est';    % CAUTION: transpose
    t_stats(j,:) = sqrt(n)*(theta_est-theta_true)'./sqrt(var_est_diag');
end;

t_stats = t_stats.^2;