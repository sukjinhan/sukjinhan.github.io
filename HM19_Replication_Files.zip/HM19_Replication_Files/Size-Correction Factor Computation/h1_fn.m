function h1 = h1_fn(ind, delta, xi1, xi2, pi)

%This function calculates the elements h^1(xi,pi^0). 
%The value of ind indicates which element (first or second) to calculate.

a = pi*(1-delta);
b = (1-delta)-pi*(1-delta)-xi2*pi*(1-delta);
c = xi2*(pi*(1-delta)-1);


if ind == 2
    h1 = xi1*(1-pi*(1-delta))/(delta-xi1*pi*(1-delta));
elseif ind == 1 
    if a~=0
        h1 = real((-b+sqrt(b^2-4*a*c))/(2*a));
    else
        h1 = -c/b;
    end
end